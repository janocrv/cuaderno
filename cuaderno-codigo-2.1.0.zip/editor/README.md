# Editor de documentos de Cuaderno

Tiptap 3 / ProseMirror, con páginas A4 de 794 × 1123 px y 28 px entre hojas.
Las esquinas, la sombra y el color de cada hoja pertenecen a la interfaz, no al apunte.
El documento sigue guardándose como HTML y mantiene referencias `data-fid`, imágenes
de fondo, tablas y notas adhesivas. El historial se reinicia al cambiar de apunte.

`editor.js` contiene la integración. `build.mjs` genera un paquete sin conexiones
externas y lo incluye entre los marcadores `CUADERNO_EDITOR_BUNDLE_*` del HTML.
Incluye las licencias; la app y los instaladores siguen copiando un solo HTML.
No editar el paquete generado: editar la fuente y volver a ejecutar el generador.

Para evitar miles de archivos dentro de Drive:

```sh
mkdir -p /tmp/cuaderno-editor-build
cp editor/package.json editor/package-lock.json /tmp/cuaderno-editor-build/
npm ci --prefix /tmp/cuaderno-editor-build
node editor/build.mjs /tmp/cuaderno-editor-build
node editor/tests/editor.cjs /tmp/cuaderno-editor-build
```

Las pruebas abren Chrome sin interfaz y con perfil temporal, usan exclusivamente
datos de ejemplo y nunca leen `datos/` ni el perfil de la app real.

La paginación y las tablas usan extensiones MIT de Romik Makavana. El generador
adapta el cálculo de páginas para incluir los objetos flotantes de Cuaderno.
La exportación PDF mantiene su composición propia (título, fecha, notas al final);
sus saltos pueden diferir de la vista del editor. La app de escritorio importa y
exporta DOCX mediante `documentos-worker.js`; esa función no está en la edición web.
