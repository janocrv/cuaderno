// npm install in this folder, then node build.mjs. Optional external build directory
// keeps node_modules out of Drive: node editor/build.mjs /tmp/cuaderno-editor-build
import { createRequire } from 'node:module';
import { readFile, writeFile, readdir } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
const dir = path.dirname(fileURLToPath(import.meta.url));
const dependencies = process.argv[2] ? path.resolve(process.argv[2]) : dir;
const require = createRequire(path.join(dependencies, 'package.json'));
const { build } = require('esbuild');
const result = await build({ entryPoints: [path.join(dir, 'editor.js')], bundle: true, write: false, minify: true, metafile: true,
  format: 'iife', target: 'chrome110', legalComments: 'none', nodePaths: [path.join(dependencies, 'node_modules')],
  plugins: [{ name: 'cuaderno-floating-pages', setup(builder) {
    builder.onLoad({ filter: /tiptap-pagination-plus\/dist\/PaginationPlus\.js$/ }, async ({ path: filename }) => {
      let source = await readFile(filename, 'utf8');
      // Floating images/stickies can be lower than the last paragraph. Exclude page widgets.
      const before = 'const lastElementRect = lastElementOfEditor.getBoundingClientRect();';
      if (!source.includes(before)) throw new Error('Revisar la adaptación de paginación para esta versión');
      source = source.replace(before, `const lastElementRect = { bottom: Math.max(...Array.from(editorDom.children).filter(el => !el.matches('[data-rm-pagination], .rm-first-page-header')).map(el => el.getBoundingClientRect().bottom)) };`);
      return { contents: source, loader: 'js' };
    });
  } }],
});
const filename = path.join(dir, '..', 'cuaderno-apuntes.html');
const html = await readFile(filename, 'utf8');
const start = '<!-- CUADERNO_EDITOR_BUNDLE_START -->', end = '<!-- CUADERNO_EDITOR_BUNDLE_END -->';
const packages = new Set();
for (const input of Object.keys(result.metafile.inputs)) {
  const match = path.resolve(input).match(/^(.*\/node_modules\/(?:@[^/]+\/)?[^/]+)/);
  if (match) packages.add(match[1]);
}
const mit = (await readFile(path.join(dependencies, 'node_modules', '@tiptap', 'core', 'LICENSE.md'), 'utf8')).split('Permission is hereby granted')[1];
const notices = [];
for (const folder of [...packages].sort()) {
  const pkg = JSON.parse(await readFile(path.join(folder, 'package.json'), 'utf8'));
  const licenseFile = (await readdir(folder)).find(name => /^licen[cs]e(?:\.(?:md|txt))?$/i.test(name));
  const license = licenseFile ? await readFile(path.join(folder, licenseFile), 'utf8') : `MIT License\nAuthor: ${typeof pkg.author === 'string' ? pkg.author : pkg.author?.name || pkg.name}\n\nPermission is hereby granted${mit}`;
  notices.push(`${pkg.name} ${pkg.version}\n${'='.repeat(60)}\n${license.trim()}`);
}
const notice = notices.join('\n\n');
await writeFile(path.join(dir, 'THIRD_PARTY_NOTICES.txt'), notice + '\n');
const bundle = `${start}\n<script type="application/json" id="cuaderno-editor-licenses">${JSON.stringify(notice).replace(/</g, '\\u003c')}</script>\n<script>\n${result.outputFiles[0].text.replace(/<\/script/gi, '<\\/script')}\n</script>\n${end}`;
if (!html.includes(start) || !html.includes(end)) throw new Error('Faltan los marcadores del editor');
await writeFile(filename, html.slice(0, html.indexOf(start)) + bundle + html.slice(html.indexOf(end) + end.length));
console.log('Editor integrado en cuaderno-apuntes.html (funciona sin conexión).');
