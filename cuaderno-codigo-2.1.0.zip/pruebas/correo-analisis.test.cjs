const {test}=require('node:test'),assert=require('node:assert/strict'),api=require('../correo-analisis.js');
test('libros con título explícito conservan texto y autor sin inventar metadatos',()=>{
  const result=api.books({body:'Os recomiendo el libro «Aprender a enseñar», de Ana López.\nLibro: Evaluación formativa\nNos vemos el martes.'});
  assert.equal(result.length,2);assert.equal(result[0].title,'Aprender a enseñar');assert.equal(result[0].authors,'Ana López');assert.equal(result[1].authors,'');
});
test('no convierte comentarios vagos ni citas de mensajes anteriores en libros',()=>{
  assert.deepEqual(api.books({body:'Recomiendo que leáis algo sobre evaluación.'}),[]);
  assert.deepEqual(api.books({body:'Gracias\nDe: Profesor\nRecomiendo «Libro anterior»'}),[]);
});
test('ampliación con identidad única de tarea; nunca fusiona por fecha',()=>{
  const tasks=[{id:'uno',title:'Análisis de caso'},{id:'dos',title:'Comentario de texto'}];
  assert.equal(api.extension({subject:'Ampliación de plazo',body:'El Análisis de caso se entrega el 20 de noviembre.'},tasks,'2026-11-20').id,'uno');
  assert.equal(api.extension({subject:'Nuevo plazo',body:'Entregad la actividad el viernes'},tasks,'2026-11-20'),null);
  assert.equal(api.extension({body:'Ampliamos Análisis de caso y Comentario de texto'},tasks,'2026-11-20'),null);
  assert.equal(api.extension({body:'Información sobre Análisis de caso'},tasks,'2026-11-20'),null);
});
test('ampliación elige fecha nueva y omite mensajes citados',()=>{
  assert.equal(api.extensionDate({body:'Ampliamos el plazo del 15 de noviembre de 2026 al 20 de noviembre de 2026.\n> El año que viene, 30/12/2027'},'2026-11-14'),'2026-11-20');
  assert.equal(api.extensionDate({body:'Nou termini: 22/11/2026'},'2026-11-14'),'2026-11-22');
});
