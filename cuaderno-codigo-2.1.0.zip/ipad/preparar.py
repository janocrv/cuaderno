"""Prepara una edición web sin copiar datos personales ni publicarla."""
from pathlib import Path
import shutil, hashlib, json
here=Path(__file__).resolve().parent
root=here.parent
out=here/'vista-previa'
out.mkdir(exist_ok=True)
for name in ['cuaderno-apuntes.html','esquemas.html','correo-analisis.js','aviso.mp3','avisos.mp3','cuaderno.png']:
    shutil.copy2(root/name,out/name)
shutil.copytree(root/'sonidos',out/'sonidos',dirs_exist_ok=True)
for name in ['manifest.webmanifest','web.js']:
    shutil.copy2(here/name,out/name)
html=(out/'cuaderno-apuntes.html').read_text()
html=html.replace('<title>Cuaderno</title>','<title>Cuaderno</title>\n<link rel="manifest" href="manifest.webmanifest">\n<link rel="apple-touch-icon" href="cuaderno.png">\n<meta name="apple-mobile-web-app-capable" content="yes">\n<meta name="theme-color" content="#edf3f0">\n<script src="web.js"></script>',1)
(out/'cuaderno-apuntes.html').write_text(html)
(out/'index.html').write_text('<!doctype html><meta charset="utf-8"><meta http-equiv="refresh" content="0;url=cuaderno-apuntes.html"><a href="cuaderno-apuntes.html">Abrir Cuaderno</a>')
assets=['./'+str(p.relative_to(out)) for p in out.rglob('*') if p.is_file() and p.name!='sw.js']
digest=hashlib.sha256()
for asset in sorted(assets):digest.update((out/asset[2:]).read_bytes())
version=digest.hexdigest()[:12]
worker='''const CACHE='cuaderno-web-VERSION',ASSETS=ASSETLIST;
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(ASSETS))));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(key=>key.startsWith('cuaderno-web-')&&key!==CACHE).map(key=>caches.delete(key))))));
self.addEventListener('fetch',event=>{const url=new URL(event.request.url);if(event.request.method!=='GET'||url.origin!==self.location.origin||url.pathname.includes('/api/'))return;event.respondWith(caches.open(CACHE).then(async cache=>(await cache.match(event.request))||fetch(event.request)));});
'''.replace('VERSION',version).replace('ASSETLIST',json.dumps(assets))
(out/'sw.js').write_text(worker)
print('Edición iPad preparada en '+str(out)+'. No publicada; sin datos personales.')
