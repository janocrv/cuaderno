window.CUADERNO_WEB=true;
addEventListener('DOMContentLoaded',()=>{
  document.documentElement.classList.add('tablet-edition');
  const help=document.createElement('p');help.className='hint';help.textContent='Edición iPad · Los documentos se guardan en este dispositivo. Usa las copias de seguridad para llevarlos a otro ordenador.';
  document.querySelector('#settingsDlg .dlg, #setDlg .dlg')?.append(help);
  const mail=document.querySelector('#mailBtn');if(mail)mail.onclick=()=>window.open('https://correo.uv.es/','_blank','noopener');
  const intranet=document.querySelector('#intranetBtn');if(intranet)intranet.onclick=()=>window.open('https://portal.uv.es/','_blank','noopener');
  if('serviceWorker' in navigator&&isSecureContext)navigator.serviceWorker.register('./sw.js').catch(()=>{});
});
