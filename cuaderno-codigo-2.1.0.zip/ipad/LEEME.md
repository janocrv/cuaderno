# Cuaderno para iPad · versión de prueba

Ejecutar `python3 ipad/preparar.py` prepara `ipad/vista-previa` con la interfaz táctil y funcionamiento sin conexión tras la primera carga. No copia datos, fotos, correos ni credenciales de Jano. No publica nada.

Para instalarla en iPad se necesita servir esa carpeta en una dirección HTTPS. Cuando Jano apruebe la interfaz, se podrá elegir el alojamiento. En Safari: Compartir → Añadir a pantalla de inicio → Abrir como app web. Fuente: https://support.apple.com/en-gb/guide/ipad/ipad8f1f7a29/27/ipados/27

Los documentos y adjuntos se guardan en el navegador del iPad. Se pueden importar/exportar copias desde Archivos (incluido Google Drive). No hay sincronización automática con Drive ni acceso a servicios de escritorio: correo e intranet abren sus webs oficiales; Word e historial requieren Mac/Windows. PDF usa Imprimir de Safari. No borrar datos de Safari sin exportar una copia.

Controles preparados para toque y probados en tamaños de tableta; falta validación con iPad físico. Es una edición web preparada, no una app de App Store ni un instalador de Electron.
