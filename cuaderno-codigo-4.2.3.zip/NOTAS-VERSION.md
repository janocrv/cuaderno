# Cuaderno 4.2.3

- **Trabajos en grupo, con panel propio:** la pestaña «En grupo» (y el botón β de la barra) muestra tus trabajos en tarjetas, con su asignatura, quién está dentro y si hay cambios nuevos. Dentro de cada asignatura ves sus trabajos. «+ Nuevo trabajo» y «Unirme con un código» abren su ventanita, donde eliges la asignatura.
- **Invitar es más fácil:** el código ahora es corto (por ejemplo T82R-78JD-GC6R), sale grande en «Invitar» y es el mismo para todo el grupo. Los códigos largos anteriores siguen funcionando.
- **Fotos donde escribes:** al añadir una foto a un apunte, entra justo debajo de la línea donde tienes el cursor (antes aparecía arriba de la primera página).
- **Avisos visibles:** mensajes como «Código copiado» salen por encima de las ventanas, no detrás.
- **Cabecera y barra del editor:** más aire arriba, elementos centrados y la franja de la barra de herramientas sin «cortes» a los lados.

Incluye todas las mejoras de la versión 4.2.1. Los datos guardados se conservan al actualizar.

## Descargas

- **Mac con chip Apple:** Cuaderno-mac-arm64.dmg.
- **Mac Intel:** Cuaderno-mac-x64.dmg.
- **Windows de 64 bits:** Cuaderno-win-x64.exe.

Probado con datos ficticios. Los trabajos en grupo necesitan internet; un código recién creado puede tardar hasta un minuto en funcionar. Windows físico queda pendiente de comprobación.
