/* NODE_PATH=<playwright> node pruebas/barra-editor-fija.cjs. Datos ficticios. */
const {chromium}=require('playwright'),fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
(async()=>{const browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});try{
 const p=await browser.newPage({viewport:{width:1440,height:1000}}),errors=[];p.on('pageerror',e=>errors.push(e.message));
 const content=Array.from({length:160},(_,i)=>(i%20===0?'<h2>Sección '+i+'</h2>':'')+'<p>Párrafo '+i+'. Texto de prueba para comprobar que las herramientas siguen accesibles en todas las páginas del documento.</p>').join('');
 await p.addInitScript(content=>{if(top!==window)return;localStorage.setItem('cuaderno-apuntes-v1',JSON.stringify({subjects:[{id:'test',short:'ADP',name:'Asignatura de prueba',color:'#399c91',notes:[{id:'note',title:'Documento de varias páginas',date:'2026-11-15',updated:1,content}],tasks:[],files:[],biblio:[],teachers:[]}],active:'test',subjectScope:'test',activeNote:'note',view:'notes',theme:'light',settings:{userName:'Prueba',lang:'es'},deleted:{},library:[],schedule:[],homeBoard:[],tfmAdded:true,seeded2627:true}));localStorage.setItem('cuaderno-correo-preguntado','1');},content);
 await p.route('https://api.github.com/**',r=>r.fulfill({json:{tag_name:'v3.0.2'}}));await p.goto(require('node:url').pathToFileURL(path.join(process.cwd(),'cuaderno-apuntes.html')).href);await p.waitForTimeout(1000);
 assert(await p.locator('.page-sheet').count()>3);
 for(const width of [1440,1024,784]){
  await p.setViewportSize({width,height:1000});await p.waitForTimeout(200);
  for(const y of [800,2400,5000]){
   await p.locator('.ed-scroll').evaluate((el,y)=>el.scrollTop=y,y);await p.waitForTimeout(120);
   const box=await p.locator('.editor-tools').boundingBox(),scroll=await p.locator('.ed-scroll').boundingBox(),bar=await p.locator('#toolbar').boundingBox();assert(Math.abs(box.y-scroll.y)<2);assert(bar.y>=scroll.y&&bar.y+bar.height<scroll.y+scroll.height);
   assert(await p.locator('#toolbar [data-cmd="bold"]').evaluate(el=>{const r=el.getBoundingClientRect();return el.contains(document.elementFromPoint(r.x+r.width/2,r.y+r.height/2));}));
   const side=await p.locator('#pageTools').boundingBox();assert(side.y>=box.y+box.height);
  }
  await p.locator('#wordTools summary').click();assert(await p.locator('#wordExport').isVisible());const menu=await p.locator('#wordTools>div').boundingBox();assert(menu.x>=0&&menu.x+menu.width<=width);await p.locator('#wordTools summary').click();
  await p.locator('.font-preview-menu summary').click();await p.locator('.font-preview-choices').waitFor({state:'visible'});await p.locator('.font-preview-menu summary').click();
  await p.locator('#toolbar [data-cmd="table"]').click();assert(await p.locator('#tpGrid').isVisible());await p.locator('#toolbar [data-cmd="table"]').click();
  console.log('PASS barra, herramientas laterales y menús accesibles tras desplazarse a '+width+' px');
 }
 await p.setViewportSize({width:1440,height:1000});await p.locator('#outlineToggle').click();await p.locator('#documentOutline button').nth(4).click();await p.waitForTimeout(700);
 const tools=await p.locator('.editor-tools').boundingBox(),heading=await p.locator('#editor h2').nth(4).boundingBox();assert(heading.y>=tools.y+tools.height);
 const paragraph=p.locator('#editor>p').nth(85);await paragraph.scrollIntoViewIfNeeded();await paragraph.click();await p.keyboard.press('End');await p.locator('#toolbar [data-cmd="bold"]').click();await p.keyboard.type(' Texto añadido desde la barra fija');await p.keyboard.press('Meta+s');await p.waitForTimeout(600);
 const saved=await p.evaluate(()=>JSON.parse(localStorage.getItem('cuaderno-apuntes-v1')));assert.match(saved.subjects[0].notes[0].content,/<strong>[^<]*Texto añadido desde la barra fija/);
 const out=path.join(process.cwd(),'revisiones/2026-11-15');fs.mkdirSync(out,{recursive:true});await p.screenshot({path:path.join(out,'barra-editor-fija.png')});console.log('PASS índice sin títulos tapados, formato y guardado desde páginas posteriores');
 await p.locator('#toolbar [data-cmd="table"]').click();await p.locator('#tpGrid i[data-r="3"][data-c="3"]').click();await p.locator('#editor table td').first().click();await p.waitForTimeout(150);
 const delta=await p.locator('#editor table').evaluate(t=>t.closest('.cuaderno-table').getBoundingClientRect().bottom-document.querySelector('.editor-tools').getBoundingClientRect().bottom+30);
 await p.locator('.ed-scroll').evaluate((el,delta)=>el.scrollTop+=delta,delta);await p.waitForTimeout(150);assert(!(await p.locator('.table-edges').isVisible()));
 assert(await p.locator('#toolbar [data-cmd="bold"]').evaluate(el=>{const r=el.getBoundingClientRect();return el.contains(document.elementFromPoint(r.x+r.width/2,r.y+r.height/2));}));
 await p.locator('.ed-scroll').evaluate((el,delta)=>el.scrollTop-=delta,delta);await p.waitForTimeout(150);assert(await p.locator('.table-edges').isVisible());
 assert.deepEqual(errors,[]);console.log('PASS los controles de una tabla oculta no cubren las herramientas y reaparecen al volver');
}finally{await browser.close()}})().catch(e=>{console.error(e);process.exit(1)});
