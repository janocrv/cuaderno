const {test}=require('node:test'),assert=require('node:assert/strict'),{Worker}=require('node:worker_threads'),path=require('node:path'),JSZip=require('jszip'),{DOMParser}=require('@xmldom/xmldom');
const W='http://schemas.openxmlformats.org/wordprocessingml/2006/main',nodes=(d,n)=>Array.from(d.getElementsByTagNameNS(W,n)),attr=(n,k)=>n?.getAttributeNS(W,k);
const plainText=node=>nodes(node,'t').map(t=>t.textContent).join('');
async function exportDoc(html,header='',footer=''){
 const worker=new Worker(process.env.CUADERNO_WORD_WORKER||path.resolve(__dirname,'../escritorio/documentos-worker.js'));
 try{const r=await new Promise((resolve,reject)=>{worker.once('error',reject);worker.once('message',resolve);worker.postMessage({id:1,type:'export',html,title:'Auditoría de exportación',header,footer});});if(r.error)throw Error(r.error);const zip=await JSZip.loadAsync(Buffer.from(r.result.buffer));const xml=await zip.file('word/document.xml').async('string');return {zip,xml,doc:new DOMParser().parseFromString(xml,'application/xml')};}finally{await worker.terminate();}
}
test('DOCX conserva sangría, interlineado y espacios de párrafo explícitos',async()=>{
 const {doc,xml}=await exportDoc('<p style="line-height:1.5;margin-top:0;margin-bottom:12pt;margin-left:1.25cm;text-indent:1.25cm">Párrafo</p>');
 const p=nodes(doc,'p').find(p=>plainText(p)==='Párrafo'),spacing=nodes(p,'spacing')[0],ind=nodes(p,'ind')[0];assert.equal(attr(spacing,'line'),'360');assert.equal(attr(spacing,'before'),'0');assert.equal(attr(spacing,'after'),'240');assert.equal(attr(ind,'left'),'709');assert.equal(attr(ind,'firstLine'),'709');assert(!xml.includes('undefined'));assert(!xml.includes('CUADERNO_'));
});
test('DOCX conserva tabulaciones nativas y texto literal del encabezado/pie',async()=>{
 const {doc,zip}=await exportDoc('<p>Antes<span data-doc-tab="true" style="white-space:pre;tab-size:1.25cm">\t</span>Después</p>','Grupo <A> & B','Página <Z>');assert.equal(nodes(doc,'tab').length,1);assert.match(plainText(doc),/AntesDespués/);
 const parser=new DOMParser(),head=parser.parseFromString(await zip.file('word/header1.xml').async('string'),'application/xml'),foot=parser.parseFromString(await zip.file('word/footer1.xml').async('string'),'application/xml');assert.equal(plainText(head),'Grupo <A> & B');assert.equal(plainText(foot),'Página <Z>');
});
test('DOCX conserva números individuales y negrita del marcador',async()=>{
 const {doc,zip}=await exportDoc('<ol><li><p>Uno</p></li><li value="4" data-marker-bold="true"><p>Cuatro</p></li><li value="3"><p>Tres</p></li></ol>');
 const numbering=new DOMParser().parseFromString(await zip.file('word/numbering.xml').async('string'),'application/xml');
 for(const [text,expected,bold] of [['Uno','1',false],['Cuatro','4',true],['Tres','3',false]]){const p=nodes(doc,'p').find(p=>plainText(p)===text),id=attr(nodes(p,'numId')[0],'val'),num=nodes(numbering,'num').find(n=>attr(n,'numId')===id),aid=attr(nodes(num,'abstractNumId')[0],'val'),abs=nodes(numbering,'abstractNum').find(n=>attr(n,'abstractNumId')===aid);assert.equal(attr(nodes(abs,'start')[0],'val'),expected);if(bold)assert.equal(attr(nodes(abs,'b')[0],'val'),'1');}
});
test('DOCX mantiene listas alfabéticas y viñetas individuales',async()=>{
 const {doc,zip}=await exportDoc('<ol type="a" start="3"><li><p>Letra</p></li><li style="list-style-type:disc" data-marker-italic="true"><p>Viñeta</p></li></ol>');const numbering=new DOMParser().parseFromString(await zip.file('word/numbering.xml').async('string'),'application/xml');
 for(const [text,format] of [['Letra','lowerLetter'],['Viñeta','bullet']]){const p=nodes(doc,'p').find(p=>plainText(p)===text),num=nodes(numbering,'num').find(n=>attr(n,'numId')===attr(nodes(p,'numId')[0],'val')),aid=attr(nodes(num,'abstractNumId')[0],'val'),abs=nodes(numbering,'abstractNum').find(n=>attr(n,'abstractNumId')===aid);assert.equal(attr(nodes(abs,'numFmt')[0],'val'),format);if(text==='Letra')assert.equal(attr(nodes(abs,'start')[0],'val'),'3');else assert.equal(attr(nodes(abs,'i')[0],'val'),'1');}
});
test('DOCX mantiene texto y marcas dentro de tablas y no propaga márgenes de contenedor',async()=>{
 const {doc}=await exportDoc('<div style="margin-bottom:24pt"><p>Primero</p><p>Segundo</p></div><table><tbody><tr><td colwidth="120"><p><strong>Celda A</strong></p></td><td colwidth="160"><p>Celda B</p></td></tr></tbody></table>');assert.equal(nodes(doc,'tbl').length,1);assert.match(doc.documentElement.textContent,/Primero[\s\S]*Segundo[\s\S]*Celda A[\s\S]*Celda B/);assert(nodes(doc,'b').length>0);const first=nodes(doc,'p').find(p=>plainText(p)==='Primero');assert.notEqual(attr(nodes(first,'spacing')[0],'after'),'480');
});
test('DOCX conserva guion de marcador y sangría francesa sin valores XML inválidos',async()=>{
 const {doc,zip,xml}=await exportDoc('<p style="text-indent:-1.25cm;margin-left:1.25cm">Francesa</p><ul><li style="list-style-type:&quot;—  &quot;"><p>Guion</p></li></ul><ul style="list-style-type:none"><li><p>Sin marcador</p></li></ul>');const p=nodes(doc,'p').find(p=>plainText(p)==='Francesa');assert.equal(attr(nodes(p,'ind')[0],'hanging'),'709');const numbering=new DOMParser().parseFromString(await zip.file('word/numbering.xml').async('string'),'application/xml');assert(nodes(numbering,'lvlText').some(n=>attr(n,'val')==='—'));assert(nodes(numbering,'numFmt').some(n=>attr(n,'val')==='none'));assert(!xml.includes('undefined'));const body=nodes(doc,'body')[0];assert.equal(Array.from(body.childNodes).filter(n=>n.nodeType===1).at(-1).localName,'sectPr');
});
test('DOCX no añade un párrafo vacío inicial y conserva los vacíos intencionales',async()=>{
 const first=await exportDoc('<p>Inicio</p>');assert.equal(nodes(first.doc,'p').length,1);const empty=await exportDoc('<p></p><p>Inicio</p>');assert.equal(nodes(empty.doc,'p').length,2);assert.equal(plainText(nodes(empty.doc,'p')[0]),'');
});
