/* Auditoría de integridad: solo documentos ficticios y un perfil temporal. */
const {chromium}=require('playwright'),assert=require('node:assert/strict'),path=require('node:path'),fs=require('node:fs'),{pathToFileURL}=require('node:url');
(async()=>{const browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true}),results=[];try{
 const p=await browser.newPage({viewport:{width:1440,height:1000}}),errors=[];p.setDefaultTimeout(8000);p.on('pageerror',e=>errors.push(e.message));
 await p.addInitScript(()=>{if(top!==window)return;
  Object.defineProperty(window,'CuadernoEditor',{configurable:true,set(api){const mount=api.mount;api.mount=(...args)=>(window.auditRich=mount(...args));Object.defineProperty(window,'CuadernoEditor',{value:api,configurable:true});}});
  const s={id:'audit',short:'ADP',name:'Auditoría aislada',color:'#399c91',notes:[{id:'n',title:'Auditoría',date:'2026-11-15',content:'<p>Inicial</p>'},{id:'other',title:'Segundo documento',date:'2026-11-14',content:'<p>Texto independiente</p>'}],tasks:[],files:[],teachers:[],biblio:[]};
  localStorage.setItem('cuaderno-apuntes-v1',JSON.stringify({subjects:[s],active:s.id,subjectScope:s.id,activeNote:'n',view:'notes',theme:'light',settings:{userName:'Prueba',lang:'es'},deleted:{},library:[],schedule:[],seeded2627:true,tfmAdded:true}));localStorage.setItem('cuaderno-correo-preguntado','1');
 });
 await p.route('https://api.github.com/**',r=>r.fulfill({json:{tag_name:'v3.0.2'}}));await p.goto(pathToFileURL(process.env.CUADERNO_AUDIT_HTML||path.join(process.cwd(),'cuaderno-apuntes.html')).href);await p.waitForFunction(()=>!!window.auditRich);
 const load=async html=>{await p.evaluate(html=>auditRich.load(html),html);await p.evaluate(()=>new Promise(requestAnimationFrame));};
 const run=async(name,fn)=>{try{await fn();results.push({name,ok:true});console.log('PASS '+name);}catch(e){results.push({name,ok:false,error:e.message});console.log('FAIL '+name+': '+e.message.slice(0,240));}};
 const image='<img alt="Imagen de prueba" src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyMCIgaGVpZ2h0PSIyMCIvPg==">';
 const table='<table><tbody><tr><td><p>Celda A</p></td><td><p>Celda B</p></td></tr></tbody></table>';
 await run('borrar imagen anidada conserva lista y texto; deshacer restaura solo la imagen',async()=>{
  await load('<ol><li><p>Antes</p>'+image+'<p>Después</p></li><li><p>Vecino</p></li></ol>');await p.evaluate(()=>auditRich.remove(document.querySelector('#editor img')));assert.equal(await p.locator('#editor img').count(),0);assert.equal(await p.locator('#editor > ol > li').count(),2);assert.match(await p.locator('#editor').innerText(),/Antes[\s\S]*Después[\s\S]*Vecino/);await p.evaluate(()=>auditRich.command('undo'));assert.equal(await p.locator('#editor img').count(),1);
 });
 await run('borrar nota adhesiva dentro de cita conserva el resto de la cita',async()=>{
  await load('<blockquote><p>Cita conservada</p><div class="sticky" data-col="rosa"><div class="st-body"><p>Nota</p></div></div><p>Final conservado</p></blockquote>');await p.evaluate(()=>auditRich.remove(document.querySelector('#editor .sticky')));assert.equal(await p.locator('#editor blockquote').count(),1);assert.match(await p.locator('#editor blockquote').innerText(),/Cita conservada[\s\S]*Final conservado/);assert.equal(await p.locator('#editor .sticky').count(),0);
 });
 await run('tabla anidada se redimensiona y se borra sin borrar la lista',async()=>{
  await load('<ul><li><p>Instrucciones</p>'+table+'<p>Conclusión</p></li></ul>');assert.equal(await p.evaluate(()=>auditRich.tableGeometry(document.querySelector('#editor table'),[120,160],[48])),true);assert.match(await p.locator('#editor table').evaluate(e=>e.closest('.cuaderno-table').style.width),/280px/);await p.evaluate(()=>auditRich.remove(document.querySelector('#editor table')));assert.equal(await p.locator('#editor > ul > li').count(),1);assert.match(await p.locator('#editor').innerText(),/Instrucciones[\s\S]*Conclusión/);
 });
 await run('tabla flotante conserva coordenadas cero al guardar y cargar',async()=>{
  await load(table);await p.evaluate(()=>auditRich.tablePosition(document.querySelector('#editor table'),0,0,280));const html=await p.evaluate(()=>auditRich.html());await load(html);assert.equal(await p.locator('#editor .cuaderno-table').evaluate(e=>e.style.left),'0px');assert.equal(await p.locator('#editor .cuaderno-table').evaluate(e=>e.style.top),'0px');
 });
 await run('interlineado uniforme inline y de párrafo no aparece como Mixto',async()=>{
  await load('<p style="line-height:1.5"><span style="line-height:1.5">Mismo interlineado</span></p>');await p.evaluate(()=>auditRich.editor.commands.setTextSelection(3));assert.equal(await p.evaluate(()=>auditRich.paragraphFormat().lineHeight),'1.5');
 });
 await run('Deshacer al cambiar de apunte no recupera texto de otro documento',async()=>{
  await load('<p>Documento A</p>');await p.evaluate(()=>{auditRich.editor.commands.setTextSelection(3);auditRich.insertText(' CAMBIO ');});await load('<p>Documento B</p>');await p.evaluate(()=>auditRich.command('undo'));assert.equal(await p.locator('#editor').innerText(),'Documento B');
 });
 await run('corrección ortográfica reemplaza texto literal, sin interpretar HTML',async()=>{
  await load('<p>palabra</p>');await p.evaluate(()=>{const t=document.querySelector('#editor>p').firstChild,r=new Range();r.selectNodeContents(t);auditRich.replaceRange(r,'<b>literal</b>');});assert.equal(await p.locator('#editor b,#editor strong').count(),0);assert.equal(await p.locator('#editor>p').innerText(),'<b>literal</b>');
 });
 await run('un rango obsoleto no modifica un documento recién abierto',async()=>{
  await load('<p>Anterior</p>');await p.evaluate(()=>{window.auditRange=document.createRange();auditRange.selectNodeContents(document.querySelector('#editor>p'));});await load('<p>Nuevo documento</p>');assert.equal(await p.evaluate(()=>auditRich.replaceRange(auditRange,'ERRÓNEO')),false);assert.equal(await p.locator('#editor').innerText(),'Nuevo documento');
 });
 await run('vaciar documento y deshacer conserva contenido, formato y adjuntos',async()=>{
  await load('<p><strong>Importante</strong> <span style="color:#ff0000">color</span></p>'+image+table);const before=await p.evaluate(()=>auditRich.editor.getHTML());await p.evaluate(()=>{auditRich.editor.commands.selectAll();auditRich.editor.commands.deleteSelection();auditRich.command('undo');});assert.equal(await p.evaluate(()=>auditRich.editor.getHTML()),before);
 });
 await run('color, tamaño, enlace, resaltado, subrayado y título sobreviven a edición y reapertura',async()=>{
  await load('<h2>Título</h2><p><u>Subrayado</u> <a href="https://www.uv.es/">enlace</a> <mark>resaltado</mark> <span style="font-size:18pt;color:#112233">grande</span></p>');await p.evaluate(()=>{auditRich.editor.commands.setTextSelection(3);auditRich.insertText('X');});const html=await p.evaluate(()=>auditRich.html());await load(html);assert.equal(await p.locator('#editor h2').count(),1);assert.equal(await p.locator('#editor u').innerText(),'Subrayado');assert.equal(await p.locator('#editor a').getAttribute('href'),'https://www.uv.es/');assert.equal(await p.locator('#editor mark').innerText(),'resaltado');assert.match(await p.locator('#editor span').getAttribute('style'),/18pt/);
 });
 await run('adjuntar lentamente y salir a Archivos conserva el adjunto en su apunte',async()=>{
  await load('<p>Texto antes del adjunto</p>');
  await p.evaluate(()=>{window.auditDelayIDB=true;const desc=Object.getOwnPropertyDescriptor(IDBTransaction.prototype,'oncomplete');Object.defineProperty(IDBTransaction.prototype,'oncomplete',{configurable:true,get:desc.get,set(handler){desc.set.call(this,event=>{if(window.auditDelayIDB&&this.mode==='readwrite')setTimeout(()=>handler.call(this,event),600);else handler.call(this,event);});}});});
  await p.locator('#attInput').setInputFiles({name:'auditoria-adjunto.txt',mimeType:'text/plain',buffer:Buffer.from('Adjunto ficticio')});await p.locator('#tabFiles').click();await p.waitForTimeout(850);await p.evaluate(()=>window.auditDelayIDB=false);await p.keyboard.press('Meta+s');await p.locator('#tabNotes').click();await p.waitForTimeout(150);assert.equal(await p.locator('#editor .att[data-fid]').count(),1);assert.match(await p.locator('#editor').innerText(),/Texto antes del adjunto/);
 });
 await run('composición de teclado y guardado no duplican ni pierden letras acentuadas',async()=>{
  await load('<p>Inicio X</p>');await p.evaluate(()=>{auditRich.editor.commands.setTextSelection(8);auditRich.editor.commands.focus();});await p.evaluate(()=>new Promise(requestAnimationFrame));const cdp=await p.context().newCDPSession(p);try{await cdp.send('Input.imeSetComposition',{text:'á',selectionStart:1,selectionEnd:1});await p.keyboard.press('Meta+s');await cdp.send('Input.insertText',{text:'á'});await p.keyboard.press('Meta+s');assert.equal(await p.locator('#editor>p').innerText(),'Inicio áX');}finally{await cdp.detach();}
 });
 await run('pegar HTML no ejecuta atributos de evento de una imagen',async()=>{
  await p.evaluate(()=>window.auditInjected=false);await load('<p>Antes</p><img src="data:image/png;base64,AA" onerror="window.auditInjected=true"><p>Después</p>');await p.waitForTimeout(150);assert.equal(await p.evaluate(()=>window.auditInjected),false);assert.equal(await p.locator('#editor [onerror]').count(),0);
 });
 await run('geometría inválida no guarda NaN ni tamaños imposibles',async()=>{
  await load(table);const before=await p.evaluate(()=>auditRich.editor.getHTML());assert.equal(await p.evaluate(()=>auditRich.tableGeometry(document.querySelector('#editor table'),[0,0],null)),false);assert.equal(await p.evaluate(()=>auditRich.editor.getHTML()),before);
 });
 await run('menús de letra y negrita conservan la selección de una palabra',async()=>{
  await load('<p>antes palabra después</p>');await p.evaluate(()=>{auditRich.editor.commands.setTextSelection({from:7,to:14});auditRich.editor.commands.focus();});await p.evaluate(()=>new Promise(requestAnimationFrame));await p.locator('.font-preview-menu summary').click();await p.locator('.font-preview-choices button').filter({hasText:'Georgia · Aa Bb 123'}).click();assert.equal(await p.locator('#editor span[style*="Georgia"]').innerText(),'palabra');await p.locator('#toolbar [data-cmd="bold"]').click();assert.equal(await p.locator('#editor strong').innerText(),'palabra');
 });
 await run('quitar formato deja texto y no elimina objetos del documento',async()=>{
  await load('<h2 style="text-indent:1.25cm;color:#112233"><strong>Título</strong></h2><p style="line-height:2;margin-top:12pt"><u>Texto</u></p>'+image);await p.evaluate(()=>{auditRich.editor.commands.selectAll();auditRich.command('removeFormat');});assert.match(await p.locator('#editor').innerText(),/Título[\s\S]*Texto/);assert.equal(await p.locator('#editor img').count(),1);assert.equal(await p.locator('#editor strong,#editor u').count(),0);
 });
 await run('una lista que empieza en cero muestra ese número en su editor de marcador',async()=>{
  await load('<ol start="0"><li><p>Cero</p></li><li><p>Uno</p></li></ol>');const r=await p.locator('#editor li').first().boundingBox();await p.mouse.dblclick(r.x-8,r.y+10);assert.equal(await p.getByLabel('Número de este elemento',{exact:true}).inputValue(),'0');await p.getByRole('button',{name:'Cerrar',exact:true}).click();
 });
 await run('vaciar src y título de una imagen no deja la imagen anterior visible',async()=>{
  await load(image.replace('alt="Imagen de prueba"','alt="Imagen de prueba" title="Título anterior"'));await p.evaluate(()=>{auditRich.editor.commands.setNodeSelection(0);auditRich.editor.commands.updateAttributes('image',{src:null,title:null,fid:null});});assert.equal(await p.locator('#editor img').getAttribute('src'),null);assert.equal(await p.locator('#editor img').getAttribute('title'),null);
 });
 await run('borrar el apunte durante una carga cancela el adjunto sin recrear el apunte',async()=>{
  await load('<p>Apunte que se va a eliminar</p>');const before=await p.evaluate(()=>JSON.parse(localStorage.getItem('cuaderno-apuntes-v1')).subjects[0].files.length);await p.evaluate(()=>window.auditDelayIDB=true);
  await p.locator('#attInput').setInputFiles({name:'cancelado.txt',mimeType:'text/plain',buffer:Buffer.from('No debe quedar huérfano')});p.once('dialog',d=>d.accept());await p.locator('#deleteNote').click();await p.waitForTimeout(900);await p.evaluate(()=>window.auditDelayIDB=false);await p.keyboard.press('Meta+s');await p.waitForTimeout(100);const s=await p.evaluate(()=>JSON.parse(localStorage.getItem('cuaderno-apuntes-v1')).subjects[0]);assert.equal(s.notes.some(n=>n.id==='n'),false);assert.equal(s.files.length,before);assert.match(await p.locator('#editor').innerText(),/Texto independiente/);
 });
 await run('no hay errores de ejecución del editor',async()=>assert.deepEqual(errors,[]));
 const out=path.join(process.cwd(),'revisiones/2026-11-15');fs.mkdirSync(out,{recursive:true});fs.writeFileSync(path.join(out,process.env.CUADERNO_AUDIT_RESULT||'auditoria-editor-pruebas.json'),JSON.stringify({time:new Date().toISOString(),results},null,2)+'\n');
 if(results.some(r=>!r.ok))process.exitCode=1;
}finally{await browser.close();}})().catch(e=>{console.error(e);process.exit(1)});
