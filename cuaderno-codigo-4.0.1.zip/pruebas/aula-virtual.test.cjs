const {test}=require('node:test'),assert=require('node:assert/strict'),path=require('node:path'),api=require('../aula-virtual.js');
test('solo acepta actividades UV HTTPS con identidad exacta',()=>{
 assert.equal(api.activityURL('123'),'https://aulavirtual.uv.es/mod/assign/view.php?id=123');
 for(const url of ['http://aulavirtual.uv.es/mod/assign/view.php?id=123','https://aulavirtual.uv.es.evil.test/mod/assign/view.php?id=123','https://evil.test/mod/assign/view.php?id=123','https://aulavirtual.uv.es@evil.test/mod/assign/view.php?id=123','https://aulavirtual.uv.es/mod/assign/view.php?id=abc','javascript:alert(1)','https://aulavirtual.uv.es/login/index.php'])assert.equal(api.activityURL(url),'');
 assert.equal(api.taskURL({av:'123',sourceMail:{url:'https://aulavirtual.uv.es/mod/assign/view.php?id=999'}}),api.activityURL('123'));
});
test('conserva procedencia y texto completo del aviso, sin convertirlo en instrucciones',()=>{
 const m={uid:12,subject:'Nueva tarea',from:'profesor@uv.es',from_name:'Profesor',date:'2026-11-15',body:'Instrucciones\n'+'Texto '.repeat(500)+'https://aulavirtual.uv.es/mod/assign/view.php?id=123'};const source=api.fromMail(m);assert.equal(source.body,m.body);assert.equal(source.url,api.activityURL('123'));assert.equal(source.uid,'12');
});
test('actualiza datos verificados y fecha sin tocar trabajo ni estado manual',()=>{
 const t={av:'123',title:'Mi título',done:false,noteId:'documento',due:'2026-11-20'};
 api.apply(t,{verified:true,url:api.activityURL('123'),title:'Título original',instructions:'Enunciado',due:'2026-12-02',submission:'Enviado para calificar',attachments:[{name:'Rúbrica',url:'https://aulavirtual.uv.es/pluginfile.php/12/mod_assign/intro/rubrica.pdf'},{name:'Ajeno',url:'https://evil.test/a.pdf'}]});
 assert.equal(t.title,'Mi título');assert.equal(t.done,false);assert.equal(t.noteId,'documento');assert.equal(t.due,'2026-12-02');assert.equal(t.aula.attachments.length,1);
 assert.throws(()=>api.apply(t,{verified:true,url:api.activityURL('999')}),/no coincide/);assert.throws(()=>api.apply(t,{verified:false,url:api.activityURL('123')}),/Inicia sesión/);
});
test('lector comparte sesión UV, pide login y destruye la ventana temporal',async()=>{
 let created=0,destroyed=0,login='',mode='login',options;
 class Reader{constructor(o){created++;options=o;this.webContents={on(){},setWindowOpenHandler(){},getURL:()=>mode==='login'?'https://as.uv.es/login':api.activityURL('123'),executeJavaScriptInIsolatedWorld:async()=>({verified:true,url:api.activityURL('123'),title:'Tarea',instructions:'Enunciado'})};}async loadURL(){}isDestroyed(){return false;}destroy(){destroyed++;}}
 const reader=require('../escritorio/aula-lector.js')({BrowserWindow:Reader,web:path.resolve(__dirname,'..'),open:url=>login=url});
 await assert.rejects(()=>reader.read('https://evil.test'),/enlace/);assert.equal(created,0);
 assert.equal((await reader.read('123')).needsLogin,true);assert.equal(login,api.activityURL('123'));assert.equal(options.webPreferences.partition,'persist:cuaderno-intranet');assert.equal(options.webPreferences.nodeIntegration,false);
 mode='ready';assert.equal((await reader.read('123')).instructions,'Enunciado');assert.equal(destroyed,2);
});
