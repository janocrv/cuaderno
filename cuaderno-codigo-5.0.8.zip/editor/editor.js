/* Motor de Cuaderno. El HTML sigue siendo el formato de intercambio y de las copias.
   Las páginas son decoraciones: nunca se guardan dentro del apunte. */
import { Editor, Extension, Node, mergeAttributes, wrappingInputRule, createDocument, getHTMLFromFragment } from '@tiptap/core';
import * as Y from 'yjs';
import { updateYFragment, yXmlFragmentToProseMirrorRootNode } from 'y-prosemirror';
import StarterKit from '@tiptap/starter-kit';
import { ListItem } from '@tiptap/extension-list';
import { TextStyleKit } from '@tiptap/extension-text-style';
import TextAlign from '@tiptap/extension-text-align';
import Highlight from '@tiptap/extension-highlight';
import Image from '@tiptap/extension-image';
import { TablePlus, TableRowPlus, TableCellPlus, TableHeaderPlus } from 'tiptap-table-plus';
import { PaginationPlus } from 'tiptap-pagination-plus';
import { EditorState, TextSelection, Plugin } from '@tiptap/pm/state';
import { Decoration, DecorationSet } from '@tiptap/pm/view';
import { closeHistory } from '@tiptap/pm/history';
import { DOMSerializer, Fragment } from '@tiptap/pm/model';
import { CellSelection, tableEditing } from '@tiptap/pm/tables';

const PAGE = { width: 794, height: 1123, gap: 28 };
// Trabajos en grupo (beta): el documento compartido es un estado Yjs. Cada persona convierte su borrador en
// cambios (diferencia con lo último que conocía) y al juntar los estados de todos no se pierde ninguna letra.
const b64e=bytes=>{let s='';for(let i=0;i<bytes.length;i+=8192)s+=String.fromCharCode(...bytes.subarray(i,i+8192));return btoa(s);};
const b64d=text=>Uint8Array.from(atob(text),c=>c.charCodeAt(0));
const TabStop=Node.create({name:'tabStop',group:'inline',inline:true,atom:true,selectable:false,
  parseHTML(){return [{tag:'span[data-doc-tab]'}];},
  renderHTML(){return ['span',{'data-doc-tab':'true',style:'white-space:pre;tab-size:1.25cm'},'\t'];},
  renderText(){return '\t';},
});
const INDENT_STEP=1.25*96/2.54;
const indentPx=value=>Math.round(Math.max(0,Math.min(8*INDENT_STEP,value))*1000)/1000;
const numericAttr=(el,name,fallback)=>{const value=el.getAttribute(name);return value!==null&&value.trim()!==''&&Number.isFinite(Number(value))?Number(value):fallback;};
function lengthPx(value,dom,property='marginLeft'){
  const s=String(value||'').trim(),n=parseFloat(s);if(!Number.isFinite(n))return 0;
  const font=parseFloat(dom&&getComputedStyle(dom).fontSize)||16;
  if(s.endsWith('cm'))return n*96/2.54;if(s.endsWith('mm'))return n*96/25.4;if(s.endsWith('pt'))return n*96/72;
  if(s.endsWith('rem'))return n*(parseFloat(getComputedStyle(document.documentElement).fontSize)||16);if(s.endsWith('em'))return n*font;
  if(s.endsWith('%'))return n*(property==='textIndent'?(dom?.parentElement?.clientWidth||658):658)/100;
  return n;
}
function selectedParagraphs(state){
  const found=new Map();
  for(const {$from,$to} of state.selection.ranges){const from=$from.pos,to=$to.pos;
    state.doc.nodesBetween(from,to,(node,pos)=>{
      if(!['paragraph','heading'].includes(node.type.name))return;
      // A selection ending at the start of the next paragraph excludes that paragraph.
      if(from!==to&&(pos>=to||pos+1===to&&$to.parentOffset===0))return false;
      found.set(pos,node);return false;
    });
  }
  return [...found].map(([pos,node])=>({pos,node}));
}
// Sangrías de párrafo (text-indent / margin-left) y marcadores de lista.
const LISTS=['bulletList','orderedList'];
const DASH_MARKER='"–  "';
const cssBox=style=>{const el=document.createElement('span');el.style.cssText=style||'';return el;};
const indentOf=style=>{const el=cssBox(style);return {text:lengthPx(el.style.textIndent,null,'textIndent'),margin:lengthPx(el.style.marginLeft)};};
const isIndented=style=>{const i=indentOf(style);return i.text>0.5||i.margin>0.5;};
const withoutIndent=style=>{const el=cssBox(style);el.style.removeProperty('text-indent');el.style.removeProperty('margin-left');return el.style.cssText||null;};
const withMarker=(style,dash)=>{const el=cssBox(style);if(dash)el.style.listStyleType=DASH_MARKER;else el.style.removeProperty('list-style-type');return el.style.cssText||null;};
const inListItem=$pos=>$pos.depth>=2&&$pos.node($pos.depth-1).type.name==='listItem';
// «- » → viñeta de guion, «* »/«• » → viñeta, «3. » → números desde el 3, «a) » → letras
const listKind=marker=>{
  if(/^[-–]$/.test(marker))return {ordered:false,dash:true};
  if(/^[*•]$/.test(marker))return {ordered:false,dash:false};
  if(/^[aA]/.test(marker))return {ordered:true,start:1,type:marker[0]};
  return {ordered:true,start:Number(marker.slice(0,-1))||1,type:null};
};
// Sube (dir -1) o baja (dir 1) el elemento de lista donde está el cursor, con sus subelementos. En el primero o el
// último no hace nada (pero se queda con la tecla para que no se mueva el cursor de sitio).
function moveListItem(editor,dir){
  const {state,view}=editor,{$from,from,to}=state.selection;
  for(let d=$from.depth;d>0;d--){
    if($from.node(d).type.name!=='listItem')continue;
    const list=$from.node(d-1),index=$from.index(d-1),item=$from.node(d),pos=$from.before(d),other=list.maybeChild(index+dir);
    if(!other)return true;
    const tr=state.tr,start=dir<0?pos-other.nodeSize:pos,end=dir<0?pos+item.nodeSize:pos+item.nodeSize+other.nodeSize;
    tr.replaceWith(start,end,Fragment.fromArray(dir<0?[item,other]:[other,item]));
    const shift=dir<0?-other.nodeSize:other.nodeSize;
    tr.setSelection(TextSelection.create(tr.doc,from+shift,to+shift));
    view.dispatch(closeHistory(tr).scrollIntoView());return true;
  }
  return false;   // fuera de listas: Alt+Mayús+flecha hace lo de siempre (seleccionar)
}
// Tab en el primer elemento (no hay elemento anterior del que colgarlo): se mueve toda la lista hacia dentro;
// Mayús+Tab en el primero de una lista movida la devuelve hacia el margen.
function shiftWholeList(editor,dir){
  const {state,view}=editor,{$from}=state.selection;
  for(let d=$from.depth;d>0;d--){
    if($from.node(d).type.name!=='listItem')continue;
    if($from.index(d-1)!==0)return false;
    const list=$from.node(d-1),el=cssBox(list.attrs.style),now=lengthPx(el.style.marginLeft),next=indentPx(now+dir*INDENT_STEP);
    if(dir<0&&now<0.5)return false;
    if(next>0.5)el.style.marginLeft=next+'px';else el.style.removeProperty('margin-left');
    view.dispatch(closeHistory(state.tr.setNodeMarkup($from.before(d-1),undefined,{...list.attrs,style:el.style.cssText||null})));return true;
  }
  return false;
}
const CuadernoListItem=ListItem.extend({addAttributes(){return {...this.parent?.(),value:{default:null,keepOnSplit:false,parseHTML:el=>numericAttr(el,'value',null),renderHTML:a=>a.value!==null?{value:a.value}:{}},markerBold:{default:false,keepOnSplit:false,parseHTML:el=>el.hasAttribute('data-marker-bold'),renderHTML:a=>a.markerBold?{'data-marker-bold':'true'}:{}},markerItalic:{default:false,keepOnSplit:false,parseHTML:el=>el.hasAttribute('data-marker-italic'),renderHTML:a=>a.markerItalic?{'data-marker-italic':'true'}:{}}};}});
const TableSelection = Extension.create({ name:'cuadernoTableSelection', addProseMirrorPlugins(){return [tableEditing()];} });
const CuadernoTable = TablePlus.extend({
  content:'tableRow+',
  addExtensions(){return (this.parent?.()||[]).filter(extension=>extension.name!=='tableRowGroup');},
  addAttributes() { return { ...this.parent?.(), width: { default: null, parseHTML: el => el.style.width || null, renderHTML: attrs => attrs.width ? { style: `width:${attrs.width}` } : {} },
    floating:{default:false,parseHTML:el=>el.dataset.tableFloating==='true',renderHTML:a=>a.floating?{'data-table-floating':'true'}:{}},
    x:{default:68,parseHTML:el=>numericAttr(el,'data-table-x',68),renderHTML:a=>({'data-table-x':a.x})},
    y:{default:64,parseHTML:el=>numericAttr(el,'data-table-y',64),renderHTML:a=>({'data-table-y':a.y})},
    // Tabla en el texto desplazada a la derecha (px): se mueve a izquierda/derecha sin taparle nada al texto
    indent:{default:0,parseHTML:el=>numericAttr(el,'data-table-indent',0),renderHTML:a=>a.indent?{'data-table-indent':a.indent,style:`margin-left:${a.indent}px`}:{}},
  }; },
  addNodeView(){return ({node})=>{
    const dom=document.createElement('div'),contentDOM=document.createElement('table');dom.className='cuaderno-table';contentDOM.className='nt table-plus';dom.append(contentDOM);
    const paint=()=>{let count=0;node.descendants(n=>{if(n.type.name==='tableRow'){let cols=0;n.forEach(c=>cols+=c.attrs.colspan||1);count=Math.max(count,cols);return false;}});const sizes=(node.attrs.columnSize||'').split(',').map(Number);dom.style.width=node.attrs.width||'100%';dom.dataset.floating=String(node.attrs.floating);dom.style.position=node.attrs.floating?'absolute':'relative';dom.style.left=node.attrs.floating?node.attrs.x+'px':'';dom.style.top=node.attrs.floating?node.attrs.y+'px':'';dom.style.margin=node.attrs.floating?'0':'';if(!node.attrs.floating&&node.attrs.indent)dom.style.marginLeft=node.attrs.indent+'px';dom.style.setProperty('--cell-percentage',(sizes.length===count&&sizes.every(n=>n>0)?sizes:Array(count).fill(100/count)).map(n=>n+'%').join(' '));};paint();
    return {dom,contentDOM,update(next){if(next.type!==node.type)return false;node=next;paint();return true;},ignoreMutation(m){return m.type!=='selection'&&(m.target===dom||m.target===contentDOM&&m.attributeName==='class');}};
  };},
});
// Celdas con color de fondo (`background`, se guarda como data-bg + background-color). La vista de tiptap-table-plus
// solo sabía de colspan; esta pinta también rowspan y el fondo.
const cellWithBackground=(Base,tag)=>Base.extend({
  addAttributes(){return {...this.parent?.(),background:{default:null,parseHTML:el=>el.getAttribute('data-bg')||el.style.backgroundColor||null,renderHTML:a=>a.background?{'data-bg':a.background,style:`background-color:${a.background}`}:{}}};},
  addNodeView(){return ({node})=>{
    const dom=document.createElement(tag);dom.style.border='1px solid var(--line)';
    const paint=n=>{const {colspan,rowspan,background}=n.attrs;dom.style.gridColumn=`auto / span ${colspan||1}`;dom.rowSpan=rowspan||1;dom.setAttribute('colspan',String(colspan||1));dom.style.backgroundColor=background||'';if(background)dom.dataset.bg=background;else delete dom.dataset.bg;};
    paint(node);
    return {dom,contentDOM:dom,update(next){if(next.type!==node.type)return false;node=next;paint(next);return true;},ignoreMutation(m){return m.type==='attributes'&&m.target===dom;}};
  };},
});
const CuadernoCell=cellWithBackground(TableCellPlus,'td'),CuadernoHeader=cellWithBackground(TableHeaderPlus,'th');
const CuadernoRow = TableRowPlus.extend({
  addAttributes() { return { ...this.parent?.(), height: { default: null, parseHTML: el => el.style.height || null, renderHTML: attrs => attrs.height ? { style: `height:${attrs.height}` } : {} } }; },
  addNodeView(){return ({node})=>{const dom=document.createElement('tr');const paint=()=>{dom.style.display='grid';dom.style.gridTemplateColumns='var(--cell-percentage)';dom.style.position='relative';dom.style.minHeight=node.attrs.height||'';};paint();return {dom,contentDOM:dom,update(next){if(next.type!==node.type)return false;node=next;paint();return true;},ignoreMutation(m){return m.type==='attributes'&&m.target===dom;}};};},
});
const Blocks = Extension.create({
  name: 'cuadernoStyles',
  addKeyboardShortcuts() { return {
    /* Listas (reglas únicas, 25-11-2026). Al pulsar espacio detrás de un símbolo al principio de una línea:
         símbolos: «-», «–» (guiones), «*», «•» (viñetas), «1.», «1)», «1-» (números), «a.», «a)» (letras).
       · Tab o espacios DELANTE del símbolo = un nivel más adentro (dentro de una lista o justo después de ella).
         1-3 espacios = 1 nivel, cada 2 espacios más (o cada Tab) = otro nivel.
       · El símbolo decide el tipo de ESE nivel: «- » tras Tab da una sublista de guiones; «1. » tras Tab, de números…
       · Sin Tab ni espacios, en medio de una lista no cambia nada (se escribe tal cual): antes «- » al empezar un
         elemento lo metía solo en una sublista, y con espacios delante no hacía nada; ahora es siempre igual.
       · Fuera de listas: «- », «1. »… empiezan una lista; en una línea sangrada, la lista toma esa sangría. */
    Space: () => {
      const {state}=this.editor,{$from,empty}=state.selection,schema=state.schema,para=$from.parent;
      if(!empty||para.type.name!=='paragraph'||$from.parentOffset!==para.content.size)return false;
      const typed=para.textBetween(0,para.content.size,'',n=>n.type.name==='tabStop'?'\t':'\u0000');
      const m=typed.match(/^([ \t ]*)([-*–•]|\d{1,3}[.)-]|[aA][.)])$/);if(!m)return false;
      const kind=listKind(m[2]),tabs=(m[1].match(/\t/g)||[]).length,spaces=m[1].length-tabs;
      let levels=tabs+(spaces?Math.max(1,Math.floor(spaces/2)):0);
      const retype=({tr})=>{   // tipo del nivel donde ha quedado la línea (solo si es su primer elemento)
        const $p=tr.selection.$from;if(!inListItem($p))return true;
        const d=$p.depth-2;if($p.index(d)!==0)return true;
        const list=$p.node(d),pos=$p.before(d);
        if(kind.ordered){const el=cssBox(list.attrs.style);el.style.removeProperty('list-style-type');tr.setNodeMarkup(pos,schema.nodes.orderedList,{start:kind.start,type:kind.type,style:el.style.cssText||null});}
        else tr.setNodeMarkup(pos,schema.nodes.bulletList,{style:withMarker(list.attrs.style,kind.dash)});
        return true;
      };
      const sink=(chain,n)=>{for(let i=0;i<n;i++)chain=chain.sinkListItem('listItem');return chain;};
      // 1) Dentro de una lista (primera línea de un elemento)
      if(inListItem($from)){
        if($from.index($from.depth-1)!==0)return false;
        const listDepth=$from.depth-2,first=$from.index(listDepth)===0;
        if(!levels&&!first)return false;   // «- » sin Tab ni espacios en medio de la lista: se escribe tal cual
        const chain=this.editor.chain().command(({tr})=>{closeHistory(tr);tr.delete($from.start(),$from.end());return true;});
        return sink(chain,levels).command(retype).scrollIntoView().run(),true;
      }
      if($from.depth!==1)return false;
      const index=$from.index(0),previous=index>0?state.doc.child(index-1):null,indent=indentOf(para.attrs.style);
      // La sangría de primera línea que Intro copia del párrafo de arriba es estilo del texto, no una orden de sangrar:
      // «1. » ahí empieza la lista en el margen (como antes). Solo cuenta la sangría puesta en esta línea (Tab…).
      const above=previous&&previous.type.name==='paragraph'?indentOf(previous.attrs.style):null;
      const inherited=above&&indent.margin<0.5&&indent.text>0.5&&Math.abs(above.text-indent.text)<0.5;
      if(!levels&&!inherited&&(indent.text>0.5||indent.margin>0.5))levels=Math.max(1,Math.round((indent.text+indent.margin)/INDENT_STEP));
      const pos=$from.before(1),clean=schema.nodes.paragraph.create({...para.attrs,style:withoutIndent(para.attrs.style)});
      // 2) Justo después de una lista, con Tab/espacios/sangría: sublista del último elemento (tantos niveles como toque)
      if(previous&&LISTS.includes(previous.type.name)&&levels){
        const chain=this.editor.chain().command(({tr})=>{
          closeHistory(tr);tr.delete(pos,pos+para.nodeSize);tr.insert(pos-1,schema.nodes.listItem.create(null,clean));
          tr.setSelection(TextSelection.create(tr.doc,pos+1));return true;});
        return sink(chain,levels).command(retype).scrollIntoView().run(),true;
      }
      // 3) Línea suelta con Tab/espacios/sangría: lista nueva con esa sangría
      if(levels){
        const style=cssBox(kind.ordered?null:withMarker(null,kind.dash));style.style.marginLeft=indentPx(levels*INDENT_STEP)+'px';
        const list=kind.ordered?schema.nodes.orderedList.create({start:kind.start,type:kind.type,style:style.style.cssText},schema.nodes.listItem.create(null,clean))
          :schema.nodes.bulletList.create({style:style.style.cssText},schema.nodes.listItem.create(null,clean));
        return this.editor.chain().command(({tr})=>{closeHistory(tr);tr.replaceWith(pos,pos+para.nodeSize,list);tr.setSelection(TextSelection.create(tr.doc,pos+3));return true;}).scrollIntoView().run();
      }
      return false;   // sin sangría: las reglas de escritura de siempre («- », «1. »…) empiezan la lista
    },
    // Mover el elemento de la lista donde está el cursor (con todo lo que cuelga de él)
    'Alt-Shift-ArrowUp': () => moveListItem(this.editor,-1),
    'Alt-Shift-ArrowDown': () => moveListItem(this.editor,1),
    // Intro en una línea vacía sangrada (fuera de listas) → vuelve al margen en vez de repetir la sangría.
    Enter: () => {
      const {$from,empty}=this.editor.state.selection,p=$from.parent;
      if(!empty||p.type.name!=='paragraph'||p.content.size||inListItem($from)||!isIndented(p.attrs.style))return false;
      return this.editor.commands.command(({tr})=>{tr.setNodeMarkup($from.before(),undefined,{...p.attrs,style:withoutIndent(p.attrs.style)});return true;});
    },
    // Retroceso al principio de una línea sangrada → quita un paso de sangría (primero la de primera línea).
    Backspace: () => {
      const {$from,empty}=this.editor.state.selection,p=$from.parent;
      if(!empty||$from.parentOffset!==0||!['paragraph','heading'].includes(p.type.name)||inListItem($from))return false;
      const {text,margin}=indentOf(p.attrs.style);if(!(text>0.5||margin>0.5))return false;
      const el=cssBox(p.attrs.style);
      if(text>0.5){const next=indentPx(text-INDENT_STEP);if(next>0.5)el.style.textIndent=next+'px';else el.style.removeProperty('text-indent');}
      else{const next=indentPx(margin-INDENT_STEP);if(next>0.5)el.style.marginLeft=next+'px';else el.style.removeProperty('margin-left');}
      return this.editor.commands.command(({tr})=>{tr.setNodeMarkup($from.before(),undefined,{...p.attrs,style:el.style.cssText||null});return true;});
    },
    Tab: () => {
      if(this.editor.isActive('table')||this.editor.isActive('codeBlock'))return false;
      if(this.editor.isActive('listItem')){if(!this.editor.commands.sinkListItem('listItem'))shiftWholeList(this.editor,1);return true;}
      const {$from,empty}=this.editor.state.selection;
      if(empty&&$from.parentOffset===0)return this.editor.commands.paragraphStyle('textIndent',(current,{dom})=>`${indentPx(lengthPx(current||getComputedStyle(dom).textIndent,dom,'textIndent')+INDENT_STEP)}px`);
      return this.editor.commands.insertContent({type:'tabStop'});
    },
    'Shift-Tab': () => {
      if(this.editor.isActive('table')||this.editor.isActive('codeBlock'))return false;
      if(this.editor.isActive('listItem')){if(!shiftWholeList(this.editor,-1))this.editor.commands.liftListItem('listItem');return true;}
      return this.editor.commands.paragraphStyle('textIndent',(current,{dom})=>`${indentPx(lengthPx(current||getComputedStyle(dom).textIndent,dom,'textIndent')-INDENT_STEP)}px`);
    },
  }; },
  addProseMirrorPlugins() { return [new Plugin({
    // «Ver espacios»: marca ↵ en cada salto de línea (Mayús+Intro), que si no se confunde con un párrafo nuevo.
    props:{decorations(state){const marks=[];state.doc.descendants((node,pos)=>{if(node.type.name==='hardBreak')marks.push(Decoration.widget(pos,()=>{const el=document.createElement('span');el.className='hb-mark';el.textContent='↵';return el;},{side:-1,key:'hb'}));});return marks.length?DecorationSet.create(state.doc,marks):null;}},
  }),new Plugin({
    // Una línea que entra en una lista (botón, «1. », «- »…) o sale de ella (Intro en línea vacía,
    // Mayús+Tab) no conserva la sangría de párrafo: la viñeta va a su sitio y el texto vuelve al margen.
    appendTransaction(transactions, oldState, newState) {
      if(!transactions.some(t=>t.docChanged)||transactions.some(t=>t.getMeta('history$')||t.getMeta('paste')||t.getMeta('uiEvent')==='paste'))return null;
      const before=inListItem(oldState.selection.$from),$now=newState.selection.$from;
      if(before===inListItem($now))return null;
      const p=$now.parent;if(!['paragraph','heading'].includes(p.type.name)||!isIndented(p.attrs.style))return null;
      // Solo la misma línea que se estaba escribiendo: nunca al cargar otro apunte (se sustituye todo).
      if(transactions.some(t=>t.steps.some(s=>s.from===0&&s.to>=t.before.content.size)))return null;
      let mapped=oldState.selection.head;for(const t of transactions)mapped=t.mapping.map(mapped);
      if(mapped<$now.start()||mapped>$now.end())return null;
      return newState.tr.setNodeMarkup($now.before(),undefined,{...p.attrs,style:withoutIndent(p.attrs.style)});
    },
  })]; },
  addGlobalAttributes() {
    return [{ types: ['paragraph', 'heading', 'blockquote', 'bulletList', 'orderedList', 'listItem', 'tableCell', 'tableHeader'], attributes: {
      style: { default: null, parseHTML: el => { const s = document.createElement('span'); s.style.cssText = el.getAttribute('style') || ''; s.style.removeProperty('text-align');
        if (/^(TD|TH|TABLE)$/.test(el.tagName)) { s.style.removeProperty('background-color'); s.style.removeProperty('margin-left'); }   // los guardan `background` e `indent`
        return s.style.cssText || null; }, renderHTML: a => a.style ? { style: a.style } : {} },
    } }, { types: ['orderedList'], attributes: { type: { default: null, parseHTML: el => el.getAttribute('type'), renderHTML: a => a.type ? { type: a.type } : {} } } }];
  },
  addInputRules() { return [
    // Justo debajo de otra lista, solo se continúa si es del mismo tipo y el número sigue la cuenta
    // («3. » bajo una lista «a) b)» o bajo «1. 2. 3.» empieza una lista nueva desde el 3).
    wrappingInputRule({ find: /^\s*(\d{1,3})[.)-]\s$/, type: this.editor.schema.nodes.orderedList, getAttributes: m => ({ start: Number(m[1]) }),
      joinPredicate: (m, node) => !node.attrs.type && (node.attrs.start || 1) + node.childCount === Number(m[1]) }),
    wrappingInputRule({ find: /^\s*a[.)]\s$/i, type: this.editor.schema.nodes.orderedList, getAttributes: m => ({ type: m[0].trim()[0] }),
      joinPredicate: () => false }),   // «a) » siempre empieza de nuevo por la a
    wrappingInputRule({ find: /^\s*[•–]\s$/, type: this.editor.schema.nodes.bulletList }),
  ]; },
  addCommands() {
    return {
      paragraphStyle: (property, value) => ({ tr, state, dispatch, view }) => {
        const blocks=selectedParagraphs(state),storedMarks=state.storedMarks;if(!blocks.length)return false;
        if(dispatch)closeHistory(tr);
        for(const {node,pos} of blocks){
          const el = document.createElement('span'); el.style.cssText = node.attrs.style || '';
          el.style[property] = typeof value === 'function' ? value(el.style[property],{node,pos,dom:view.nodeDOM(pos)}) : value;
          if (dispatch) tr.setNodeMarkup(pos, undefined, { ...node.attrs, style: el.style.cssText || null });
          if(dispatch&&property==='lineHeight')node.descendants((child,offset)=>{
            if(!child.isInline)return;
            for(const mark of child.marks){if(mark.type.name!=='textStyle'||!mark.attrs.lineHeight)continue;
              const start=pos+1+offset,attrs={...mark.attrs,lineHeight:null};tr.removeMark(start,start+child.nodeSize,mark.type);
              if(Object.values(attrs).some(v=>v!==null&&v!==''))tr.addMark(start,start+child.nodeSize,mark.type.create(attrs));
            }
          });
        }
        // setNodeMarkup clears pending typing marks. Preserve them, except for
        // the inline line-height now owned by the paragraph itself.
        if(dispatch&&storedMarks!==null)tr.setStoredMarks(storedMarks.flatMap(mark=>{
          if(property!=='lineHeight'||mark.type.name!=='textStyle'||!mark.attrs.lineHeight)return [mark];
          const attrs={...mark.attrs,lineHeight:null};return Object.values(attrs).some(v=>v!==null&&v!=='')?[mark.type.create(attrs)]:[];
        }));
        return true;
      },
    };
  },
});
const Attachment = Node.create({
  name: 'attachment', group: 'inline', inline: true, atom: true,
  addAttributes() { return {
    fid: { default: '', parseHTML: el => el.dataset.fid, renderHTML: a => ({ 'data-fid': a.fid }) },
    label: { default: '', parseHTML: el => el.textContent, renderHTML: () => ({}) },
  }; },
  parseHTML() { return [{ tag: 'span.att[data-fid]' }]; },
  renderHTML({ node, HTMLAttributes }) { return ['span', mergeAttributes(HTMLAttributes, { class: 'att', contenteditable: 'false' }), node.attrs.label]; },
});
const NoteImage = Image.extend({
  addAttributes() { return { ...this.parent?.(),
    fid: { default: null, parseHTML: el => el.dataset.fid, renderHTML: a => a.fid ? { 'data-fid': a.fid } : {} },
    style: { default: null, parseHTML: el => el.style.cssText || null, renderHTML: a => a.style ? { style: a.style } : {} },
    class: { default: 'att-img', parseHTML: el => [...el.classList].filter(c => c !== 'sel' && c !== 'grab').join(' '), renderHTML: a => ({ class: a.class || 'att-img' }) },
  }; },
  parseHTML() { return [{ tag: 'img' }]; },
  addNodeView() { return ({ node }) => {
    const img = document.createElement('img');
    const paint = current => {
      const a = current.attrs;
      const previousFid=img.dataset.fid||null;
      img.className = a.class || 'att-img'; img.style.cssText = a.style || '';
      img.alt = a.alt || ''; if (a.title) img.title = a.title;else img.removeAttribute('title');
      if (a.fid) img.dataset.fid = a.fid;else delete img.dataset.fid;
      if(!a.src&&(!a.fid||a.fid!==previousFid))img.removeAttribute('src');
      if (a.src && img.getAttribute('src') !== a.src) img.src = a.src;
    };
    paint(node);
    return { dom: img,
      update(next) { if (next.type !== node.type) return false; node = next; paint(next); return true; },
      // Loading a local blob and showing selection must not change note content/history.
      ignoreMutation(m) { return m.type === 'attributes'; },
    };
  }; },
}).configure({ allowBase64: true });
// Keep the sticky body in the document model; its controls remain outside contentDOM.
function stickySpec(HTMLAttributes) { return ['div', mergeAttributes(HTMLAttributes, { class: 'sticky', contenteditable: 'false' }),
  ['div', { class: 'st-bar', contenteditable: 'false', title: 'Arrastra la nota por aquí (puedes sacarla del folio)' },
    ['button', { type: 'button', class: 'st-col', title: 'Color de la nota' }], ['button', { type: 'button', class: 'st-x', title: 'Quitar la nota' }, '×']],
  ['div', { class: 'st-body', contenteditable: 'true' }, 0],
  ['button', { type: 'button', class: 'st-rot', title: 'Arrastra para girar la nota', contenteditable: 'false' }, '↻'],
  ['button', { type: 'button', class: 'st-size', title: 'Tamaño: arrastra hacia fuera para agrandar la nota y hacia dentro para hacerla más pequeña', contenteditable: 'false' }, '⤢'],
]; }
const Sticky = Node.create({
  name: 'sticky', group: 'block', content: 'block+', isolating: true, selectable: false,
  addAttributes() { return {
    col: { default: 'amarillo', parseHTML: el => el.dataset.col, renderHTML: a => ({ 'data-col': a.col }) },
    style: { default: '', parseHTML: el => el.style.cssText || '', renderHTML: a => ({ style: a.style || '' }) },
  }; },
  parseHTML() { return [{ tag: 'div.sticky', contentElement: '.st-body' }]; },
  renderHTML({ HTMLAttributes }) { return stickySpec(HTMLAttributes); },
  addNodeView() { return ({ node }) => {
    const { dom, contentDOM } = DOMSerializer.renderSpec(document, stickySpec({ style: node.attrs.style, 'data-col': node.attrs.col }));
    return { dom, contentDOM,
      update(next) { if (next.type !== node.type) return false; node = next; dom.style.cssText = next.attrs.style || ''; dom.dataset.col = next.attrs.col; return true; },
      ignoreMutation(m) { return m.type !== 'selection' && (m.target === dom || !contentDOM.contains(m.target)); },
    };
  }; },
});

function inertBody(html){
  const doc=new DOMParser().parseFromString(String(html||''),'text/html'),box=doc.body;
  box.querySelectorAll('script,style,iframe,object,embed,link,meta,base').forEach(el=>el.remove());
  for(const el of box.querySelectorAll('*'))for(const attr of [...el.attributes]){
    if(/^on/i.test(attr.name)||attr.name==='srcdoc'||['href','src','xlink:href'].includes(attr.name)&&/^(?:javascript|vbscript):/i.test(attr.value.replace(/[\u0000-\u0020]/g,'')))el.removeAttribute(attr.name);
  }
  return box;
}
function legacyHTML(html) {
  // Parsing in the live document starts image requests and may execute onerror,
  // even when the temporary DIV has never been attached to the page.
  const box=inertBody(html),doc=box.ownerDocument;
  // Chromium's old formatBlock/indent output. Preserve inherited formatting on the leaves.
  for (const div of [...box.querySelectorAll('div:not(.sticky):not(.sticky *)')].reverse()) {
    const p = doc.createElement('p');
    for (const attr of div.attributes) p.setAttribute(attr.name, attr.value);
    if (div.querySelector('p,div,h1,h2,h3,h4,ul,ol,table,blockquote')) {
      for (const child of div.children) {
        // Only inherited text styles cascade. Copying container margins/heights
        // onto every child manufactured paragraph gaps in legacy documents.
        for(const property of ['color','font-family','font-size','font-weight','font-style','line-height','text-align','text-indent','letter-spacing'])if(div.style.getPropertyValue(property)&&!child.style.getPropertyValue(property))child.style.setProperty(property,div.style.getPropertyValue(property));
        if(div.style.marginLeft)child.style.marginLeft=child.style.marginLeft?`calc(${div.style.marginLeft} + ${child.style.marginLeft})`:div.style.marginLeft;
        if (div.getAttribute('align') && !child.style.textAlign) child.style.textAlign = div.getAttribute('align');
      }
      // Keep a container's outer spacing once, at the corresponding edge.
      for(const [property,child] of [['marginTop',div.firstElementChild],['marginBottom',div.lastElementChild]])if(child&&div.style[property])child.style[property]=child.style[property]?`max(${div.style[property]}, ${child.style[property]})`:div.style[property];
      div.replaceWith(...div.childNodes);
    } else { if(!div.style.marginBottom&&!div.style.margin)p.style.marginBottom='0';p.append(...div.childNodes); div.replaceWith(p); }
  }
  for (const font of box.querySelectorAll('font')) {
    const span = doc.createElement('span'); span.style.cssText = font.style.cssText;
    if (font.face) span.style.fontFamily = font.face;
    if (font.color) span.style.color = font.color;
    if (font.size) span.style.fontSize = `${[0, 8, 10, 12, 14, 18, 24, 36][Number(font.size)] || 12}pt`;
    span.append(...font.childNodes); font.replaceWith(span);
  }
  for (const el of box.querySelectorAll('[align]')) { el.style.textAlign = el.style.textAlign || el.getAttribute('align'); el.removeAttribute('align'); }
  for(const table of box.querySelectorAll('table[data-column-size]')){
    const sizes=(table.dataset.columnSize||'').split(',').map(Number);if(!sizes.length||sizes.some(n=>!Number.isFinite(n)||n<=0))continue;
    const width=parseFloat(table.style.width)||658;
    for(const row of table.rows){let col=0;for(const cell of row.cells){const span=cell.colSpan||1;cell.setAttribute('colwidth',sizes.slice(col,col+span).map(n=>Math.round(width*n/100)).join(','));col+=span;}}
  }
  return box.innerHTML;
}

window.CuadernoEditor = {safeHTML:html=>inertBody(html).innerHTML, mount(old) {
  const viewport = document.createElement('div'); viewport.className = 'page-viewport';
  const stage = document.createElement('div'); stage.className = 'page-stage';
  const sheets = document.createElement('div'); sheets.className = 'page-sheets'; sheets.setAttribute('aria-hidden', 'true');
  const host = document.createElement('div'); host.className = 'editor-host';
  const runningRegions=document.createElement('div');runningRegions.className='page-running-regions';
  old.replaceWith(viewport); viewport.append(stage); stage.append(sheets, host, runningRegions);
  let loading = false, notifyPending = false, layoutFrame = 0, zoom = 'fit', editor, original = '', dirty = false, generation = 0,serialized=null;
  let runningHeader='',runningFooter='',regionChange=null;
  let session=null;   // trabajo en grupo abierto (beta)
  const track=()=>{if(!session||!session.ready||loading)return;   // nunca antes de que el editor muestre el documento del grupo
    session.doc.transact(()=>updateYFragment(session.doc,session.doc.getXmlFragment('doc'),editor.state.doc,{mapping:session.mapping,isOMark:new Map()}));};
  const yHTML=()=>getHTMLFromFragment(yXmlFragmentToProseMirrorRootNode(session.doc.getXmlFragment('doc'),editor.schema).content,editor.schema);
  const regionValue=field=>field==='header'?runningHeader:runningFooter;
  function allowFloatingNotes(){
    const stageRect=stage.getBoundingClientRect(),scale=stageRect.width/PAGE.width;if(!scale)return;
    const holes=[];
    for(const el of editor.view.dom.querySelectorAll('.sticky,.st-pal,.cuaderno-table[data-floating="true"]')){const r=el.getBoundingClientRect();if(!r.width||!r.height)continue;let box={l:Math.max(0,(r.left-stageRect.left)/scale-3),t:Math.max(0,(r.top-stageRect.top)/scale-3),r:Math.min(PAGE.width,(r.right-stageRect.left)/scale+3),b:(r.bottom-stageRect.top)/scale+3};if(box.r<=box.l)continue;
      for(let i=holes.length-1;i>=0;i--){const other=holes[i];if(box.l<=other.r&&box.r>=other.l&&box.t<=other.b&&box.b>=other.t){box={l:Math.min(box.l,other.l),t:Math.min(box.t,other.t),r:Math.max(box.r,other.r),b:Math.max(box.b,other.b)};holes.splice(i,1);i=holes.length;}}
      holes.push(box);
    }
    const rect=(l,t,r,b)=>`M${l} ${t}H${r}V${b}H${l}Z`,height=Math.max(PAGE.height,runningRegions.children.length*(PAGE.height+PAGE.gap));
    runningRegions.style.clipPath=holes.length?'path(evenodd, "'+rect(0,0,PAGE.width,height)+' '+holes.map(b=>rect(b.l,b.t,b.r,b.b)).join(' ')+'")':'';
  }
  function paintRunningRegions(count){
    while(runningRegions.children.length>count)runningRegions.lastElementChild.remove();
    while(runningRegions.children.length<count){
      const page=document.createElement('div');page.className='page-running-page';
      for(const field of ['header','footer']){
        const region=document.createElement('div');region.className='page-running-region page-running-'+field;region.dataset.field=field;
        const input=document.createElement('textarea');input.className='page-running-input';input.dataset.field=field;input.dataset.noi18n='';input.rows=1;input.maxLength=240;input.spellcheck=true;input.autocomplete='off';input.value=regionValue(field);
        region.append(input);page.append(region);
        region.addEventListener('pointerdown',event=>{if(event.target!==input){event.preventDefault();input.focus();}});
        input.addEventListener('focus',()=>{region.classList.add('editing');stage.classList.add('editing-page-region');});
        input.addEventListener('blur',()=>{region.classList.remove('editing');stage.classList.remove('editing-page-region');input.scrollTop=0;});
        input.addEventListener('input',()=>{if(field==='header')runningHeader=input.value;else runningFooter=input.value;for(const other of runningRegions.querySelectorAll('.page-running-input'))if(other!==input&&other.dataset.field===field)other.value=input.value;regionChange?.(field,input.value);});
        input.addEventListener('keydown',event=>{if(event.key==='Escape'||((event.ctrlKey||event.metaKey)&&event.key==='Enter')){event.preventDefault();editor.commands.focus();}});
      }
      const number=document.createElement('span');number.className='page-running-number';page.append(number);runningRegions.append(page);
    }
    const ca=document.documentElement.lang==='ca';
    const signature=[count,runningHeader,runningFooter,ca].join('\u0001');if(runningRegions.dataset.signature===signature)return;runningRegions.dataset.signature=signature;
    [...runningRegions.children].forEach((page,index)=>{page.style.top=`${index*(PAGE.height+PAGE.gap)}px`;page.querySelector('.page-running-number').textContent=String(index+1);for(const region of page.querySelectorAll('.page-running-region')){const field=region.dataset.field,label=field==='header'?(ca?'Capçalera de pàgina':'Encabezado de página'):(ca?'Peu de pàgina':'Pie de página'),input=region.querySelector('textarea');region.dataset.label=label;input.placeholder=label;input.setAttribute('aria-label',label+' · '+(index+1));input.lang=ca?'ca':'es';if(document.activeElement!==input)input.value=regionValue(field);}});
  }
  const notify = () => {
    if (loading || notifyPending) return;
    notifyPending = true;
    const current = generation;
    queueMicrotask(() => { notifyPending = false; if (!loading && current === generation) editor.view.dom.dispatchEvent(new Event('input', { bubbles: true })); });
  };
  const layout = () => {
    if(layoutFrame)return;
    layoutFrame = requestAnimationFrame(() => {
      layoutFrame=0;
      if (!host.offsetWidth) return;
      const count = Math.max(1, editor.view.dom.querySelectorAll('.rm-page-break').length);
      runningRegions.style.color=getComputedStyle(editor.view.dom).color;
      const empty=String(editor.isEmpty);if(editor.view.dom.dataset.empty!==empty)editor.view.dom.dataset.empty=empty;
      while (sheets.children.length > count) sheets.lastElementChild.remove();
      while (sheets.children.length < count) { const page = document.createElement('div'); page.className = 'page-sheet'; sheets.append(page); }
      paintRunningRegions(count);
      [...sheets.children].forEach((page, i) => { page.style.top = `${i * (PAGE.height + PAGE.gap)}px`; });
      const scale = zoom === 'fit' ? Math.min(1, viewport.clientWidth / PAGE.width) : Number(zoom) / 100;
      stage.style.zoom = String(Math.max(.25, scale));
      allowFloatingNotes();
      const label = document.getElementById('pageCount');
      if (label) { const ca = document.documentElement.lang === 'ca'; label.textContent = count + (count === 1 ? (ca ? ' pàgina' : ' página') : (ca ? ' pàgines' : ' páginas')); }
      const pct = document.getElementById('pageZoomValue'); if (pct) pct.textContent = `${Math.round(scale * 100)} %`;
    });
  };
  editor = new Editor({
    element: host, injectCSS: true, content: '<p></p>',
    editorProps: { attributes: { id: 'editor', class: 'editor', spellcheck: 'true', 'aria-label': 'Texto del apunte', 'data-placeholder': 'Empieza a escribir…' },transformPastedHTML:legacyHTML },
    extensions: [
      StarterKit.configure({ heading: { levels: [1, 2, 3, 4] }, link: { openOnClick: false },listItem:false }),CuadernoListItem,
      TextStyleKit.configure({ backgroundColor: false }), Blocks,TabStop,
      TextAlign.configure({ types: ['heading', 'paragraph'], defaultAlignment: null }),
      Highlight.extend({ parseHTML() { return [{ tag: 'mark' }, { style: 'background-color', getAttrs: color => ({ color }) }]; } }).configure({ multicolor: true }), NoteImage, Attachment, Sticky,
      CuadernoTable.configure({ HTMLAttributes: { class: 'nt' }, borderColor:'var(--line)' }), CuadernoRow, CuadernoCell, CuadernoHeader, TableSelection,
      PaginationPlus.configure({ pageWidth: PAGE.width, pageHeight: PAGE.height, pageGap: PAGE.gap,
        marginTop: 64, marginBottom: 44, marginLeft: 68, marginRight: 68,
        contentMarginTop: 0, contentMarginBottom: 12, pageGapBorderSize: 0, pageGapBorderColor: 'transparent',
        pageBreakBackground: 'var(--surface)', headerLeft: '', headerRight: '', footerLeft: '', footerRight: '',
      }),
    ],
    onUpdate: () => { if (!loading) dirty = true; serialized=null;track();notify(); layout(); },
    onSelectionUpdate: () => document.dispatchEvent(new Event('selectionchange')),
    onTransaction: ({transaction}) => {if(transaction.docChanged)layout();},
  });
  const observer = new MutationObserver(layout); observer.observe(editor.view.dom, { childList: true, subtree: true,attributes:true,attributeFilter:['data-paper'] });
  editor.view.dom.addEventListener('dblclick', event => {
    // Native markers live outside the LI box; Chromium can target the OL/UL
    // instead of the item, especially after changing a number into a bullet.
    const hitsMarker=li=>{
      const r=li.getBoundingClientRect(),scale=r.width/(li.offsetWidth||r.width||1),css=getComputedStyle(li),line=(parseFloat(css.lineHeight)||parseFloat(css.fontSize)*1.5)*scale;
      return event.clientX>=r.left-40*scale&&event.clientX<=r.left+4&&event.clientY>=r.top&&event.clientY<=Math.min(r.bottom,r.top+line);
    };
    const direct=event.target.closest('li'),item=direct&&hitsMarker(direct)?direct:[...editor.view.dom.querySelectorAll('li')].reverse().find(hitsMarker);
    if (!item || !editor.view.dom.contains(item) || event.clientX > item.getBoundingClientRect().left + 4) return;
    const list = item.parentElement;
    if (!list.matches('ul,ol')) return;
    event.preventDefault();
    const position = editor.view.posAtDOM(item, 0) - 1, original = editor.state.doc.nodeAt(position);
    if (!original || original.type.name!=='listItem') return;
    const ca = document.documentElement.lang === 'ca', dialog = document.createElement('dialog');
    dialog.setAttribute('aria-label', ca ? 'Símbol de la llista' : 'Símbolo de la lista');
    dialog.style.cssText = 'border:1px solid var(--line);border-radius:18px;padding:20px;background:var(--surface);color:var(--ink);max-width:320px';
    const label = document.createElement('p'); label.textContent = ca?'Canvia només este element':'Cambiar solo este elemento'; dialog.append(label);
    const apply=(marker,value=null,format={})=>{
      if(editor.state.doc.nodeAt(position)!==original)return;
      const style=document.createElement('span');style.style.cssText=original.attrs.style||'';if(marker!==null)style.style.listStyleType=marker;
      if(value!==null){if(list.tagName==='UL')style.style.counterSet='list-item '+value;else style.style.removeProperty('counter-set');}
      const tr=editor.state.tr;if(value!==null&&list.tagName==='OL'){
        let number=numericAttr(list,'start',1);for(const sibling of list.children){if(sibling===item)break;if(sibling.hasAttribute('value'))number=Number(sibling.getAttribute('value'));number++;}
        if(item.hasAttribute('value'))number=Number(item.getAttribute('value'));
        const next=editor.state.doc.nodeAt(position+original.nodeSize);if(next?.type.name==='listItem'&&next.attrs.value===null)tr.setNodeMarkup(position+original.nodeSize,undefined,{...next.attrs,value:number+1});
      }
      tr.setNodeMarkup(position,undefined,{...original.attrs,...format,style:style.style.cssText||null,value:value??original.attrs.value});editor.view.dispatch(closeHistory(tr));dialog.close();editor.commands.focus();
    };
    const formatRow=document.createElement('div');formatRow.style.cssText='display:flex;gap:8px;margin:10px 0 14px';
    for(const [attr,text] of [['markerBold',ca?'Negreta':'Negrita'],['markerItalic',ca?'Cursiva':'Cursiva']]){
      const button=document.createElement('button');button.type='button';button.className='btn';button.textContent=text;button.setAttribute('aria-label',text+(ca?' del marcador':' del marcador'));button.setAttribute('aria-pressed',String(original.attrs[attr]));button.style[attr==='markerBold'?'fontWeight':'fontStyle']=attr==='markerBold'?'700':'italic';button.onclick=()=>apply(null,null,{[attr]:!original.attrs[attr]});formatRow.append(button);
    }dialog.append(formatRow);
    // Cambiar el orden: el elemento sube o baja con sus subelementos (también Alt+Mayús+↑/↓ con el cursor dentro)
    const orderRow=document.createElement('div');orderRow.style.cssText='display:flex;gap:8px;align-items:center;margin:0 0 14px';
    const orderLabel=document.createElement('span');orderLabel.textContent=ca?'Ordre:':'Orden:';orderLabel.style.marginRight='4px';orderRow.append(orderLabel);
    const siblingsCount=list.children.length,itemIndex=[...list.children].indexOf(item);
    for(const [dir,text] of [[-1,ca?'↑ Puja':'↑ Subir'],[1,ca?'↓ Baixa':'↓ Bajar']]){
      const button=document.createElement('button');button.type='button';button.className='btn';button.textContent=text;
      button.disabled=dir<0?itemIndex<=0:itemIndex>=siblingsCount-1;button.title=ca?'També amb Alt+Maj+fletxa':'También con Alt+Mayús+flecha';
      button.onclick=()=>{if(editor.state.doc.nodeAt(position)!==original)return;editor.view.dispatch(editor.state.tr.setSelection(TextSelection.create(editor.state.doc,position+2)));moveListItem(editor,dir);dialog.close();editor.commands.focus();};
      orderRow.append(button);
    }
    dialog.append(orderRow);
    for (const [name, ordered, type, marker] of [['1. 2. 3.',true,'1','decimal'],['a. b. c.',true,'a','lower-alpha'],['I. II. III.',true,'I','upper-roman'],['•',false,null,'disc'],['◦',false,null,'circle'],['▪',false,null,'square'],['—',false,null,'"—  "']]) {
      const button = document.createElement('button'); button.type = 'button'; button.textContent = name; button.className = 'btn'; button.style.margin = '4px';
      button.onclick = () => {
        apply(marker);
      }; dialog.append(button);
    }
    const numberRow=document.createElement('form');numberRow.style.cssText='display:flex;gap:8px;align-items:center;margin:14px 0;flex-wrap:wrap';
    const numberLabel=document.createElement('label');numberLabel.textContent=ca?'Número d’este element':'Número de este elemento';const numberInput=document.createElement('input');numberInput.type='number';numberInput.min='0';numberInput.max='99999';numberInput.setAttribute('aria-label',numberLabel.textContent);numberInput.style.cssText='width:76px;padding:7px;border:1px solid var(--line);border-radius:7px;background:var(--surface);color:var(--ink)';
    let number=numericAttr(list,'start',1);for(const sibling of list.children){if(sibling.hasAttribute('value'))number=Number(sibling.getAttribute('value'));if(sibling===item)break;number++;}numberInput.value=String(number);numberLabel.append(numberInput);const setNumber=document.createElement('button');setNumber.type='submit';setNumber.className='btn primary';setNumber.textContent=ca?'Aplica el número':'Aplicar número';numberRow.append(numberLabel,setNumber);numberRow.onsubmit=e=>{e.preventDefault();const value=Number(numberInput.value);if(Number.isInteger(value)&&value>=0&&value<=99999)apply('decimal',value);};dialog.append(numberRow);
    const close = document.createElement('button'); close.className = 'btn'; close.textContent = ca ? 'Tancar' : 'Cerrar'; close.onclick = () => dialog.close(); dialog.append(close);
    dialog.addEventListener('close', () => dialog.remove(), { once: true }); document.body.append(dialog); dialog.showModal();
  });
  new ResizeObserver(layout).observe(viewport);
  new MutationObserver(layout).observe(document.documentElement, { attributes: true, attributeFilter: ['lang', 'data-theme','style'] });

  const domSelection = () => {
    if (!(editor.state.selection instanceof TextSelection)) return;
    const sel = getSelection(); if (!sel.rangeCount || !editor.view.dom.contains(sel.anchorNode)) return;
    try {
      const from = editor.view.posAtDOM(sel.anchorNode, sel.anchorOffset), to = editor.view.posAtDOM(sel.focusNode, sel.focusOffset);
      if (from !== editor.state.selection.anchor || to !== editor.state.selection.head) editor.view.dispatch(editor.state.tr.setSelection(TextSelection.between(editor.state.doc.resolve(from), editor.state.doc.resolve(to))));
    } catch (_) { /* A removed attachment can leave a stale DOM range. */ }
  };
  const sync = () => {
    editor.view.domObserver.flush();
    // Floating object tools edit their DOM during pointer movement; commit once on release.
    const changes = [];
    editor.state.doc.descendants((node, pos) => {
      if (!['image', 'sticky'].includes(node.type.name)) return;
      const dom = editor.view.nodeDOM(pos); if (!dom?.isConnected) return;
      const attrs = { ...node.attrs, style: dom.getAttribute('style') || null };
      if (node.type.name === 'sticky') attrs.col = dom.dataset.col || 'amarillo';
      if (attrs.style !== (node.attrs.style || null) || attrs.col !== node.attrs.col) changes.push({ pos, node, attrs });
    });
    let tr = editor.state.tr;
    for (const { pos, node, attrs } of changes) if (tr.doc.nodeAt(pos)?.type === node.type) tr.setNodeMarkup(pos, undefined, attrs);
    if (tr.docChanged) editor.view.dispatch(tr);
    domSelection();
  };
  const targetNode = el => {
    if(!el||!editor.view.dom.contains(el))return null;
    let found;
    editor.state.doc.descendants((node,pos)=>{const dom=editor.view.nodeDOM(pos);if(!dom||!(dom===el||dom.contains(el)))return false;found={node,pos,dom};return dom!==el;});
    return found;
  };
  /* Ayudas de tablas (26-11-2026, para tableShift/tableSize/tableBackground/tableInfo). */
  const CELL_TYPES=['tableCell','tableHeader'];
  // Celda donde está el cursor (o la primera de una selección de celdas): tabla, posición, fila, columna y desplazamiento.
  const currentCell=()=>{
    const sel=editor.state.selection;
    if(sel instanceof CellSelection){   // $anchorCell queda justo antes de la celda
      const $c=sel.$anchorCell,cell=$c.nodeAfter,tableDepth=$c.depth-1,table=$c.node(tableDepth);
      if(!cell||!CELL_TYPES.includes(cell.type.name)||table?.type.name!=='table')return null;
      return {table,tablePos:$c.before(tableDepth),r:$c.index(tableDepth),c:$c.index(),cellPos:$c.pos,cell,offset:1};
    }
    const $p=sel.$from;
    for(let d=$p.depth;d>1;d--){
      const node=$p.node(d);if(!CELL_TYPES.includes(node.type.name))continue;
      const table=$p.node(d-2);if(table?.type.name!=='table')return null;
      const cellPos=$p.before(d);
      return {table,tablePos:$p.before(d-2),r:$p.index(d-2),c:$p.index(d-1),cellPos,cell:node,offset:Math.max(1,sel.from-cellPos)};
    }
    return null;
  };
  // Celdas combinadas: mover columnas o cambiar el número de columnas las descuadraría.
  const hasSpans=table=>{let spans=false;table.descendants(n=>{if(CELL_TYPES.includes(n.type.name)){if((n.attrs.colspan||1)>1||(n.attrs.rowspan||1)>1)spans=true;return false;}});return spans;};
  const dirOf=kind=>kind==='rowUp'||kind==='colLeft'?-1:1;
  // La fila con todas sus celdas del tipo pedido (título o celda normal), sin perder contenido ni atributos.
  const retypeRow=(row,typeName,schema)=>{const type=schema.nodes[typeName];return row.copy(Fragment.fromArray(row.content.content.map(cell=>cell.type===type?cell:type.create(cell.attrs,cell.content,cell.marks))));};
  // Cambia la tabla entera en una sola transacción (Deshacer la devuelve de una vez) y deja el cursor en la celda (r,c).
  const replaceTable=(table,tablePos,next,r,c,offset=1)=>{
    const tr=editor.state.tr.replaceWith(tablePos,tablePos+table.nodeSize,next);
    let pos=tablePos+1;const row=Math.max(0,Math.min(r,next.childCount-1));
    for(let i=0;i<row;i++)pos+=next.child(i).nodeSize;
    const rowNode=next.child(row),col=Math.max(0,Math.min(c,rowNode.childCount-1));pos+=1;
    for(let j=0;j<col;j++)pos+=rowNode.child(j).nodeSize;
    const cell=rowNode.child(col),inside=Math.min(pos+Math.max(1,offset),pos+cell.nodeSize-1);
    try{tr.setSelection(TextSelection.near(tr.doc.resolve(inside)));}catch(_){tr.setSelection(TextSelection.near(tr.doc.resolve(pos+1)));}
    editor.view.dispatch(closeHistory(tr));editor.view.focus({preventScroll:true});return true;   // sin desplazar: la tabla ya está a la vista
  };
  const move = (el, ref, after) => {
    sync();const from=targetNode(el),target=targetNode(ref);if(!from||!target||from.pos===target.pos||target.pos>from.pos&&target.pos<from.pos+from.node.nodeSize)return false;
    try{
      const tr=editor.state.tr.delete(from.pos,from.pos+from.node.nodeSize),to=tr.mapping.map(target.pos+(after?target.node.nodeSize:0));
      tr.insert(to,from.node);tr.doc.check();tr.setSelection(TextSelection.near(tr.doc.resolve(Math.min(to+1,tr.doc.content.size))));editor.view.dispatch(closeHistory(tr));return true;
    }catch(_){return false;}
  };
  const command = (cmd, value) => {
    sync(); const chain = editor.chain().focus();
    const names = { bold: 'toggleBold', italic: 'toggleItalic', underline: 'toggleUnderline', strike: 'toggleStrike', insertUnorderedList: 'toggleBulletList', insertOrderedList: 'toggleOrderedList', undo: 'undo', redo: 'redo', hr: 'setHorizontalRule' };
    if (names[cmd]) return chain[names[cmd]]().run();
    if (cmd === 'fontName') return chain.setFontFamily(value).run();
    if (cmd === 'fontSize') return chain.setFontSize(`${value}pt`).run();
    if (cmd === 'color') return value ? chain.setColor(value).run() : chain.unsetColor().run();
    if (cmd === 'mark') return chain.toggleHighlight({ color: '#ffe36e' }).run();
    if (cmd === 'lineHeight') return chain.paragraphStyle('lineHeight', value).run();
    if (cmd === 'spaceAfter') return chain.paragraphStyle('marginTop','0px').paragraphStyle('marginBottom', `${value}pt`).run();
    if (cmd === 'firstLine') {
      const blocks=selectedParagraphs(editor.state),remove=blocks.length&&blocks.every(({pos})=>lengthPx(getComputedStyle(editor.view.nodeDOM(pos)).textIndent,editor.view.nodeDOM(pos),'textIndent')>0);
      return chain.paragraphStyle('textIndent', remove?'0px':'1.25cm').run();
    }
    if (cmd === 'indent' || cmd === 'outdent') {
      if (editor.isActive('listItem')) return chain[cmd === 'indent' ? 'sinkListItem' : 'liftListItem']('listItem').run();
      return chain.paragraphStyle('marginLeft', (current,{dom}) => `${indentPx(lengthPx(getComputedStyle(dom).marginLeft,dom)+(cmd==='indent'?INDENT_STEP:-INDENT_STEP))}px`).run();
    }
    const align = { justifyLeft: 'left', justifyCenter: 'center', justifyRight: 'right', justifyFull: 'justify' }[cmd];
    if (align) return chain.setTextAlign(editor.isActive({ textAlign: align }) && align !== 'left' ? 'left' : align).run();
    if (cmd === 'removeFormat') return chain.unsetAllMarks().clearNodes().paragraphStyle('lineHeight', '').paragraphStyle('marginLeft', '').paragraphStyle('textIndent', '').paragraphStyle('marginBottom', '').unsetTextAlign().run();
    return false;
  };
  const api = {
    editor, sync, command, layout, move,
    remove(el) {sync();const found=targetNode(el);return found&&['image','table','sticky','attachment'].includes(found.node.type.name)?editor.chain().command(({tr})=>{closeHistory(tr);return true;}).deleteRange({from:found.pos,to:found.pos+found.node.nodeSize}).run():false;},
    blockDOM(el) {const found=targetNode(el);return found?.node.isBlock?found.dom:el?.closest('p,h1,h2,h3,h4,li,blockquote')||null;},
    moveStep(el, dir) {
      sync();const current=targetNode(el);if(!current||![1,-1].includes(dir))return false;
      const $pos=editor.state.doc.resolve(current.pos),nodes=[];$pos.parent.forEach((node,offset)=>{const pos=$pos.start()+offset;nodes.push({node,pos,dom:editor.view.nodeDOM(pos)});});
      const index = nodes.findIndex(n => n.pos === current.pos), target = nodes[index + dir];
      return target ? move(el, target.dom, dir > 0) : false;
    },
    load(html) {
      if(runningRegions.contains(document.activeElement))document.activeElement.blur();
      loading = true; generation++; original = html || ''; dirty = false;serialized=null;
      try {
        editor.commands.setContent(legacyHTML(html), { emitUpdate: false });
        // History belongs to one note: Cmd+Z must never bring another note's text back.
        editor.view.updateState(EditorState.create({ schema: editor.schema, doc: editor.state.doc, plugins: editor.state.plugins }));
      } finally { loading = false; }
      if(session){session.mapping=new Map();session.ready=true;track();}   // el documento cargado pasa a ser la base de los cambios
      layout();
    },
    html() { sync();if(!dirty)return original.replace(/\u200b/g,'');return serialized??(serialized=editor.getHTML().replace(/\u200b/g,'')); },
    block(tag) { sync(); const c = editor.chain().focus(); return tag === 'blockquote' ? c.toggleBlockquote().run() : /^h[1-4]$/.test(tag) ? c.toggleHeading({ level: Number(tag[1]) }).run() : c.setParagraph().run(); },
    table(rows, cols) { sync(); return editor.chain().focus().insertTable({ rows, cols, withHeaderRow: true }).run(); },
    tablePosition(el,x,y,width){const found=targetNode(el);if(!found||found.node.type.name!=='table'||x!==null&&(!Number.isFinite(x)||!Number.isFinite(y))||width!==undefined&&(!Number.isFinite(width)||width<=0))return false;const attrs={...found.node.attrs,floating:x!==null,x:x??found.node.attrs.x,y:y??found.node.attrs.y,width:width?Math.round(width)+'px':found.node.attrs.width};editor.view.dispatch(closeHistory(editor.state.tr.setNodeMarkup(found.pos,undefined,attrs)));return true;},
    tableGeometry(el, widths, heights) {
      const found=targetNode(el);if(!found||found.node.type.name!=='table')return false;
      const {node,pos}=found,tr=editor.state.tr;
      if(widths&&(!Array.isArray(widths)||!widths.length||widths.some(w=>!Number.isFinite(w)||w<=0))||heights&&(!Array.isArray(heights)||heights.length!==node.childCount||heights.some(h=>!Number.isFinite(h)||h<=0)))return false;
      if(widths){const total=widths.reduce((a,b)=>a+b,0);tr.setNodeMarkup(pos,undefined,{...node.attrs,width:Math.round(total)+'px',columnSize:widths.map(w=>w*100/total).join(',')});let column=0;
        node.descendants((cell,offset)=>{if(cell.type.name==='tableRow')column=0;if(!['tableCell','tableHeader'].includes(cell.type.name))return;const span=cell.attrs.colspan||1;tr.setNodeMarkup(pos+1+offset,undefined,{...cell.attrs,colwidth:widths.slice(column,column+span).map(Math.round)});column+=span;});}
      if(heights){let index=0;node.descendants((row,offset)=>{if(row.type.name!=='tableRow')return;if(heights[index])tr.setNodeMarkup(pos+1+offset,undefined,{...row.attrs,height:Math.round(heights[index])+'px'});index++;});}
      editor.view.dispatch(closeHistory(tr));return true;
    },
    /* Tablas (25-11-2026): todo en una sola transacción, para que Deshacer lo devuelva de una vez. */
    // Marco: tamaño (anchos de columna / altos de fila en px), suelta o en el texto, posición y sangría.
    tableFrame(el,{widths=null,heights=null,floating,x,y,indent}={}){
      const found=targetNode(el);if(!found||found.node.type.name!=='table')return false;
      const {node,pos}=found,tr=editor.state.tr,attrs={...node.attrs};
      if(widths&&(!Array.isArray(widths)||!widths.length||widths.some(w=>!Number.isFinite(w)||w<=0)))return false;
      if(heights&&(!Array.isArray(heights)||heights.length!==node.childCount||heights.some(h=>!Number.isFinite(h)||h<=0)))return false;
      if(widths){const total=widths.reduce((a,b)=>a+b,0);attrs.width=Math.round(total)+'px';attrs.columnSize=widths.map(w=>w*100/total).join(',');}
      if(floating!==undefined)attrs.floating=!!floating;
      if(Number.isFinite(x))attrs.x=Math.round(x);if(Number.isFinite(y))attrs.y=Math.round(y);
      if(Number.isFinite(indent))attrs.indent=Math.max(0,Math.round(indent));
      tr.setNodeMarkup(pos,undefined,attrs);
      if(widths){let column=0;node.descendants((cell,offset)=>{if(cell.type.name==='tableRow')column=0;if(!['tableCell','tableHeader'].includes(cell.type.name))return;const span=cell.attrs.colspan||1;tr.setNodeMarkup(pos+1+offset,undefined,{...cell.attrs,colwidth:widths.slice(column,column+span).map(Math.round)});column+=span;});}
      if(heights){let index=0;node.descendants((row,offset)=>{if(row.type.name!=='tableRow')return;tr.setNodeMarkup(pos+1+offset,undefined,{...row.attrs,height:Math.round(heights[index])+'px'});index++;});}
      editor.view.dispatch(closeHistory(tr));return true;
    },
    // Mover la fila o la columna donde está el cursor: 'rowUp' | 'rowDown' | 'colLeft' | 'colRight'.
    // La fila de títulos se queda arriba (las celdas cambian de tipo si una fila sube a ese sitio).
    tableShift(kind){
      const at=currentCell();if(!at)return 'nocell';const {table,tablePos,r,c,offset}=at,schema=editor.schema;
      if(hasSpans(table))return 'spans';
      const rows=[...table.content.content],row=dirOf(kind),isRow=kind.startsWith('row');
      if(isRow){
        const j=r+row;if(j<0||j>=rows.length)return 'edge';
        const header=rows.map(x=>x.childCount&&x.content.content.every(cell=>cell.type.name==='tableHeader'));
        [rows[r],rows[j]]=[rows[j],rows[r]];
        for(const i of [r,j])rows[i]=retypeRow(rows[i],header[i]?'tableHeader':'tableCell',schema);
        return replaceTable(table,tablePos,table.copy(Fragment.fromArray(rows)),j,c,offset);
      }
      const j=c+row;if(j<0||j>=rows[0].childCount)return 'edge';
      const next=rows.map(x=>{const cells=[...x.content.content];[cells[c],cells[j]]=[cells[j],cells[c]];
        // el tipo (título o celda) se queda en su sitio: en la primera columna/fila no se mezclan
        const types=x.content.content.map(cell=>cell.type);return x.copy(Fragment.fromArray(cells.map((cell,i)=>cell.type===types[i]?cell:types[i].create(cell.attrs,cell.content,cell.marks))));});
      const sizes=String(table.attrs.columnSize||'').split(',');const attrs={...table.attrs};
      if(sizes.length===rows[0].childCount){[sizes[c],sizes[j]]=[sizes[j],sizes[c]];attrs.columnSize=sizes.join(',');}
      return replaceTable(table,tablePos,schema.nodes.table.create(attrs,Fragment.fromArray(next),table.marks),r,j,offset);
    },
    // Número de filas y columnas. Si se quitaría texto, devuelve 'lost' y no hace nada (salvo force).
    tableSize(rowsWanted,colsWanted,force=false){
      const at=currentCell();if(!at)return 'nocell';const {table,tablePos,r,c,offset}=at,schema=editor.schema;
      rowsWanted=Math.max(1,Math.min(60,Math.round(rowsWanted)));colsWanted=Math.max(1,Math.min(12,Math.round(colsWanted)));
      const rows=[...table.content.content],cols=rows[0].childCount;
      if(hasSpans(table)&&colsWanted!==cols)return 'spans';
      const lost=rows.slice(rowsWanted).some(x=>x.textContent.trim())||rows.slice(0,rowsWanted).some(x=>x.content.content.slice(colsWanted).some(cell=>cell.textContent.trim()));
      if(lost&&!force)return 'lost';
      const old=String(table.attrs.columnSize||'').split(',').map(Number),sizes=old.length===cols&&old.every(n=>n>0)?old:Array(cols).fill(100/cols);
      const avg=sizes.reduce((a,b)=>a+b,0)/cols,nextSizes=sizes.slice(0,colsWanted);while(nextSizes.length<colsWanted)nextSizes.push(avg);
      const sum=nextSizes.reduce((a,b)=>a+b,0),pct=nextSizes.map(n=>n*100/sum);
      const width=parseFloat(table.attrs.width)||0,newWidth=width?Math.min(PAGE.width-136,width*colsWanted/cols):0;
      const px=pct.map(p=>Math.round((newWidth||PAGE.width-136)*p/100));
      const fill=(type,i)=>type.createAndFill({colwidth:[px[i]]});
      const resized=rows.slice(0,rowsWanted).map(x=>{const cells=[...x.content.content].slice(0,colsWanted);const type=cells[0]?.type||schema.nodes.tableCell;while(cells.length<colsWanted)cells.push(fill(type,cells.length));return x.copy(Fragment.fromArray(cells.map((cell,i)=>cell.type.create({...cell.attrs,colwidth:[px[i]]},cell.content,cell.marks))));});
      while(resized.length<rowsWanted){const cells=[];for(let i=0;i<colsWanted;i++)cells.push(fill(schema.nodes.tableCell,i));resized.push(schema.nodes.tableRow.create(null,Fragment.fromArray(cells)));}
      const attrs={...table.attrs,columnSize:pct.join(','),width:newWidth?Math.round(newWidth)+'px':table.attrs.width};
      return replaceTable(table,tablePos,schema.nodes.table.create(attrs,Fragment.fromArray(resized),table.marks),Math.min(r,rowsWanted-1),Math.min(c,colsWanted-1),Math.min(r,rowsWanted-1)===r&&Math.min(c,colsWanted-1)===c?offset:1);
    },
    // Color de fondo: celdas seleccionadas (o la del cursor) o toda la tabla. color null = sin color.
    tableBackground(color,whole=false){
      const at=currentCell();if(!at)return false;const tr=editor.state.tr,sel=editor.state.selection,value=color||null,cells=[];
      if(whole)at.table.descendants((cell,off)=>{if(['tableCell','tableHeader'].includes(cell.type.name)){cells.push(at.tablePos+1+off);return false;}});
      else if(sel instanceof CellSelection)sel.forEachCell((cell,pos)=>cells.push(pos));
      else cells.push(at.cellPos);
      for(const pos of cells){const cell=tr.doc.nodeAt(pos);if(cell)tr.setNodeMarkup(pos,undefined,{...cell.attrs,background:value});}
      editor.view.dispatch(closeHistory(tr));return true;
    },
    tableInfo(){const at=currentCell();if(!at)return null;return {rows:at.table.childCount,cols:at.table.firstChild.childCount,row:at.r,col:at.c,spans:hasSpans(at.table),floating:!!at.table.attrs.floating,indent:at.table.attrs.indent||0,background:at.cell.attrs.background||null};},
    tableCommand(cmd) {
      sync(); const map = { rowAbove: 'addRowBefore', rowBelow: 'addRowAfter', colLeft: 'addColumnBefore', colRight: 'addColumnAfter', delRow: 'deleteRow', delCol: 'deleteColumn', delTable: 'deleteTable', merge: 'mergeCells', split: 'splitCell' };
      if (cmd === 'merge') { const sel = editor.state.selection; if (!(sel instanceof CellSelection) || sel.$anchorCell.index(-1) !== sel.$headCell.index(-1)) return false; }
      return map[cmd] ? editor.chain().focus().command(({tr})=>{closeHistory(tr);return true;})[map[cmd]]().run() : false;
    },
    insertText(text) { sync(); return editor.chain().focus().insertContent({ type: 'text', text }).run(); },
    replaceRange(range,text){
      if(!range||range.collapsed||range.startContainer.nodeType!==3||range.endContainer.nodeType!==3||!editor.view.dom.contains(range.startContainer)||!editor.view.dom.contains(range.endContainer)||editor.view.composing)return false;
      try{const from=editor.view.posAtDOM(range.startContainer,range.startOffset),to=editor.view.posAtDOM(range.endContainer,range.endOffset);return from<to&&editor.chain().focus().insertContentAt({from,to},{type:'text',text:String(text)}).run();}catch(_){return false;}
    },
    insertHTML(html, append = false) {
      sync(); const end = editor.state.doc.content.size;
      // An attachment never replaces a selection. Use its trailing edge (or append).
      return editor.chain().focus().insertContentAt(append ? end : editor.state.selection.to, html).run();
    },
    // Imagen u objeto de bloque donde está el cursor: debajo de la línea en la que se escribe (si la línea está
    // vacía, ocupa su lugar). El cursor del editor se conserva aunque el foco haya ido al botón del clip.
    insertBlockAtCursor(html) {
      sync(); const {$to}=editor.state.selection;
      if(!$to.parent.isTextblock||!$to.depth)return editor.chain().focus().insertContentAt(editor.state.selection.to,html).run();
      const range=$to.parent.content.size?$to.after():{from:$to.before(),to:$to.after()};
      return editor.chain().focus().insertContentAt(range,html).run();
    },
    setZoom(value) { zoom = value; layout(); },
    collab: {
      // Sesión del trabajo abierto: cada cambio del editor se apunta en el estado Yjs (como al escribir juntos),
      // así al juntar con los demás se conoce exactamente qué ha hecho cada uno.
      open(state) { session={doc:new Y.Doc(),mapping:new Map(),ready:false};if(state)try{Y.applyUpdate(session.doc,b64d(state));}catch(_){}return yHTML(); },
      close() { session=null; },
      state() { return session?b64e(Y.encodeStateAsUpdate(session.doc)):null; },
      // Encabezado y pie de página del trabajo: también se comparten (gana el último que los cambió).
      meta() { const m=session?.doc.getMap('meta');return {header:String(m?.get('header')??''),footer:String(m?.get('footer')??'')}; },
      setMeta(field,value) { if(session&&['header','footer'].includes(field)&&session.doc.getMap('meta').get(field)!==value)session.doc.getMap('meta').set(field,String(value)); },
      // Recibe los estados de los demás y deja en el editor el documento ya mezclado (conserva más o menos el cursor).
      receive(states) {
        if(!session)return null;track();
        for(const state of states||[])if(state)try{Y.applyUpdate(session.doc,b64d(state));}catch(_){/* archivo dañado: se ignora */}
        const head=editor.state.selection.head,html=yHTML();api.load(html);
        try{editor.commands.setTextSelection(Math.min(head,editor.state.doc.content.size-1));}catch(_){}
        return {state:this.state(),html};
      },
      merge(states) {
        const doc=new Y.Doc();for(const state of states||[])if(state)try{Y.applyUpdate(doc,b64d(state));}catch(_){/* archivo dañado: se ignora */}
        const pm=yXmlFragmentToProseMirrorRootNode(doc.getXmlFragment('doc'),editor.schema);
        return {state:b64e(Y.encodeStateAsUpdate(doc)),html:getHTMLFromFragment(pm.content,editor.schema)};
      },
    },
    regions(header='',footer='') { runningHeader=header;runningFooter=footer;paintRunningRegions(Math.max(1,sheets.children.length)); },
    onRegionChange(callback) { regionChange=callback; },
    active(name, attrs) { return editor.isActive(name, attrs); },
    style() { return editor.getAttributes('textStyle'); },
    fontSize() {
      const {state,view}=editor, sizes=new Set();
      const element=node=>node?.nodeType===3?node.parentElement:node;
      const points=px=>String(Math.round(px*.75*100)/100);
      if(!state.selection.empty){
        for(const {$from,$to} of state.selection.ranges)state.doc.nodesBetween($from.pos,$to.pos,(node,pos)=>{
          if(sizes.size>1)return false;
          if(node.isText||node.isTextblock&&!node.content.size){const dom=element(view.nodeDOM(pos));if(dom)sizes.add(points(parseFloat(getComputedStyle(dom).fontSize)));}
        });
        if(sizes.size)return sizes.size===1?[...sizes][0]:'mixed';
      }
      const {$from}=state.selection,block=$from.depth?view.nodeDOM($from.before()):view.dom;
      const base=parseFloat(getComputedStyle(element(block)).fontSize);
      const value=(state.storedMarks??$from.marks()).find(m=>m.type.name==='textStyle')?.attrs.fontSize;
      if(!value)return points(base);
      // Resolve relative CSS sizes against the paragraph, not parseFloat('1.02rem').
      const outer=document.createElement('span'),probe=document.createElement('span');
      outer.style.cssText=`position:absolute;visibility:hidden;pointer-events:none;font-size:${base}px`;
      probe.style.fontSize=value;outer.append(probe);document.body.append(outer);
      try{return points(parseFloat(getComputedStyle(probe).fontSize));}finally{outer.remove();}
    },
    paragraphFormat(){
      const rows=selectedParagraphs(editor.state).map(({node,pos})=>{
        const css=getComputedStyle(editor.view.nodeDOM(pos)),inline=new Set();node.descendants(n=>{for(const m of n.marks)if(m.type.name==='textStyle'&&m.attrs.lineHeight)inline.add(m.attrs.lineHeight);});
        const line=Number((parseFloat(css.lineHeight)/parseFloat(css.fontSize)).toFixed(3));
        const mixed=[...inline].some(v=>{const s=String(v).trim(),ratio=/^[\d.]+$/.test(s)?Number(s):s.endsWith('%')?parseFloat(s)/100:lengthPx(s,editor.view.nodeDOM(pos))/parseFloat(css.fontSize);return !Number.isFinite(ratio)||Math.abs(ratio-line)>.002;});
        return {lineHeight:mixed?'mixed':String(line),spaceAfter:String(Number((parseFloat(css.marginBottom)*.75).toFixed(3)))};
      });
      const common=k=>rows.length&&rows.every(r=>r[k]===rows[0][k])?rows[0][k]:'mixed';return {lineHeight:common('lineHeight'),spaceAfter:common('spaceAfter')};
    },
  };
  return api;
} };
