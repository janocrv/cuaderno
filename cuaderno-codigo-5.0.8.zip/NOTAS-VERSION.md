# Cuaderno 5.0.8

- **Transcripción simultánea más fina:** cada frase sale al momento (en gris) y, en cuanto hay un hueco o al terminar la clase, se repasa con el reconocimiento de voz bueno y queda en negro. «Añadir a apuntes» usa siempre la versión afinada. La primera vez descarga unos 250 MB más.
- **Más rápida, sobre todo en Windows:** el reconocimiento de voz usa ahora varios núcleos del procesador (antes solo uno), así que va el doble de rápido y no se queda atrás.
- **Sin frases inventadas:** cuando no entendía un trozo, a veces se quedaba repitiendo lo mismo («de la información de la información…»). Ya no.
- **Transcribir un audio** (después de la clase) también va más rápido por lo mismo.
- **Dónde queda la grabación:** al detener, Cuaderno dice dónde se ha guardado (Archivos de la asignatura y Documentos › Cuaderno - Grabaciones), con «Mostrar» para abrir la carpeta y **«Guardar en…»** para guardar una copia donde tú quieras. También con la transcripción simultánea.

Incluye todo lo de la 5.0.7 (transcripción simultánea, medidor de sonido, ajustes sincronizados entre tus ordenadores). Los datos guardados se conservan al actualizar.

## Descargas

- **Mac con chip Apple:** Cuaderno-mac-arm64.dmg.
- **Mac Intel:** Cuaderno-mac-x64.dmg.
- **Windows de 64 bits:** Cuaderno-win-x64.exe.
