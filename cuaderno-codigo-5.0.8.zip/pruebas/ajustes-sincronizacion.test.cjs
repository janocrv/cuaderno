/* mergeStates de escritorio/main.js: los ajustes se mezclan clave a clave (settings._k) y se apuntan los ordenadores. */
const fs = require('node:fs'), path = require('node:path'), assert = require('node:assert/strict');
const src = fs.readFileSync(path.join(__dirname, '../escritorio/main.js'), 'utf8');
const grab = name => { const a = src.indexOf('function ' + name + '('); let i = src.indexOf('{', a), d = 0; for (; i < src.length; i++) { if (src[i] === '{') d++; else if (src[i] === '}' && !--d) break; } return src.slice(a, i + 1); };
const LISTS = ['notes', 'tasks', 'biblio', 'files'], LOCAL_KEYS = ['active', 'activeNote', 'view', 'railOpen', 'theme', 'soundOff', 'subjectScope'];
const mergeList = eval('(' + grab('mergeList') + ')');
const mergeStates = eval('(' + grab('mergeStates') + ')');
const base = { _u: 1, subjects: [], settings: { _u: 100, photo: 'A', userName: 'Jano', appearance: { day: 'gris' } }, schedule: [{ id: 'c1' }] };
// 1) el PC cambia la foto (t=200) y el Mac los colores (t=210) sin haberse visto
const pc = JSON.parse(JSON.stringify(base)); pc.settings.photo = 'B'; pc.settings._u = 200; pc.settings._k = { photo: 200 };
const mac = JSON.parse(JSON.stringify(base)); mac.settings.appearance = { day: 'niebla' }; mac.settings._u = 210; mac.settings._k = { appearance: 210 };
let disk = mergeStates(base, pc); disk = mergeStates(disk, mac);
assert.equal(disk.settings.photo, 'B', 'la foto del PC no se pierde');
assert.deepEqual(disk.settings.appearance, { day: 'niebla' }, 'los colores del Mac no se pierden');
assert.equal(disk.settings.userName, 'Jano');
assert.deepEqual(disk.schedule, [{ id: 'c1' }]);
console.log('PASS foto (PC) y colores (Mac) cambiados a la vez se conservan los dos');
// 2) un ordenador con versión antigua (sin _k) sigue funcionando: gana el más reciente
const old = JSON.parse(JSON.stringify(base)); old.settings.userName = 'Jano C.'; old.settings._u = 300; delete old.settings._k;
disk = mergeStates(disk, old);
assert.equal(disk.settings.userName, 'Jano C.');
console.log('PASS compatible con versiones anteriores (sin hora por ajuste)');
// 3) quitar la foto también viaja
const del = JSON.parse(JSON.stringify(disk)); delete del.settings.photo; del.settings._u = 400; del.settings._k = { ...del.settings._k, photo: 400 };
disk = mergeStates(disk, del);
assert.equal(disk.settings.photo, undefined);
console.log('PASS quitar la foto se sincroniza');
// 4) ordenadores: se juntan los de los dos lados
const a = { ...disk, devices: { m: { name: 'Mac', at: 5 } } }, b = { ...disk, devices: { p: { name: 'PC', at: 7 }, m: { name: 'Mac', at: 3 } } };
const d = mergeStates(a, b).devices;
assert.deepEqual(Object.keys(d).sort(), ['m', 'p']); assert.equal(d.m.at, 5);
console.log('PASS lista de ordenadores');
