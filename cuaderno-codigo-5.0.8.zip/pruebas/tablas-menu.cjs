// Menú de tabla (26-11-2026): mover filas/columnas, tamaño, color de celda y sangría, con Deshacer.
const {chromium}=require('playwright'),assert=require('node:assert/strict'),path=require('node:path');
const root=path.resolve(__dirname,'..'),out=path.join(root,'revisiones/2026-11-26');require('node:fs').mkdirSync(out,{recursive:true});
const TABLE='<p>Antes</p><p>Texto de ejemplo para que la tabla no quede pegada arriba.</p><p>Otra línea.</p><p>Y otra más.</p><table><tbody><tr><th><p>A</p></th><th><p>B</p></th><th><p>C</p></th></tr><tr><td><p>1</p></td><td><p>2</p></td><td><p>3</p></td></tr><tr><td><p>4</p></td><td><p>5</p></td><td><p>6</p></td></tr></tbody></table><p>Después</p>';
(async()=>{const b=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});try{
 const p=await b.newPage({viewport:{width:1440,height:1000},deviceScaleFactor:2}),errors=[];p.on('pageerror',e=>errors.push(e.message));
 await p.route('https://api.github.com/**',r=>r.fulfill({status:200,contentType:'application/json',body:'{"tag_name":"v2.0.0"}'}));
 const s={id:'t',short:'ADP',name:'Prueba',color:'#399c91',notes:[{id:'n',title:'Tabla',date:'2026-11-26',updated:1,content:TABLE}],tasks:[],files:[],teachers:[],biblio:[]};
 await p.addInitScript(s=>{if(window.top!==window)return;localStorage.setItem('cuaderno-apuntes-v1',JSON.stringify({subjects:[s],active:'t',subjectScope:'t',activeNote:'n',view:'notes',theme:'light',settings:{userName:'Prueba',lang:'es'},deleted:{},library:[],schedule:[],tfmAdded:true,seeded2627:true}));localStorage.setItem('cuaderno-correo-preguntado','1')},s);
 await p.goto(require('node:url').pathToFileURL(path.join(root,'cuaderno-apuntes.html')).href);await p.waitForTimeout(900);
 const grid=()=>p.evaluate(()=>[...document.querySelector('#editor table').rows].map(r=>[...r.cells].map(c=>c.textContent).join('')));
 const cell=txt=>{return p.locator('#editor td, #editor th').filter({hasText:new RegExp('^'+txt+'$')}).first();};
 const menu=async()=>{if(!(await p.locator('#tableActionMenu').isVisible())){await p.evaluate(()=>document.querySelector('#editor .cuaderno-table').scrollIntoView({block:'center'}));await p.waitForTimeout(150);await p.locator('.table-menu-toggle').click();await p.waitForTimeout(150);}};
 const act=async t=>{await menu();await p.locator(`#tableActionMenu [data-t="${t}"]`).first().click();await p.waitForTimeout(200);};
 assert.deepEqual(await grid(),['ABC','123','456']);
 await cell('2').click();await act('rowDown');assert.deepEqual(await grid(),['ABC','456','123']);
 assert(await p.locator('#tableActionMenu').isVisible(),'el menú sigue abierto para dar más pasos');
 await act('rowUp');assert.deepEqual(await grid(),['ABC','123','456']);
 await act('rowUp');assert.deepEqual(await grid(),['123','ABC','456'],'la fila sube al sitio de los títulos');
 assert.equal(await p.evaluate(()=>document.querySelector('#editor table').rows[0].cells[0].tagName),'TH','la fila de arriba sigue siendo de títulos');
 await p.keyboard.press('Meta+z');await p.waitForTimeout(200);assert.deepEqual(await grid(),['ABC','123','456'],'Deshacer devuelve la fila');
 console.log('PASS mover filas (con títulos fijos arriba y Deshacer)');
 await cell('2').click();await act('colMoveR');assert.deepEqual(await grid(),['ACB','132','465']);await act('colMoveL');await act('colMoveL');assert.deepEqual(await grid(),['BAC','213','546']);
 console.log('PASS mover columnas');
 await act('rows+');assert.equal(await p.locator('#editor table tr').count(),4);assert.equal(await p.locator('#tbRows').innerText(),'4');
 await act('cols+');assert.equal(await p.evaluate(()=>document.querySelector('#editor table').rows[0].cells.length),4);
 await act('cols-');await act('rows-');assert.deepEqual(await grid(),['BAC','213','546']);
 p.once('dialog',d=>d.dismiss());await act('rows-');assert.deepEqual(await grid(),['BAC','213','546'],'no quita una fila con texto sin preguntar');
 console.log('PASS tamaño con − / + (pregunta antes de quitar texto)');
 await cell('1').click();await act('bg');   // primer muestra = sin color
 await p.locator('#tableActionMenu [data-bg="#cfe3ff"]').click();await p.waitForTimeout(200);
 assert.equal(await p.evaluate(()=>getComputedStyle([...document.querySelectorAll('#editor td')].find(c=>c.textContent==='1')).backgroundColor),'rgb(207, 227, 255)');
 assert.match(await p.evaluate(()=>[...document.querySelectorAll('#editor td')].find(c=>c.textContent==='2').style.backgroundColor||'ninguno'),/ninguno|^$/);
 await p.locator('#tableActionMenu [data-t="bgAll"]').click();await p.locator('#tableActionMenu [data-bg="#c9f0e1"]').click();await p.waitForTimeout(200);
 assert.equal(await p.evaluate(()=>[...document.querySelectorAll('#editor td,#editor th')].every(c=>getComputedStyle(c).backgroundColor==='rgb(201, 240, 225)')),true,'toda la tabla');
 await p.screenshot({path:path.join(out,'menu-tabla.png'),clip:await p.evaluate(()=>{const a=document.querySelector('#tableActionMenu').getBoundingClientRect(),t=document.querySelector('#editor .cuaderno-table').getBoundingClientRect();const x=Math.min(a.left,t.left)-20,y=Math.min(a.top,t.top)-40;return {x,y,width:Math.max(a.right,t.right)-x+20,height:Math.max(a.bottom,t.bottom)-y+20};})});
 console.log('PASS color de la celda y de toda la tabla');
 const floating=await p.evaluate(()=>document.querySelector('#editor .cuaderno-table').dataset.floating);
 if(floating==='true'){await act('inline');await cell('1').click();}
 const ml=()=>p.evaluate(()=>parseFloat(document.querySelector('#editor .cuaderno-table').style.marginLeft)||0);
 await act('indent+');await act('indent+');assert.equal(await ml(),48);await act('indent-');assert.equal(await ml(),24);
 console.log('PASS sangría de la tabla en el texto');
 await p.locator('#tableActionMenu [data-t="indent-"]').click();await p.waitForTimeout(150);
 const html=await p.evaluate(()=>window.CuadernoEditor&&document.querySelector('#editor').innerHTML.length);assert(html>0);
 await p.keyboard.press('Escape');await p.waitForTimeout(2500);
 const saved=await p.evaluate(()=>{const s=JSON.parse(localStorage.getItem('cuaderno-apuntes-v1'));return s.subjects[0].notes[0].content;});
 assert.match(saved,/data-bg="#c9f0e1"/,'el color se guarda: '+saved.slice(saved.indexOf('<table'),saved.indexOf('<table')+300));
 assert.deepEqual(errors,[]);console.log('PASS se guarda y sin errores');
}finally{await b.close();}})().catch(e=>{console.error(e);process.exit(1)});
