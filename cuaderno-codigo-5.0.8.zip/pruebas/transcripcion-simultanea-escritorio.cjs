/* Transcripción simultánea: la voz entra por un micrófono simulado; el texto tiene que ir apareciendo MIENTRAS se graba.
   Uso: CUADERNO_VOZ=<archivo.wav> node pruebas/transcripcion-simultanea-escritorio.cjs [capturas]
   La primera vez descarga Whisper tiny y base (≈ 120 MB) a la caché del perfil de prueba. */
const { _electron } = require('playwright'), fs = require('node:fs'), path = require('node:path'), os = require('node:os'), assert = require('node:assert/strict');
const BUILD = process.env.CUADERNO_APP_DIR || path.join(os.homedir(), '.cuaderno-build');
const VOZ = process.env.CUADERNO_VOZ, SHOTS = process.argv[2] || null, MIN = +process.env.CUADERNO_MINUTOS || 0;   // CUADERNO_MINUTOS=10: clase larga
if (!VOZ) { console.log('Sin CUADERNO_VOZ: prueba omitida'); process.exit(0); }
(async () => {
  let app; const profile = fs.mkdtempSync(path.join(os.tmpdir(), 'cuaderno-directo-'));
  try {
    const s = { id: 'adp', short: 'ADP', name: 'Aprendizaje y desarrollo de la personalidad', color: '#399c91', notes: [], tasks: [], files: [], teachers: [], biblio: [] };
    fs.mkdirSync(path.join(profile, 'datos')); fs.writeFileSync(path.join(profile, 'datos/cuaderno-datos.json'), JSON.stringify({ subjects: [s], settings: { userName: 'Prueba', lang: 'es' }, deleted: {}, library: [], schedule: [], homeBoard: [], seeded2627: true, tfmAdded: true }));
    app = await _electron.launch({ executablePath: path.join(BUILD, 'node_modules/electron/dist/Electron.app/Contents/MacOS/Electron'), args: [BUILD, '--use-fake-ui-for-media-stream', '--use-fake-device-for-media-stream'], env: { ...process.env, CUADERNO_PRUEBA: profile, CUADERNO_UPDATE_API: 'http://127.0.0.1:9' }, timeout: 60000 });
    const p = await app.firstWindow(); p.setDefaultTimeout(20000);
    const errors = []; p.on('pageerror', e => errors.push(String(e)));
    await p.waitForTimeout(1500);
    await p.evaluate(() => { localStorage.setItem('cuaderno-correo-preguntado', '1'); document.querySelectorAll('dialog[open]').forEach(d => d.close()); });
    // la voz empieza a sonar cuando se abre el micrófono, dos veces seguidas (34 s) y después silencio
    await p.evaluate(async ([b64, MIN]) => {
      const bytes = Uint8Array.from(atob(b64), c => c.charCodeAt(0));
      navigator.mediaDevices.getUserMedia = async () => {
        const ac = new AudioContext(), buf = await ac.decodeAudioData(bytes.buffer.slice(0)), dest = ac.createMediaStreamDestination();
        const veces = MIN ? Math.ceil(MIN * 60 / (buf.duration + 1)) : 2;
        for (let k = 0; k < veces; k++) { const at = 0.3 + k * (buf.duration + 1); const src = ac.createBufferSource(); src.buffer = buf; src.connect(dest); src.start(ac.currentTime + at); }
        return dest.stream;
      };
    }, [fs.readFileSync(VOZ).toString('base64'), MIN]);
    await p.locator('#subjects [data-sid="adp"]').click(); await p.locator('#tabNotes').click();
    await p.locator('#recBtn').click();
    await p.waitForFunction(() => document.querySelector('#recBar').classList.contains('rec'));
    await p.locator('#recLive').click();
    await p.waitForFunction(() => document.querySelector('#livePan').matches(':popover-open'));
    // CUADERNO_RETRASO=1: el ordenador «no da abasto» (no transcribe nada mientras suena la voz) y todo queda para el final
    if (process.env.CUADERNO_RETRASO) {
      await p.evaluate(() => { cuadernoGrabacion.directo().busy = true; });
      await p.waitForTimeout(40000);
      const pend = await p.evaluate(() => Math.round(cuadernoGrabacion.directo().openLen / 16000));
      console.log('Pendiente sin transcribir al detener:', pend, 's');
      await p.evaluate(() => { cuadernoGrabacion.directo().busy = false; });
      await p.locator('#recStop').click();
      await p.waitForFunction(() => /terminada/i.test(document.querySelector('#lpStatus').textContent), null, { timeout: 120000 });
      const txt = await p.evaluate(() => document.querySelector('#lpText').innerText);
      const n = (txt.match(/diciembre/gi) || []).length, words = (txt.match(/\S+/g) || []).length;
      console.log(txt.replace(/\s+/g, ' ').slice(0, 700));
      assert.ok(pend > 30, 'había más de 30 s pendientes'); assert.equal(n, 2, 'están las dos repeticiones completas, hasta el final');
      console.log('PASS con', pend, 's pendientes, al detener lo transcribe todo:', words, 'palabras');
      assert.deepEqual(errors, []); console.log('PASS sin errores'); return;
    }
    if (MIN) {   // clase larga: mide cuánto se queda atrás minuto a minuto
      let maxLag = 0; const t0 = Date.now();
      while (Date.now() - t0 < MIN * 60000 + 5000) {
        await p.waitForTimeout(30000);
        const st = await p.evaluate(() => { const l = cuadernoGrabacion.directo(); return { lag: Math.round(l.openLen / 16000), frases: l.parts.length, mem: Math.round(performance.memory.usedJSHeapSize / 1e6) }; });
        maxLag = Math.max(maxLag, st.lag); console.log(`${Math.round((Date.now() - t0) / 60000 * 10) / 10} min · retraso ${st.lag} s · frases ${st.frases} · memoria ${st.mem} MB`);
      }
      const t1 = Date.now(); await p.locator('#recStop').click();
      await p.waitForFunction(() => /terminada/i.test(document.querySelector('#lpStatus').textContent), null, { timeout: 600000 });
      const txt = await p.evaluate(() => document.querySelector('#lpText').innerText), n = (txt.match(/diciembre/gi) || []).length, veces = Math.ceil(MIN * 60 / 18);
      console.log(`Al detener tardó ${Math.round((Date.now() - t1) / 1000)} s en terminar · «diciembre» aparece ${n} de ${veces} veces · palabras ${(txt.match(/\S+/g) || []).length} · retraso máximo ${maxLag} s`);
      assert.ok(n >= veces - 1, 'está todo el texto'); assert.deepEqual(errors, []); console.log('PASS clase larga'); return;
    }
    // mientras suena la voz, el texto tiene que ir creciendo
    const seen = []; const t0 = Date.now();
    while (Date.now() - t0 < 40000) {
      await p.waitForTimeout(2000);
      const st = await p.evaluate(() => ({ txt: document.querySelector('#lpText').innerText.replace(/\s+/g, ' ').trim(), status: document.querySelector('#lpStatus').textContent }));
      seen.push(`${Math.round((Date.now() - t0) / 1000)} s · ${st.status} · ${st.txt.slice(-90)}`);
      if (SHOTS && seen.length === 8) await p.screenshot({ path: path.join(SHOTS, 'directo.png') });
    }
    console.log(seen.join('\n'));
    const words = await p.evaluate(() => (document.querySelector('#lpText').innerText.match(/\S+/g) || []).length);
    assert.ok(words > 40, 'el texto aparece mientras se graba');
    assert.ok(seen.some((l, i) => i < 8 && /evaluaci/i.test(l)), 'aparece texto en los primeros 16 s');
    console.log('PASS el texto aparece mientras se graba:', words, 'palabras');
    await p.locator('#recStop').click();
    await p.waitForFunction(() => /terminada/i.test(document.querySelector('#lpStatus').textContent), null, { timeout: 60000 });
    assert.equal(await p.evaluate(() => document.querySelector('#recDlg').open), false, 'no sale la ventana de transcribir');
    await p.locator('#lpFull').click();
    await p.waitForFunction(() => cuadernoGrabacion.asignatura('adp').notes.length === 1, null, { timeout: 60000 });
    const note = await p.evaluate(() => cuadernoGrabacion.asignatura('adp').notes[0]);
    console.log('PASS apunte desde la transcripción simultánea:', note.title, '\n ', note.content.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').slice(0, 400));
    if (SHOTS) await p.screenshot({ path: path.join(SHOTS, 'directo-fin.png') });
    assert.deepEqual(errors, []); console.log('PASS sin errores');
  } finally { await app?.close(); fs.rmSync(profile, { recursive: true, force: true }); }
})().catch(e => { console.error(e); process.exitCode = 1; });
