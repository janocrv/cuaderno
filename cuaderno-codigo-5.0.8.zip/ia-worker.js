// IA local del Cuaderno (se ejecuta en un Web Worker para no congelar la ventana).
// Modelo: Gemma 3 1B (Google) en ONNX, con transformers.js. Se descarga una vez desde Hugging Face y
// queda guardado en la caché de la app ("transformers-cache"). Con tarjeta gráfica compatible usa
// WebGPU (rápido); si no, el procesador (más lento).
import { pipeline, env, TextStreamer, InterruptableStoppingCriteria } from './transformers.min.js';

const MODEL = 'onnx-community/gemma-3-1b-it-ONNX';
env.allowLocalModels = false;
env.allowRemoteModels = true;
env.useBrowserCache = true;
env.backends.onnx.wasm.wasmPaths = { mjs: new URL('./ort-wasm-simd-threaded.asyncify.mjs', import.meta.url).href, wasm: new URL('./ort-wasm-simd-threaded.asyncify.wasm', import.meta.url).href };
// Varios núcleos solo en la ventana aislada de voz (main.js /asr.html); fuera de ella el motor solo puede usar uno.
// Medido en el PC de Jano (8 núcleos): Whisper small, 20 s de audio en 19 s con 1 núcleo → 9 s con 6.
env.backends.onnx.wasm.numThreads = self.crossOriginIsolated ? Math.max(2, Math.min(6, (self.navigator?.hardwareConcurrency || 4) - 2)) : 1;

let gen = null, loading = null, device = null;
const stopper = new InterruptableStoppingCriteria();
const post = (type, data = {}) => self.postMessage({ type, ...data });

async function pickDevice() {
  try {
    if (!self.navigator?.gpu) return { device: 'wasm', dtype: 'q4' };
    const ad = await navigator.gpu.requestAdapter();
    if (ad && ad.features.has('shader-f16')) return { device: 'webgpu', dtype: 'q4f16' };
  } catch (e) {}
  return { device: 'wasm', dtype: 'q4' };
}

// ¿Está ya descargada? (mira si los archivos del modelo están en la caché)
async function isDownloaded() {
  try {
    const d = await pickDevice();
    const c = await caches.open('transformers-cache');
    const keys = (await c.keys()).map(r => r.url);
    const file = d.dtype === 'q4f16' ? 'model_q4f16.onnx' : 'model_q4.onnx';
    return keys.some(u => u.includes('gemma-3-1b-it-ONNX') && u.endsWith('/onnx/' + file));
  } catch (e) { return false; }
}

async function load() {
  if (gen) return gen;
  if (loading) return loading;
  loading = (async () => {
    const d = await pickDevice(); device = d.device;
    const files = {};
    gen = await pipeline('text-generation', MODEL, {
      device: d.device, dtype: d.dtype,
      progress_callback: p => {
        if (p.status === 'progress' && p.total) {
          files[p.file] = { loaded: p.loaded, total: p.total };
          const all = Object.values(files), loaded = all.reduce((a, f) => a + f.loaded, 0), total = all.reduce((a, f) => a + f.total, 0);
          post('progress', { loaded, total, file: p.file });
        } else if (p.status === 'ready') post('progress', { ready: true });
      },
    });
    // Calentamiento: la primera ejecución compila los «shaders» de la tarjeta gráfica
    await gen([{ role: 'user', content: 'Hola' }], { max_new_tokens: 1 });
    return gen;
  })();
  try { await loading; post('ready', { device }); return gen; }
  catch (e) { gen = null; throw e; }
  finally { loading = null; }
}

async function generate(id, prompt, maxTokens) {
  const g = await load();
  stopper.reset();
  let out = '';
  const streamer = new TextStreamer(g.tokenizer, {
    skip_prompt: true, skip_special_tokens: true,
    callback_function: t => { out += t; post('token', { id, text: t }); },
  });
  await g([{ role: 'user', content: prompt }], {
    max_new_tokens: maxTokens || 700, do_sample: false, repetition_penalty: 1.12,
    streamer, stopping_criteria: stopper,
  });
  return out;
}

// ---------- Transcribir audio (26-11-2026): Whisper small multilingüe (OpenAI) en ONNX, también local ----------
// 'small' = transcribir archivos (mejor calidad); 'base' = subtítulos en directo (≈ 4 veces más rápido)
const ASR_MODELS = { small: 'onnx-community/whisper-small', base: 'onnx-community/whisper-base', tiny: 'onnx-community/whisper-tiny' };
const asrPipes = {}, asrLoads = {};
let asrDevice = null;
async function loadAsr(size = 'small') {
  if (asrPipes[size]) return asrPipes[size];
  if (asrLoads[size]) return asrLoads[size];
  const ASR_MODEL = ASR_MODELS[size] || ASR_MODELS.small;
  let asr = null;
  const run = (async () => {
    const files = {};
    const progress_callback = p => {
      if (p.status === 'progress' && p.total) {
        files[p.file] = { loaded: p.loaded, total: p.total };
        const all = Object.values(files), loaded = all.reduce((a, f) => a + f.loaded, 0), total = all.reduce((a, f) => a + f.total, 0);
        post('asrProgress', { loaded, total });
      }
    };
    // procesador (wasm) con el modelo cuantizado (≈ 250 MB): con WebGPU se quedaba colgado en las pruebas (26-11-2026)
    const tries = [{ device: 'wasm', dtype: 'q8' }];
    let last;
    for (const t of tries) {
      try { asr = await pipeline('automatic-speech-recognition', ASR_MODEL, { ...t, progress_callback }); asrDevice = t.device; return asr; }
      catch (e) { last = e; asr = null; }
    }
    throw last;
  })();
  asrLoads[size] = run;
  try { asrPipes[size] = await run; post('asrReady', { device: asrDevice, size }); return asrPipes[size]; }
  finally { delete asrLoads[size]; }
}
async function asrDownloaded() {
  try { const c = await caches.open('transformers-cache'); return (await c.keys()).some(r => r.url.includes('whisper-small') && /encoder_model/.test(r.url)); } catch (e) { return false; }
}
// Whisper a veces se queda en bucle («de la información de la información…» hasta el máximo de palabras): con el audio
// de una clase real pasaba en casi cada trozo con tiny y a menudo con base, y cada pasada tardaba 15-27 s en vez de 2.
// Freno: tope de palabras según lo que dura el audio, sin repetir grupos de 4 palabras y, por si acaso, se quitan las
// repeticiones que queden (una frase repetida 3 veces o más seguidas se deja una sola vez).
const unloop = t => String(t || '').replace(/(\S.{4,80}?\S)(?:[\s,.;:]+\1){2,}/giu, '$1').replace(/\s+/g, ' ').trim();
async function transcribe(id, audio, lang, size, live) {
  const a = await loadAsr(size || 'small');
  const opts = { language: lang === 'ca' ? 'catalan' : 'spanish', task: 'transcribe', no_repeat_ngram_size: 4 };
  // en directo: trozos cortos (< 30 s) en una sola pasada, sin marcas de tiempo (≈ 5 piezas de palabra por segundo de voz como mucho)
  const r = live ? await a(audio, { ...opts, max_new_tokens: Math.min(440, Math.ceil(audio.length / 16000 * 5) + 16) })
    : await a(audio, { ...opts, chunk_length_s: 30, stride_length_s: 5, return_timestamps: true });
  return { text: unloop(r.text), chunks: (r.chunks || []).map(c => ({ t: c.timestamp ? c.timestamp[0] : null, text: unloop(c.text) })) };
}

self.onmessage = async e => {
  const m = e.data || {};
  try {
    if (m.type === 'asrStatus') { post('asrStatus', { downloaded: await asrDownloaded(), loaded: !!asrPipes.small, device: asrDevice }); return; }
    if (m.type === 'asrLoad') { await loadAsr(m.size); return; }
    if (m.type === 'transcribe') { const r = await transcribe(m.id, m.audio, m.lang, m.size, m.live); post('asrDone', { id: m.id, ...r }); return; }
    if (m.type === 'status') post('status', { downloaded: await isDownloaded(), loaded: !!gen, device });
    else if (m.type === 'load') await load();
    else if (m.type === 'stop') stopper.interrupt();
    else if (m.type === 'generate') { const text = await generate(m.id, m.prompt, m.maxTokens); post('done', { id: m.id, text }); }
    else if (m.type === 'delete') {
      gen = null;
      const c = await caches.open('transformers-cache');
      for (const r of await c.keys()) if (r.url.includes('gemma-3-1b-it-ONNX')) await c.delete(r);
      post('deleted');
    }
  } catch (err) {
    post('error', { id: m.id, message: String(err && err.message || err) });
  }
};
