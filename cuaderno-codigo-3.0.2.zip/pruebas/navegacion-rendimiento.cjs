/* NODE_PATH=<playwright> node pruebas/navegacion-rendimiento.cjs. Sin datos reales. */
const {chromium}=require('playwright'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..');
const source=fs.readFileSync(path.join(root,'escritorio/main.js'),'utf8');
const asset=source.match(/^const assetName = .*$/m)[0];
for(const [platform,arch,translated,expected] of [
  ['darwin','x64',true,'Cuaderno-mac-arm64.dmg'],['darwin','arm64',false,'Cuaderno-mac-arm64.dmg'],
  ['darwin','x64',false,'Cuaderno-mac-x64.dmg'],['win32','x64',false,'Cuaderno-win-x64.exe'],
])assert.equal(vm.runInNewContext(asset+';assetName()', {IS_WIN:platform==='win32',IS_MAC:platform==='darwin',process:{arch},app:{runningUnderARM64Translation:translated}}),expected);
console.log('PASS actualizador distingue Apple, Intel y Rosetta');
(async()=>{const b=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});try{
  const p=await b.newPage({viewport:{width:1920,height:1080}}),errors=[];p.on('pageerror',e=>errors.push(e.message));
  const subjects=Array.from({length:8},(_,i)=>({id:'s'+i,short:'S'+i,name:'Asignatura '+i,color:'#399c91',notes:Array.from({length:30},(_,j)=>({id:'n'+i+'-'+j,title:'Apunte '+j,date:'2026-11-14',updated:1,content:'<p>Contenido '+i+' '+j+'</p>'})),tasks:[],files:[],biblio:[],teachers:[]}));
  await p.addInitScript(subjects=>{if(window.top!==window)return;localStorage.setItem('cuaderno-apuntes-v1',JSON.stringify({subjects,active:'s0',subjectScope:'s0',activeNote:'n0-0',view:'notes',theme:'light',settings:{lang:'es',userName:'Prueba'},deleted:{},library:[],schedule:[],homeBoard:[],seeded2627:true,tfmAdded:true}));localStorage.setItem('cuaderno-correo-preguntado','1');},subjects);
  await p.route('https://api.github.com/**',r=>r.fulfill({json:{tag_name:'v2.0.0'}}));
  await p.goto(require('node:url').pathToFileURL(path.join(root,'cuaderno-apuntes.html')).href);await p.waitForTimeout(800);
  await p.evaluate(()=>{window.navWork={editor:0,notes:0,refs:0,files:0,appearance:0};for(const [key,selector]of Object.entries({editor:'#editor',notes:'#notesList',refs:'#refs',files:'#files'})){const el=document.querySelector(selector);new MutationObserver(ms=>navWork[key]+=ms.length).observe(el,{childList:true,subtree:true});}new MutationObserver(ms=>navWork.appearance+=ms.filter(m=>m.attributeName==='style'||m.attributeName==='data-theme').length).observe(document.documentElement,{attributes:true});});
  await p.locator('#tabTasks').click();await p.locator('#subjects [data-sid="s1"]').click();await p.waitForTimeout(150);
  const work=await p.evaluate(()=>navWork);assert.equal(work.editor,0);assert.equal(work.notes,0);assert.equal(work.refs,0);assert.equal(work.files,0);
  console.log('PASS cambiar asignatura en Tareas no reconstruye el editor ni pantallas ocultas',work);
  await p.locator('#tabNotes').click();assert.match(await p.locator('#editor').innerText(),/Contenido 1/);
  await p.locator('#homeBtn').click();await p.locator('[data-home-view="notes"]').click();assert.equal(await p.locator('#notesList button').count(),240);
  await p.locator('#notesList button').first().click();await p.locator('#editor').click();await p.keyboard.press('End');await p.keyboard.type(' Texto conservado');await p.locator('#tabTasks').click();await p.locator('#tabNotes').click();assert.match(await p.locator('#editor').innerText(),/Texto conservado/);
  assert.deepEqual(errors,[]);console.log('PASS vistas globales, carga diferida y conservación al salir del editor');
}finally{await b.close()}})().catch(e=>{console.error(e);process.exit(1)});
