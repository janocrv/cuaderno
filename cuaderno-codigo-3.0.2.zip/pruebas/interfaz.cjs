/* NODE_PATH=<carpeta con playwright> node pruebas/interfaz.cjs. Solo datos ficticios. */
const {chromium}=require('playwright'),http=require('node:http'),fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..'),out=path.join(root,'revisiones','2026-11-14');
const date=offset=>{const d=new Date();d.setDate(d.getDate()+offset);return d.toISOString().slice(0,10);},spanish=iso=>iso.split('-').reverse().join('/');
const subject={id:'curso-test',short:'ADP',code:'40493',name:'Aprendizaje y desarrollo de la personalidad',color:'#399c91',emails:[],teachers:[],biblio:[],files:[],notes:[{id:'nota-test',title:'Documento de prueba',date:date(0),updated:1,content:'<h2>Listas y aprendizaje</h2><ol><li><p>Comida</p></li><li><p>Pan</p></li><li><p>Bebida</p></li></ol>'}],tasks:[{id:'tarea-test',title:'Análisis de caso',due:date(-2),done:false,created:1}]};
const fixture={subjects:[subject],active:subject.id,subjectScope:subject.id,activeNote:'nota-test',view:'notes',railOpen:false,theme:'light',settings:{userName:'Prueba de interfaz',lang:'es'},homeBoard:[],schedule:[],deleted:{},library:[],tfmAdded:true,seeded2627:true};
const mail=(uid,subject,body)=>({uid,from:'ana.prueba@uv.es',from_name:'Ana Profesora',to:'estudiante@example.test',subject,body,date:new Date().toISOString(),seen:false,snippet:body.slice(0,100),attachments:[]});
const mails=[mail('m1','ADP (40493) · Tutorías','Tutorías: martes de 12:00 a 14:00\nDespacho: 2.14\nTeléfono: 963 123 456\nRecomiendo el libro «Aprendizaje visible», de John Hattie.'),mail('m2','ADP · Cambio de horario','Cambiamos el horario de clase al miércoles.'),mail('m3','ADP · Ampliación de plazo','Ampliamos el plazo de Análisis de caso hasta el '+spanish(date(10))+'.'),mail('m4','ADP · Actividades','Seminario sobre evaluación formativa el viernes.')];
fixture.settings.alerts={'mail:m5':{readAt:Date.now()-8*86400000}};mails.push({...mail('m5','ADP · Aviso caducado','Un aviso ya leído hace ocho días.'),seen:true});
let browser,server,sends=0;const errors=[];
(async()=>{
  fs.mkdirSync(out,{recursive:true});
  server=http.createServer(async(req,res)=>{try{
    const url=new URL(req.url,'http://localhost');let data='';for await(const chunk of req)data+=chunk;
    const json=value=>{res.setHeader('Content-Type','application/json');res.end(JSON.stringify(value));};
    if(url.pathname==='/api/datos')return json({state:JSON.parse(data)});
    if(url.pathname==='/api/correos')return json({configured:true,user:'prueba',mails});
    if(url.pathname==='/api/estado')return json({configured:true,user:'prueba',ok:true});
    if(url.pathname==='/api/correo/carpetas')return json({folders:[]});
    if(url.pathname==='/api/correo/enviar'){sends++;return json({sent:true});}
    if(url.pathname.startsWith('/api/'))return json({ok:true});
    const file=path.resolve(root,'.'+decodeURIComponent(url.pathname==='/'?'/cuaderno-apuntes.html':url.pathname));
    if(!file.startsWith(root+path.sep)||!fs.existsSync(file)){res.statusCode=404;return res.end();}
    res.setHeader('Content-Type',({'.html':'text/html','.js':'text/javascript','.png':'image/png','.wav':'audio/wav','.mp3':'audio/mpeg','.webmanifest':'application/manifest+json'})[path.extname(file)]||'application/octet-stream');res.end(fs.readFileSync(file));
  }catch(e){res.statusCode=500;res.end(e.message);}});
  await new Promise(r=>server.listen(0,'127.0.0.1',r));
  browser=await chromium.launch({executablePath:process.env.CHROME_PATH||'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});
  const p=await browser.newPage({viewport:{width:1440,height:1000}});p.setDefaultTimeout(10000);p.on('pageerror',e=>errors.push(e.message));
  await p.addInitScript(f=>{if(window.top===window){localStorage.setItem('cuaderno-apuntes-v1',JSON.stringify(f));localStorage.setItem('cuaderno-correo-preguntado','1');}},fixture);
  await p.goto('http://127.0.0.1:'+server.address().port);await p.waitForTimeout(3500);
  const saved=async()=>{await p.keyboard.press('Meta+s');await p.waitForTimeout(500);return p.evaluate(()=>JSON.parse(localStorage.getItem('cuaderno-apuntes-v1')));};
  let state=await saved(),s=state.subjects.find(s=>s.id==='curso-test');assert.equal(s.teachers.length,1);assert.match(s.teachers[0].room,/2.14/);assert.match(s.teachers[0].hours,/martes/);assert.equal(s.biblio.length,1);assert.equal(s.biblio[0].title,'Aprendizaje visible');assert.equal(s.biblio[0].authors,'John Hattie');assert.equal(s.tasks[0].due,date(10));console.log('PASS teacher extraction, book provenance and deadline update');
  await p.locator('#tabTasks').click();assert(await p.locator('.task.pending').count());await p.locator('.task-title').dblclick();assert(await p.locator('.t-info').isVisible());await p.locator('.tcheck').check();assert(await p.locator('.task.done').count());console.log('PASS task description and status colors');
  await p.locator('#alertsBtn').click();assert.match(await p.locator('#alertsBody').innerText(),/Cambios de horario y clases/i);assert.match(await p.locator('#alertsBody').innerText(),/Actividades/i);assert.doesNotMatch(await p.locator('#alertsBody').innerText(),/Aviso caducado/);
  const notice=p.locator('.al-item').filter({hasText:'Cambio de horario'});await notice.locator('[data-a=ok]').click();assert(await notice.isVisible());assert.match(await notice.innerText(),/Leído/);await notice.locator('[data-a=dismiss]').click();assert.equal(await notice.count(),0);console.log('PASS categorized alerts, read retention and explicit dismissal');
  await p.locator('#tabNotes').click();await p.locator('#globalSubjectFilter').selectOption('curso-test');
  await p.locator('.page-running-header textarea').first().fill('Cabecera de prueba');
  await p.locator('.page-running-footer textarea').first().fill('Pie de prueba');
  state=await saved();const n=state.subjects.find(s=>s.id==='curso-test').notes[0];assert.equal(n.header,'Cabecera de prueba');assert.equal(n.footer,'Pie de prueba');assert.equal(await p.locator('.page-region-dialog').count(),0);assert.doesNotMatch(n.content,/page-running|Cabecera de prueba|Pie de prueba/);console.log('PASS inline header/footer autosave, no popup, no body contamination');
  await p.locator('#editor li').first().scrollIntoViewIfNeeded();const rect=await p.locator('#editor li').first().boundingBox();await p.mouse.dblclick(rect.x-8,rect.y+8);await p.locator('dialog[open] button').filter({hasText:'a. b. c.'}).click();await p.locator('#editor li p').nth(1).click();await p.keyboard.press('Tab');state=await saved();assert.match(state.subjects.find(s=>s.id==='curso-test').notes[0].content,/<li[^>]*list-style-type:\s*lower-alpha/);console.log('PASS individual marker selection and nested lists');
  await p.locator('.ed-scroll').evaluate(el=>el.scrollTop=0);await p.locator('.font-preview-menu summary').click();await p.screenshot({path:path.join(out,'editor.png')});await p.locator('.font-preview-menu summary').click();
  await p.locator('#homeBtn').click();await p.locator('#homeNote').click();await p.locator('.board-card textarea').fill('Notas de clase, lecturas e ideas');
  const resize=await p.locator('.board-resize').boundingBox();await p.mouse.move(resize.x+10,resize.y+10);await p.mouse.down();await p.mouse.move(resize.x+90,resize.y+70,{steps:8});await p.mouse.up();
  state=await saved();assert(state.homeBoard[0].width>300);assert(state.homeBoard[0].height>100);console.log('PASS board free resize and persistence');
  await p.locator('#uvWalk').evaluate(el=>el.classList.add('has-tip'));await p.mouse.move(800,700);await p.waitForFunction(()=>document.querySelector('#uvWalk').classList.contains('show-idea'),{},{timeout:20000});assert.equal(await p.locator('#uvWaveHand').getAttribute('opacity'),'1');await p.waitForTimeout(500);await p.screenshot({path:path.join(out,'inicio-dia.png')});console.log('PASS mascot reaches center, waves and lights idea');
  for(const width of [1440,1280,1024,768,390]){await p.setViewportSize({width,height:900});await p.waitForTimeout(250);assert(await p.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));const nav=await p.locator('.top>.seg').boundingBox(),tools=await p.locator('.topx').boundingBox();assert(nav.y+nav.height<=tools.y||tools.y+tools.height<=nav.y||nav.x+nav.width<=tools.x||tools.x+tools.width<=nav.x);}
  console.log('PASS responsive navigation without overlap at 5 widths');
  await p.setViewportSize({width:1280,height:900});await p.locator('#railToggle').click();await p.waitForTimeout(400);await p.screenshot({path:path.join(out,'barra-expandida.png')});await p.locator('#railToggle').click();
  await p.locator('#themeBtn').click();await p.screenshot({path:path.join(out,'inicio-noche.png')});
  await p.setViewportSize({width:784,height:880});await p.locator('#tabNotes').click();await p.locator('#globalSubjectFilter').selectOption('curso-test');assert.equal(await p.locator('#globalSubjectFilter').isVisible(),false);await p.screenshot({path:path.join(out,'editor-estrecho.png')});
  const rail=await p.locator('#rail').boundingBox();assert(rail.x>0&&rail.y>0&&rail.y+rail.height<880);console.log('PASS complete sidebar frame and no redundant selector');
  assert(await p.locator('#listToggle').isVisible());assert.match(await p.locator('#listToggle').innerText(),/Lista de apuntes/);assert(!(await p.locator('#notesPanel').isVisible()));
  await p.locator('#listToggle').click();await p.waitForTimeout(250);assert(await p.locator('#notesPanel').isVisible());assert.equal(await p.locator('#search').evaluate(el=>el===document.activeElement),true);
  await p.locator('#notesList .item').first().click();await p.waitForTimeout(250);assert(!(await p.locator('#notesPanel').isVisible()));
  await p.locator('#listToggle').click();await p.waitForTimeout(250);await p.locator('#notesDrawerClose').click();await p.waitForTimeout(250);assert(!(await p.locator('#notesPanel').isVisible()));
  await p.locator('#listToggle').click();await p.waitForTimeout(250);await p.locator('#notesListBackdrop').click({position:{x:500,y:100}});await p.waitForTimeout(250);assert(!(await p.locator('#notesPanel').isVisible()));
  await p.setViewportSize({width:1440,height:900});await p.waitForTimeout(250);assert(await p.locator('#notesPanel').isVisible());assert.equal(await p.locator('#notesPanel').evaluate(el=>el.inert),false);console.log('PASS discoverable notes drawer, focus, close controls and desktop restore');
  const tabletContext=await browser.newContext({viewport:{width:820,height:1180},hasTouch:true,isMobile:true});const tablet=await tabletContext.newPage();
  await tablet.goto('http://127.0.0.1:'+server.address().port+'/ipad/vista-previa/cuaderno-apuntes.html');await tablet.evaluate(async()=>{await navigator.serviceWorker.ready;});await tablet.waitForTimeout(1200);await tablet.evaluate(()=>{for(const d of document.querySelectorAll('dialog[open]'))d.close();});await tablet.waitForTimeout(400);await tablet.screenshot({path:path.join(out,'ipad.png')});await tabletContext.setOffline(true);await tablet.reload();assert.equal(await tablet.title(),'Cuaderno');assert(await tablet.locator('#homeBtn').isVisible());console.log('PASS touch edition installs its cache and reloads offline');await tabletContext.close();
  assert.equal(sends,0);assert.deepEqual(errors,[]);console.log('PASS no real messages sent and no page errors');
})().catch(e=>{console.error(e);process.exitCode=1;}).finally(async()=>{await browser?.close();await new Promise(r=>server?server.close(r):r());});
