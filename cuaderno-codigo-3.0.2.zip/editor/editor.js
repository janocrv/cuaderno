/* Motor de Cuaderno. El HTML sigue siendo el formato de intercambio y de las copias.
   Las páginas son decoraciones: nunca se guardan dentro del apunte. */
import { Editor, Extension, Node, mergeAttributes, wrappingInputRule } from '@tiptap/core';
import StarterKit from '@tiptap/starter-kit';
import { ListItem } from '@tiptap/extension-list';
import { TextStyleKit } from '@tiptap/extension-text-style';
import TextAlign from '@tiptap/extension-text-align';
import Highlight from '@tiptap/extension-highlight';
import Image from '@tiptap/extension-image';
import { TablePlus, TableRowPlus, TableCellPlus, TableHeaderPlus } from 'tiptap-table-plus';
import { PaginationPlus } from 'tiptap-pagination-plus';
import { EditorState, TextSelection } from '@tiptap/pm/state';
import { closeHistory } from '@tiptap/pm/history';
import { DOMSerializer } from '@tiptap/pm/model';
import { CellSelection, tableEditing } from '@tiptap/pm/tables';

const PAGE = { width: 794, height: 1123, gap: 28 };
const CuadernoListItem=ListItem.extend({addAttributes(){return {...this.parent?.(),value:{default:null,keepOnSplit:false,parseHTML:el=>el.hasAttribute('value')?Number(el.getAttribute('value')):null,renderHTML:a=>a.value!==null?{value:a.value}:{}}};}});
const TableSelection = Extension.create({ name:'cuadernoTableSelection', addProseMirrorPlugins(){return [tableEditing()];} });
const CuadernoTable = TablePlus.extend({
  content:'tableRow+',
  addExtensions(){return (this.parent?.()||[]).filter(extension=>extension.name!=='tableRowGroup');},
  addAttributes() { return { ...this.parent?.(), width: { default: null, parseHTML: el => el.style.width || null, renderHTML: attrs => attrs.width ? { style: `width:${attrs.width}` } : {} },
    floating:{default:false,parseHTML:el=>el.dataset.tableFloating==='true',renderHTML:a=>a.floating?{'data-table-floating':'true'}:{}},
    x:{default:68,parseHTML:el=>Number(el.dataset.tableX)||68,renderHTML:a=>({'data-table-x':a.x})},
    y:{default:64,parseHTML:el=>Number(el.dataset.tableY)||64,renderHTML:a=>({'data-table-y':a.y})},
  }; },
  addNodeView(){return ({node})=>{
    const dom=document.createElement('div'),contentDOM=document.createElement('table');dom.className='cuaderno-table';contentDOM.className='nt table-plus';dom.append(contentDOM);
    const paint=()=>{let count=0;node.descendants(n=>{if(n.type.name==='tableRow'){let cols=0;n.forEach(c=>cols+=c.attrs.colspan||1);count=Math.max(count,cols);return false;}});const sizes=(node.attrs.columnSize||'').split(',').map(Number);dom.style.width=node.attrs.width||'100%';dom.dataset.floating=String(node.attrs.floating);dom.style.position=node.attrs.floating?'absolute':'relative';dom.style.left=node.attrs.floating?node.attrs.x+'px':'';dom.style.top=node.attrs.floating?node.attrs.y+'px':'';dom.style.margin=node.attrs.floating?'0':'';dom.style.setProperty('--cell-percentage',(sizes.length===count&&sizes.every(n=>n>0)?sizes:Array(count).fill(100/count)).map(n=>n+'%').join(' '));};paint();
    return {dom,contentDOM,update(next){if(next.type!==node.type)return false;node=next;paint();return true;},ignoreMutation(m){return m.type!=='selection'&&(m.target===dom||m.target===contentDOM&&m.attributeName==='class');}};
  };},
});
const CuadernoRow = TableRowPlus.extend({
  addAttributes() { return { ...this.parent?.(), height: { default: null, parseHTML: el => el.style.height || null, renderHTML: attrs => attrs.height ? { style: `height:${attrs.height}` } : {} } }; },
  addNodeView(){return ({node})=>{const dom=document.createElement('tr');const paint=()=>{dom.style.display='grid';dom.style.gridTemplateColumns='var(--cell-percentage)';dom.style.position='relative';dom.style.minHeight=node.attrs.height||'';};paint();return {dom,contentDOM:dom,update(next){if(next.type!==node.type)return false;node=next;paint();return true;},ignoreMutation(m){return m.type==='attributes'&&m.target===dom;}};};},
});
const Blocks = Extension.create({
  name: 'cuadernoStyles',
  addKeyboardShortcuts() { return {
    Space: () => {
      const {state,view}=this.editor,{$from,empty}=state.selection;
      if(!empty||$from.parent.type.name!=='paragraph'||!/^[-*–•]$/.test($from.parent.textContent)||$from.parentOffset!==1)return false;
      if(this.editor.isActive('orderedList')&&$from.depth>=3){
        const itemDepth=$from.depth-1;
        if($from.node(itemDepth).type.name==='listItem'&&$from.index(itemDepth-1)>0)return this.editor.chain().deleteRange({from:$from.start(),to:$from.end()}).sinkListItem('listItem').toggleBulletList().run();
      }
      if($from.depth===1&&$from.index(0)>0){
        const previous=state.doc.child($from.index(0)-1);
        if(previous.type.name!=='orderedList')return false;
        const pos=$from.before(1),insert=pos-2,nested=state.schema.nodes.bulletList.create(null,state.schema.nodes.listItem.create(null,state.schema.nodes.paragraph.create()));
        const tr=state.tr.delete(pos,pos+$from.parent.nodeSize).insert(insert,nested);tr.setSelection(TextSelection.create(tr.doc,insert+3));view.dispatch(tr.scrollIntoView());return true;
      }
      return false;
    },
    Tab: () => this.editor.isActive('listItem') ? this.editor.commands.sinkListItem('listItem') : false,
    'Shift-Tab': () => this.editor.isActive('listItem') ? this.editor.commands.liftListItem('listItem') : false,
  }; },
  addGlobalAttributes() {
    return [{ types: ['paragraph', 'heading', 'blockquote', 'bulletList', 'orderedList', 'listItem', 'tableCell', 'tableHeader'], attributes: {
      style: { default: null, parseHTML: el => { const s = document.createElement('span'); s.style.cssText = el.getAttribute('style') || ''; s.style.removeProperty('text-align'); return s.style.cssText || null; }, renderHTML: a => a.style ? { style: a.style } : {} },
    } }, { types: ['orderedList'], attributes: { type: { default: null, parseHTML: el => el.getAttribute('type'), renderHTML: a => a.type ? { type: a.type } : {} } } }];
  },
  addInputRules() { return [
    wrappingInputRule({ find: /^\s*(\d{1,3})[.)-]\s$/, type: this.editor.schema.nodes.orderedList, getAttributes: m => ({ start: Number(m[1]) }) }),
    wrappingInputRule({ find: /^\s*a[.)]\s$/i, type: this.editor.schema.nodes.orderedList, getAttributes: () => ({ type: 'a' }) }),
    wrappingInputRule({ find: /^\s*[•–]\s$/, type: this.editor.schema.nodes.bulletList }),
  ]; },
  addCommands() {
    return {
      paragraphStyle: (property, value) => ({ tr, state, dispatch }) => {
        const { from, to } = state.selection;
        state.doc.nodesBetween(from, to, (node, pos) => {
          if (!['paragraph', 'heading'].includes(node.type.name)) return;
          const el = document.createElement('span'); el.style.cssText = node.attrs.style || '';
          el.style[property] = typeof value === 'function' ? value(el.style[property]) : value;
          if (dispatch) tr.setNodeMarkup(pos, undefined, { ...node.attrs, style: el.style.cssText || null });
        });
        return true;
      },
    };
  },
});
const Attachment = Node.create({
  name: 'attachment', group: 'inline', inline: true, atom: true,
  addAttributes() { return {
    fid: { default: '', parseHTML: el => el.dataset.fid, renderHTML: a => ({ 'data-fid': a.fid }) },
    label: { default: '', parseHTML: el => el.textContent, renderHTML: () => ({}) },
  }; },
  parseHTML() { return [{ tag: 'span.att[data-fid]' }]; },
  renderHTML({ node, HTMLAttributes }) { return ['span', mergeAttributes(HTMLAttributes, { class: 'att', contenteditable: 'false' }), node.attrs.label]; },
});
const NoteImage = Image.extend({
  addAttributes() { return { ...this.parent?.(),
    fid: { default: null, parseHTML: el => el.dataset.fid, renderHTML: a => a.fid ? { 'data-fid': a.fid } : {} },
    style: { default: null, parseHTML: el => el.style.cssText || null, renderHTML: a => a.style ? { style: a.style } : {} },
    class: { default: 'att-img', parseHTML: el => [...el.classList].filter(c => c !== 'sel' && c !== 'grab').join(' '), renderHTML: a => ({ class: a.class || 'att-img' }) },
  }; },
  parseHTML() { return [{ tag: 'img' }]; },
  addNodeView() { return ({ node }) => {
    const img = document.createElement('img');
    const paint = current => {
      const a = current.attrs;
      img.className = a.class || 'att-img'; img.style.cssText = a.style || '';
      img.alt = a.alt || ''; if (a.title) img.title = a.title;
      if (a.fid) img.dataset.fid = a.fid;
      if (a.src && img.getAttribute('src') !== a.src) img.src = a.src;
    };
    paint(node);
    return { dom: img,
      update(next) { if (next.type !== node.type) return false; node = next; paint(next); return true; },
      // Loading a local blob and showing selection must not change note content/history.
      ignoreMutation(m) { return m.type === 'attributes'; },
    };
  }; },
}).configure({ allowBase64: true });
// Keep the sticky body in the document model; its controls remain outside contentDOM.
function stickySpec(HTMLAttributes) { return ['div', mergeAttributes(HTMLAttributes, { class: 'sticky', contenteditable: 'false' }),
  ['div', { class: 'st-bar', contenteditable: 'false', title: 'Arrastra la nota por aquí (puedes sacarla del folio)' },
    ['button', { type: 'button', class: 'st-col', title: 'Color de la nota' }], ['button', { type: 'button', class: 'st-x', title: 'Quitar la nota' }, '×']],
  ['div', { class: 'st-body', contenteditable: 'true' }, 0],
  ['button', { type: 'button', class: 'st-rot', title: 'Arrastra para girar la nota', contenteditable: 'false' }, '↻'],
  ['button', { type: 'button', class: 'st-size', title: 'Tamaño: arrastra hacia fuera para agrandar la nota y hacia dentro para hacerla más pequeña', contenteditable: 'false' }, '⤢'],
]; }
const Sticky = Node.create({
  name: 'sticky', group: 'block', content: 'block+', isolating: true, selectable: false,
  addAttributes() { return {
    col: { default: 'amarillo', parseHTML: el => el.dataset.col, renderHTML: a => ({ 'data-col': a.col }) },
    style: { default: '', parseHTML: el => el.style.cssText || '', renderHTML: a => ({ style: a.style || '' }) },
  }; },
  parseHTML() { return [{ tag: 'div.sticky', contentElement: '.st-body' }]; },
  renderHTML({ HTMLAttributes }) { return stickySpec(HTMLAttributes); },
  addNodeView() { return ({ node }) => {
    const { dom, contentDOM } = DOMSerializer.renderSpec(document, stickySpec({ style: node.attrs.style, 'data-col': node.attrs.col }));
    return { dom, contentDOM,
      update(next) { if (next.type !== node.type) return false; node = next; dom.style.cssText = next.attrs.style || ''; dom.dataset.col = next.attrs.col; return true; },
      ignoreMutation(m) { return m.type !== 'selection' && (m.target === dom || !contentDOM.contains(m.target)); },
    };
  }; },
});

function legacyHTML(html) {
  const box = document.createElement('div'); box.innerHTML = html || '';
  // Chromium's old formatBlock/indent output. Preserve inherited formatting on the leaves.
  for (const div of [...box.querySelectorAll('div:not(.sticky):not(.sticky *)')].reverse()) {
    const p = document.createElement('p');
    for (const attr of div.attributes) p.setAttribute(attr.name, attr.value);
    if (div.querySelector('p,div,h1,h2,h3,h4,ul,ol,table,blockquote')) {
      for (const child of div.children) {
        const own = child.getAttribute('style') || '';
        child.setAttribute('style', `${div.getAttribute('style') || ''};${own}`);
        if (div.getAttribute('align') && !child.style.textAlign) child.style.textAlign = div.getAttribute('align');
      }
      div.replaceWith(...div.childNodes);
    } else { p.append(...div.childNodes); div.replaceWith(p); }
  }
  for (const font of box.querySelectorAll('font')) {
    const span = document.createElement('span'); span.style.cssText = font.style.cssText;
    if (font.face) span.style.fontFamily = font.face;
    if (font.color) span.style.color = font.color;
    if (font.size) span.style.fontSize = `${[0, 8, 10, 12, 14, 18, 24, 36][Number(font.size)] || 12}pt`;
    span.append(...font.childNodes); font.replaceWith(span);
  }
  for (const el of box.querySelectorAll('[align]')) { el.style.textAlign = el.style.textAlign || el.getAttribute('align'); el.removeAttribute('align'); }
  for(const table of box.querySelectorAll('table[data-column-size]')){
    const sizes=(table.dataset.columnSize||'').split(',').map(Number);if(!sizes.length||sizes.some(n=>!Number.isFinite(n)||n<=0))continue;
    const width=parseFloat(table.style.width)||658;
    for(const row of table.rows){let col=0;for(const cell of row.cells){const span=cell.colSpan||1;cell.setAttribute('colwidth',sizes.slice(col,col+span).map(n=>Math.round(width*n/100)).join(','));col+=span;}}
  }
  return box.innerHTML;
}

window.CuadernoEditor = { mount(old) {
  const viewport = document.createElement('div'); viewport.className = 'page-viewport';
  const stage = document.createElement('div'); stage.className = 'page-stage';
  const sheets = document.createElement('div'); sheets.className = 'page-sheets'; sheets.setAttribute('aria-hidden', 'true');
  const host = document.createElement('div'); host.className = 'editor-host';
  const runningRegions=document.createElement('div');runningRegions.className='page-running-regions';
  old.replaceWith(viewport); viewport.append(stage); stage.append(sheets, host, runningRegions);
  let loading = false, notifyPending = false, layoutFrame = 0, zoom = 'fit', editor, original = '', dirty = false, generation = 0,serialized=null;
  let runningHeader='',runningFooter='',regionChange=null;
  const regionValue=field=>field==='header'?runningHeader:runningFooter;
  function allowFloatingNotes(){
    const stageRect=stage.getBoundingClientRect(),scale=stageRect.width/PAGE.width;if(!scale)return;
    const holes=[];
    for(const el of editor.view.dom.querySelectorAll('.sticky,.st-pal,.cuaderno-table[data-floating="true"]')){const r=el.getBoundingClientRect();if(!r.width||!r.height)continue;let box={l:Math.max(0,(r.left-stageRect.left)/scale-3),t:Math.max(0,(r.top-stageRect.top)/scale-3),r:Math.min(PAGE.width,(r.right-stageRect.left)/scale+3),b:(r.bottom-stageRect.top)/scale+3};if(box.r<=box.l)continue;
      for(let i=holes.length-1;i>=0;i--){const other=holes[i];if(box.l<=other.r&&box.r>=other.l&&box.t<=other.b&&box.b>=other.t){box={l:Math.min(box.l,other.l),t:Math.min(box.t,other.t),r:Math.max(box.r,other.r),b:Math.max(box.b,other.b)};holes.splice(i,1);i=holes.length;}}
      holes.push(box);
    }
    const rect=(l,t,r,b)=>`M${l} ${t}H${r}V${b}H${l}Z`,height=Math.max(PAGE.height,runningRegions.children.length*(PAGE.height+PAGE.gap));
    runningRegions.style.clipPath=holes.length?'path(evenodd, "'+rect(0,0,PAGE.width,height)+' '+holes.map(b=>rect(b.l,b.t,b.r,b.b)).join(' ')+'")':'';
  }
  function paintRunningRegions(count){
    while(runningRegions.children.length>count)runningRegions.lastElementChild.remove();
    while(runningRegions.children.length<count){
      const page=document.createElement('div');page.className='page-running-page';
      for(const field of ['header','footer']){
        const region=document.createElement('div');region.className='page-running-region page-running-'+field;region.dataset.field=field;
        const input=document.createElement('textarea');input.className='page-running-input';input.dataset.field=field;input.dataset.noi18n='';input.rows=1;input.maxLength=240;input.spellcheck=true;input.autocomplete='off';input.value=regionValue(field);
        region.append(input);page.append(region);
        region.addEventListener('pointerdown',event=>{if(event.target!==input){event.preventDefault();input.focus();}});
        input.addEventListener('focus',()=>{region.classList.add('editing');stage.classList.add('editing-page-region');});
        input.addEventListener('blur',()=>{region.classList.remove('editing');stage.classList.remove('editing-page-region');input.scrollTop=0;});
        input.addEventListener('input',()=>{if(field==='header')runningHeader=input.value;else runningFooter=input.value;for(const other of runningRegions.querySelectorAll('.page-running-input'))if(other!==input&&other.dataset.field===field)other.value=input.value;regionChange?.(field,input.value);});
        input.addEventListener('keydown',event=>{if(event.key==='Escape'||((event.ctrlKey||event.metaKey)&&event.key==='Enter')){event.preventDefault();editor.commands.focus();}});
      }
      const number=document.createElement('span');number.className='page-running-number';page.append(number);runningRegions.append(page);
    }
    const ca=document.documentElement.lang==='ca';
    const signature=[count,runningHeader,runningFooter,ca].join('\u0001');if(runningRegions.dataset.signature===signature)return;runningRegions.dataset.signature=signature;
    [...runningRegions.children].forEach((page,index)=>{page.style.top=`${index*(PAGE.height+PAGE.gap)}px`;page.querySelector('.page-running-number').textContent=String(index+1);for(const region of page.querySelectorAll('.page-running-region')){const field=region.dataset.field,label=field==='header'?(ca?'Capçalera de pàgina':'Encabezado de página'):(ca?'Peu de pàgina':'Pie de página'),input=region.querySelector('textarea');region.dataset.label=label;input.placeholder=label;input.setAttribute('aria-label',label+' · '+(index+1));input.lang=ca?'ca':'es';if(document.activeElement!==input)input.value=regionValue(field);}});
  }
  const notify = () => {
    if (loading || notifyPending) return;
    notifyPending = true;
    const current = generation;
    queueMicrotask(() => { notifyPending = false; if (!loading && current === generation) editor.view.dom.dispatchEvent(new Event('input', { bubbles: true })); });
  };
  const layout = () => {
    if(layoutFrame)return;
    layoutFrame = requestAnimationFrame(() => {
      layoutFrame=0;
      if (!host.offsetWidth) return;
      const count = Math.max(1, editor.view.dom.querySelectorAll('.rm-page-break').length);
      runningRegions.style.color=getComputedStyle(editor.view.dom).color;
      const empty=String(editor.isEmpty);if(editor.view.dom.dataset.empty!==empty)editor.view.dom.dataset.empty=empty;
      while (sheets.children.length > count) sheets.lastElementChild.remove();
      while (sheets.children.length < count) { const page = document.createElement('div'); page.className = 'page-sheet'; sheets.append(page); }
      paintRunningRegions(count);
      [...sheets.children].forEach((page, i) => { page.style.top = `${i * (PAGE.height + PAGE.gap)}px`; });
      const scale = zoom === 'fit' ? Math.min(1, viewport.clientWidth / PAGE.width) : Number(zoom) / 100;
      stage.style.zoom = String(Math.max(.25, scale));
      allowFloatingNotes();
      const label = document.getElementById('pageCount');
      if (label) { const ca = document.documentElement.lang === 'ca'; label.textContent = count + (count === 1 ? (ca ? ' pàgina' : ' página') : (ca ? ' pàgines' : ' páginas')); }
      const pct = document.getElementById('pageZoomValue'); if (pct) pct.textContent = `${Math.round(scale * 100)} %`;
    });
  };
  editor = new Editor({
    element: host, injectCSS: true, content: '<p></p>',
    editorProps: { attributes: { id: 'editor', class: 'editor', spellcheck: 'true', 'aria-label': 'Texto del apunte', 'data-placeholder': 'Empieza a escribir…' } },
    extensions: [
      StarterKit.configure({ heading: { levels: [1, 2, 3, 4] }, link: { openOnClick: false },listItem:false }),CuadernoListItem,
      TextStyleKit.configure({ backgroundColor: false }), Blocks,
      TextAlign.configure({ types: ['heading', 'paragraph'], defaultAlignment: null }),
      Highlight.extend({ parseHTML() { return [{ tag: 'mark' }, { style: 'background-color', getAttrs: color => ({ color }) }]; } }).configure({ multicolor: true }), NoteImage, Attachment, Sticky,
      CuadernoTable.configure({ HTMLAttributes: { class: 'nt' }, borderColor:'var(--line)' }), CuadernoRow, TableCellPlus, TableHeaderPlus, TableSelection,
      PaginationPlus.configure({ pageWidth: PAGE.width, pageHeight: PAGE.height, pageGap: PAGE.gap,
        marginTop: 64, marginBottom: 44, marginLeft: 68, marginRight: 68,
        contentMarginTop: 0, contentMarginBottom: 12, pageGapBorderSize: 0, pageGapBorderColor: 'transparent',
        pageBreakBackground: 'var(--surface)', headerLeft: '', headerRight: '', footerLeft: '', footerRight: '',
      }),
    ],
    onUpdate: () => { if (!loading) dirty = true; serialized=null;notify(); layout(); },
    onSelectionUpdate: () => document.dispatchEvent(new Event('selectionchange')),
    onTransaction: ({transaction}) => {if(transaction.docChanged)layout();},
  });
  const observer = new MutationObserver(layout); observer.observe(editor.view.dom, { childList: true, subtree: true,attributes:true,attributeFilter:['data-paper'] });
  editor.view.dom.addEventListener('dblclick', event => {
    const item = event.target.closest('li');
    if (!item || !editor.view.dom.contains(item) || event.clientX > item.getBoundingClientRect().left + 4) return;
    const list = item.parentElement;
    if (!list.matches('ul,ol')) return;
    event.preventDefault();
    const position = editor.view.posAtDOM(item, 0) - 1, original = editor.state.doc.nodeAt(position);
    if (!original || original.type.name!=='listItem') return;
    const ca = document.documentElement.lang === 'ca', dialog = document.createElement('dialog');
    dialog.setAttribute('aria-label', ca ? 'Símbol de la llista' : 'Símbolo de la lista');
    dialog.style.cssText = 'border:1px solid var(--line);border-radius:18px;padding:20px;background:var(--surface);color:var(--ink);max-width:320px';
    const label = document.createElement('p'); label.textContent = ca?'Canvia només este element':'Cambiar solo este elemento'; dialog.append(label);
    const apply=(marker,value=null)=>{
      if(editor.state.doc.nodeAt(position)!==original)return;
      const style=document.createElement('span');style.style.cssText=original.attrs.style||'';style.style.listStyleType=marker;
      if(value!==null&&list.tagName==='UL')style.style.counterSet='list-item '+value;else style.style.removeProperty('counter-set');
      const tr=editor.state.tr;if(value!==null&&list.tagName==='OL'){
        let number=Number(list.getAttribute('start'))||1;for(const sibling of list.children){if(sibling===item)break;if(sibling.hasAttribute('value'))number=Number(sibling.getAttribute('value'));number++;}
        if(item.hasAttribute('value'))number=Number(item.getAttribute('value'));
        const next=editor.state.doc.nodeAt(position+original.nodeSize);if(next?.type.name==='listItem'&&next.attrs.value===null)tr.setNodeMarkup(position+original.nodeSize,undefined,{...next.attrs,value:number+1});
      }
      tr.setNodeMarkup(position,undefined,{...original.attrs,style:style.style.cssText,value:value??original.attrs.value});editor.view.dispatch(closeHistory(tr));dialog.close();editor.commands.focus();
    };
    for (const [name, ordered, type, marker] of [['1. 2. 3.',true,'1','decimal'],['a. b. c.',true,'a','lower-alpha'],['I. II. III.',true,'I','upper-roman'],['•',false,null,'disc'],['◦',false,null,'circle'],['▪',false,null,'square'],['—',false,null,'"—  "']]) {
      const button = document.createElement('button'); button.type = 'button'; button.textContent = name; button.className = 'btn'; button.style.margin = '4px';
      button.onclick = () => {
        apply(marker);
      }; dialog.append(button);
    }
    const numberRow=document.createElement('form');numberRow.style.cssText='display:flex;gap:8px;align-items:center;margin:14px 0;flex-wrap:wrap';
    const numberLabel=document.createElement('label');numberLabel.textContent=ca?'Número d’este element':'Número de este elemento';const numberInput=document.createElement('input');numberInput.type='number';numberInput.min='0';numberInput.max='99999';numberInput.setAttribute('aria-label',numberLabel.textContent);numberInput.style.cssText='width:76px;padding:7px;border:1px solid var(--line);border-radius:7px;background:var(--surface);color:var(--ink)';
    let number=Number(list.getAttribute('start'))||1;for(const sibling of list.children){if(sibling.hasAttribute('value'))number=Number(sibling.getAttribute('value'));if(sibling===item)break;number++;}numberInput.value=String(number);numberLabel.append(numberInput);const setNumber=document.createElement('button');setNumber.type='submit';setNumber.className='btn primary';setNumber.textContent=ca?'Aplica el número':'Aplicar número';numberRow.append(numberLabel,setNumber);numberRow.onsubmit=e=>{e.preventDefault();const value=Number(numberInput.value);if(Number.isInteger(value)&&value>=0&&value<=99999)apply('decimal',value);};dialog.append(numberRow);
    const close = document.createElement('button'); close.className = 'btn'; close.textContent = ca ? 'Tancar' : 'Cerrar'; close.onclick = () => dialog.close(); dialog.append(close);
    dialog.addEventListener('close', () => dialog.remove(), { once: true }); document.body.append(dialog); dialog.showModal();
  });
  new ResizeObserver(layout).observe(viewport);
  new MutationObserver(layout).observe(document.documentElement, { attributes: true, attributeFilter: ['lang', 'data-theme','style'] });

  const domSelection = () => {
    if (!(editor.state.selection instanceof TextSelection)) return;
    const sel = getSelection(); if (!sel.rangeCount || !editor.view.dom.contains(sel.anchorNode)) return;
    try {
      const from = editor.view.posAtDOM(sel.anchorNode, sel.anchorOffset), to = editor.view.posAtDOM(sel.focusNode, sel.focusOffset);
      if (from !== editor.state.selection.anchor || to !== editor.state.selection.head) editor.view.dispatch(editor.state.tr.setSelection(TextSelection.between(editor.state.doc.resolve(from), editor.state.doc.resolve(to))));
    } catch (_) { /* A removed attachment can leave a stale DOM range. */ }
  };
  const sync = () => {
    // Floating object tools edit their DOM during pointer movement; commit once on release.
    const changes = [];
    editor.state.doc.descendants((node, pos) => {
      if (!['image', 'sticky'].includes(node.type.name)) return;
      const dom = editor.view.nodeDOM(pos); if (!dom?.isConnected) return;
      const attrs = { ...node.attrs, style: dom.getAttribute('style') || null };
      if (node.type.name === 'sticky') attrs.col = dom.dataset.col || 'amarillo';
      if (attrs.style !== (node.attrs.style || null) || attrs.col !== node.attrs.col) changes.push({ pos, node, attrs });
    });
    editor.view.domObserver.flush();
    let tr = editor.state.tr;
    for (const { pos, node, attrs } of changes) if (tr.doc.nodeAt(pos)?.type === node.type) tr.setNodeMarkup(pos, undefined, attrs);
    if (tr.docChanged) editor.view.dispatch(tr);
    domSelection();
  };
  const topNode = el => {
    let found;
    editor.state.doc.forEach((node, pos) => { const dom = editor.view.nodeDOM(pos); if (dom && (dom === el || dom.contains(el))) found = { node, pos, dom }; });
    return found;
  };
  const move = (el, ref, after) => {
    sync(); const from = topNode(el), target = topNode(ref); if (!from || !target || from.pos === target.pos) return false;
    const tr = editor.state.tr.delete(from.pos, from.pos + from.node.nodeSize);
    const to = tr.mapping.map(target.pos + (after ? target.node.nodeSize : 0));
    tr.insert(to, from.node); tr.setSelection(TextSelection.near(tr.doc.resolve(Math.min(to + 1, tr.doc.content.size))));
    editor.view.dispatch(tr); return true;
  };
  const command = (cmd, value) => {
    sync(); const chain = editor.chain().focus();
    const names = { bold: 'toggleBold', italic: 'toggleItalic', underline: 'toggleUnderline', strike: 'toggleStrike', insertUnorderedList: 'toggleBulletList', insertOrderedList: 'toggleOrderedList', undo: 'undo', redo: 'redo', hr: 'setHorizontalRule' };
    if (names[cmd]) return chain[names[cmd]]().run();
    if (cmd === 'fontName') return chain.setFontFamily(value).run();
    if (cmd === 'fontSize') return chain.setFontSize(`${value}pt`).run();
    if (cmd === 'color') return value ? chain.setColor(value).run() : chain.unsetColor().run();
    if (cmd === 'mark') return chain.toggleHighlight({ color: '#ffe36e' }).run();
    if (cmd === 'lineHeight') return chain.paragraphStyle('lineHeight', value).run();
    if (cmd === 'spaceAfter') return chain.paragraphStyle('marginBottom', `${value}pt`).run();
    if (cmd === 'firstLine') return chain.paragraphStyle('textIndent', current => current && current !== '0px' ? '' : '1.25cm').run();
    if (cmd === 'indent' || cmd === 'outdent') {
      if (editor.isActive('listItem')) return chain[cmd === 'indent' ? 'sinkListItem' : 'liftListItem']('listItem').run();
      return chain.paragraphStyle('marginLeft', current => `${Math.max(0, Math.min(12, (parseFloat(current) || 0) + (cmd === 'indent' ? 2 : -2)))}em`).run();
    }
    const align = { justifyLeft: 'left', justifyCenter: 'center', justifyRight: 'right', justifyFull: 'justify' }[cmd];
    if (align) return chain.setTextAlign(editor.isActive({ textAlign: align }) && align !== 'left' ? 'left' : align).run();
    if (cmd === 'removeFormat') return chain.unsetAllMarks().clearNodes().paragraphStyle('lineHeight', '').paragraphStyle('marginLeft', '').paragraphStyle('textIndent', '').paragraphStyle('marginBottom', '').unsetTextAlign().run();
    return false;
  };
  return {
    editor, sync, command, layout, move,
    remove(el) { const found = topNode(el); return found ? editor.chain().command(({tr})=>{closeHistory(tr);return true;}).deleteRange({ from: found.pos, to: found.pos + found.node.nodeSize }).run() : false; },
    blockDOM(el) { return topNode(el)?.dom || null; },
    moveStep(el, dir) {
      const current = topNode(el); if (!current) return false;
      const nodes = []; editor.state.doc.forEach((node, pos) => nodes.push({ node, pos, dom: editor.view.nodeDOM(pos) }));
      const index = nodes.findIndex(n => n.pos === current.pos), target = nodes[index + dir];
      return target ? move(el, target.dom, dir > 0) : false;
    },
    load(html) {
      if(runningRegions.contains(document.activeElement))document.activeElement.blur();
      loading = true; generation++; original = html || ''; dirty = false;serialized=null;
      try {
        editor.commands.setContent(legacyHTML(html), { emitUpdate: false });
        // History belongs to one note: Cmd+Z must never bring another note's text back.
        editor.view.updateState(EditorState.create({ schema: editor.schema, doc: editor.state.doc, plugins: editor.state.plugins }));
      } finally { loading = false; }
      layout();
    },
    html() { sync();if(!dirty)return original.replace(/\u200b/g,'');return serialized??(serialized=editor.getHTML().replace(/\u200b/g,'')); },
    block(tag) { sync(); const c = editor.chain().focus(); return tag === 'blockquote' ? c.toggleBlockquote().run() : /^h[1-4]$/.test(tag) ? c.toggleHeading({ level: Number(tag[1]) }).run() : c.setParagraph().run(); },
    table(rows, cols) { sync(); return editor.chain().focus().insertTable({ rows, cols, withHeaderRow: true }).run(); },
    tablePosition(el,x,y,width){const found=topNode(el);if(!found||found.node.type.name!=='table')return false;const attrs={...found.node.attrs,floating:x!==null,x:x??found.node.attrs.x,y:y??found.node.attrs.y,width:width?Math.round(width)+'px':found.node.attrs.width};editor.view.dispatch(closeHistory(editor.state.tr.setNodeMarkup(found.pos,undefined,attrs)));return true;},
    tableGeometry(el, widths, heights) {
      const found=topNode(el);if(!found||found.node.type.name!=='table')return false;
      const {node,pos}=found,tr=editor.state.tr;
      if(widths){const total=widths.reduce((a,b)=>a+b,0);tr.setNodeMarkup(pos,undefined,{...node.attrs,width:Math.round(total)+'px',columnSize:widths.map(w=>w*100/total).join(',')});let column=0;
        node.descendants((cell,offset)=>{if(cell.type.name==='tableRow')column=0;if(!['tableCell','tableHeader'].includes(cell.type.name))return;const span=cell.attrs.colspan||1;tr.setNodeMarkup(pos+1+offset,undefined,{...cell.attrs,colwidth:widths.slice(column,column+span).map(Math.round)});column+=span;});}
      if(heights){let index=0;node.descendants((row,offset)=>{if(row.type.name!=='tableRow')return;if(heights[index])tr.setNodeMarkup(pos+1+offset,undefined,{...row.attrs,height:Math.round(heights[index])+'px'});index++;});}
      editor.view.dispatch(closeHistory(tr));return true;
    },
    tableCommand(cmd) {
      sync(); const map = { rowAbove: 'addRowBefore', rowBelow: 'addRowAfter', colLeft: 'addColumnBefore', colRight: 'addColumnAfter', delRow: 'deleteRow', delCol: 'deleteColumn', delTable: 'deleteTable', merge: 'mergeCells', split: 'splitCell' };
      if (cmd === 'merge') { const sel = editor.state.selection; if (!(sel instanceof CellSelection) || sel.$anchorCell.index(-1) !== sel.$headCell.index(-1)) return false; }
      return map[cmd] ? editor.chain().focus().command(({tr})=>{closeHistory(tr);return true;})[map[cmd]]().run() : false;
    },
    insertText(text) { sync(); return editor.chain().focus().insertContent({ type: 'text', text }).run(); },
    replaceRange(range, text) { if (!editor.view.dom.contains(range.startContainer)) return false; const from=editor.view.posAtDOM(range.startContainer,range.startOffset),to=editor.view.posAtDOM(range.endContainer,range.endOffset); return editor.chain().focus().insertContentAt({from,to},text).run(); },
    insertHTML(html, append = false) {
      sync(); const end = editor.state.doc.content.size;
      // An attachment never replaces a selection. Use its trailing edge (or append).
      return editor.chain().focus().insertContentAt(append ? end : editor.state.selection.to, html).run();
    },
    setZoom(value) { zoom = value; layout(); },
    regions(header='',footer='') { runningHeader=header;runningFooter=footer;paintRunningRegions(Math.max(1,sheets.children.length)); },
    onRegionChange(callback) { regionChange=callback; },
    active(name, attrs) { return editor.isActive(name, attrs); },
    style() { return editor.getAttributes('textStyle'); },
  };
} };
