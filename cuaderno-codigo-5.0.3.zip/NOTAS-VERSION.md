# Cuaderno 5.0.3

- **Inicio mejor maquetado:** desaparece la franja vacía de arriba. El saludo sube hasta el borde superior y los botones de buscar, idioma, actualizar y ajustes quedan a su derecha; «+ Nota» y «+ Foto» se alinean con la frase de bienvenida. En las demás secciones la cabecera no cambia.

Incluye todas las mejoras de la versión 5.0.2. Los datos guardados se conservan al actualizar.

## Descargas

- **Mac con chip Apple:** Cuaderno-mac-arm64.dmg.
- **Mac Intel:** Cuaderno-mac-x64.dmg.
- **Windows de 64 bits:** Cuaderno-win-x64.exe.

Probado con datos ficticios. Windows físico queda pendiente de comprobación.
