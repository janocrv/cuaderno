/* Aplicación compilada, perfil temporal y servidores UV ficticios. Nunca usa claves reales. */
const {_electron}=require('playwright'),fs=require('node:fs'),os=require('node:os'),path=require('node:path'),assert=require('node:assert/strict');
const profile=fs.mkdtempSync(path.join(os.tmpdir(),'cuaderno-uv-prueba-'));
const executablePath=process.env.CUADERNO_BIN||'/Users/jano/.cuaderno-build/dist/mac-arm64/Cuaderno.app/Contents/MacOS/Cuaderno';
let app;
async function launch(){
 app=await _electron.launch({executablePath,env:{...process.env,CUADERNO_PRUEBA:profile,CUADERNO_UPDATE_API:'http://127.0.0.1:9'},timeout:60000});
 await app.evaluate(async({session})=>{
  globalThis.uvTest={authed:false,posts:0};
  await session.fromPartition('persist:cuaderno-intranet').protocol.handle('https',async request=>{
   const u=new URL(request.url),html=body=>new Response('<!doctype html><meta charset="utf-8">'+body,{headers:{'Content-Type':'text/html; charset=utf-8'}}),redirect=url=>new Response(null,{status:302,headers:{Location:url}});
   const auth='https://as.uv.es/cgi-bin/AuthServer';
   if(u.hostname==='portal.uv.es')return uvTest.authed?html('<h1>Intranet</h1><a href="/logout">Salir</a>'):redirect(auth);
   if(u.hostname==='aulavirtual.uv.es'){
    if(u.pathname==='/login/index.php')return html('<form action="/login/index.php" method="post"><input name="username"><input name="password" type="password"><button>Entrar externo</button></form><a href="/auth/saml2/login.php?idp=ficticio">Usuaris de la Universitat</a>');
    if(u.pathname==='/auth/saml2/login.php')return redirect(auth);
    return html('<div class="usermenu"><button class="userbutton">Cuenta ficticia</button></div>');
   }
   if(u.hostname==='as.uv.es'){
    let error='';if(request.method==='POST'){uvTest.posts++;const body=new URLSearchParams(await request.text());if(body.get('username')==='prueba'&&body.get('password')==='clave-ficticia'){uvTest.authed=true;return redirect('https://portal.uv.es/cgi-bin/portal/portal');}error='<div role="alert">Contraseña incorrecta</div>';}
    return html(error+'<form method="post" action="/cgi-bin/AuthServer"><label>Usuario<input name="username" autocomplete="username"></label><label>Clave<input type="password" name="password" autocomplete="current-password"></label><button type="submit">Acceder</button></form>');
   }
   return new Response('',{status:404});
  });
 });
 const p=await app.firstWindow();await p.waitForTimeout(1800);await p.evaluate(()=>{localStorage.setItem('cuaderno-correo-preguntado','1');document.querySelectorAll('dialog[open]').forEach(d=>d.close());});
 const windowPromise=app.waitForEvent('window');await p.evaluate(()=>fetch('/api/intranet/abrir',{method:'POST',body:'{}'}));
 const uv=await windowPromise;return {p,uv};
}
async function uvPage(){for(const p of app.windows())if(p.url().startsWith('https://'))return p;return app.waitForEvent('window');}
(async()=>{try{
 // Open window before awaiting its event: app.windows also covers an already delivered event.
 const first=await launch();
 const p=first.p,uv=await uvPage();uv.setDefaultTimeout(10000);await uv.waitForURL('https://as.uv.es/**');
 await uv.locator('[name="username"]').fill('prueba');await uv.locator('[name="password"]').fill('incorrecta');await uv.getByRole('button',{name:'Acceder'}).click();await uv.getByRole('alert').waitFor();
 assert.equal((await p.evaluate(()=>fetch('/api/intranet/estado').then(r=>r.json()))).saved,false);
 await uv.locator('[name="username"]').fill('prueba');await uv.locator('[name="password"]').fill('clave-ficticia');await uv.getByRole('button',{name:'Acceder'}).click();await uv.waitForURL('https://portal.uv.es/**');
 await p.waitForFunction(async()=>!!(await fetch('/api/intranet/estado').then(r=>r.json())).saved);
 const disk=fs.readFileSync(path.join(profile,'ajustes.json'),'utf8');assert(!disk.includes('clave-ficticia'));assert(!disk.includes('incorrecta'));console.log('PASS acceso fallido no guardado, acceso correcto cifrado por el sistema');
 await uv.goto('https://aulavirtual.uv.es/login/index.php');await uv.waitForURL('https://as.uv.es/**');await uv.waitForFunction(()=>document.querySelector('[type=password]').value==='clave-ficticia');assert.equal(await uv.locator('[name=username]').inputValue(),'prueba');assert.equal(await app.evaluate(()=>uvTest.posts),2);console.log('PASS Aula usa SSO UV, comparte clave y rellena sin enviar automáticamente');
 await app.close();app=null;
 // Restart with same local profile: the OS vault must decrypt the previous record.
 const second=await launch();const uv2=await uvPage();await uv2.waitForURL('https://as.uv.es/**');await uv2.waitForFunction(()=>document.querySelector('[type=password]').value==='clave-ficticia');
 await second.p.evaluate(()=>fetch('/api/intranet/olvidar',{method:'POST',body:'{}'}));await uv2.waitForTimeout(500);await uv2.waitForFunction(()=>document.querySelector('[type=password]')?.value==='');
 assert.equal((await second.p.evaluate(()=>fetch('/api/intranet/estado').then(r=>r.json()))).saved,false);assert(!fs.readFileSync(path.join(profile,'ajustes.json'),'utf8').includes('uvAccess'));console.log('PASS reinicio recupera el acceso; olvidar elimina claves y autorrelleno');
 await second.p.locator('#setBtn').click();await second.p.locator('#uvLoginStatus').waitFor();assert.match(await second.p.locator('#uvLoginStatus').textContent(),/primera vez/);console.log('PASS Ajustes explica el guardado de ambos servicios sin revelar claves');
}finally{await app?.close();}})().catch(e=>{console.error(e);process.exit(1)});
