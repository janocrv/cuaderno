# Cuaderno 5.0.2

Más maneras de personalizar Cuaderno y un inicio más cómodo.

- **Inicio con iconos:** todas las secciones y los sitios de la UV en un mismo panel: Asignaturas, Tareas, Apuntes, En grupo, Profesorado, Horario, Avisos, Correo UV, Aula Virtual, Intranet, NotebookLM y Gemini.
- **Fondos a tu gusto:** ocho fondos de día y ocho de noche, los cuatro colores de las esquinas y su intensidad. Además, tonos de día menos claros (Niebla, Piedra, Crepúsculo, Musgo) y de noche menos oscuros (Pizarra, Humo, Mar, Malva).
- **Foto de perfil ajustable:** al elegirla puedes moverla, acercarla y girarla. La foto y el nombre del máster quedan mejor encuadrados en la barra.
- **Qué hay de nuevo:** un resumen de cada versión, siempre a mano en Ajustes.
- **Más ordenado:** el número de tareas pendientes ya no tapa las siglas de la asignatura, Ajustes se abre por el principio y desaparece el personaje animado de la cabecera.

Incluye todas las mejoras de la versión 5.0.1. Los datos guardados se conservan al actualizar.

## Descargas

- **Mac con chip Apple:** Cuaderno-mac-arm64.dmg.
- **Mac Intel:** Cuaderno-mac-x64.dmg.
- **Windows de 64 bits:** Cuaderno-win-x64.exe.

Probado con datos ficticios. Windows físico queda pendiente de comprobación.
