# Editor de documentos de Cuaderno

Tiptap 3 / ProseMirror, con páginas A4 de 794 × 1123 px y 28 px entre hojas.
Las esquinas, la sombra y el color de cada hoja pertenecen a la interfaz, no al apunte.
El documento sigue guardándose como HTML y mantiene referencias `data-fid`, imágenes
de fondo, tablas y notas adhesivas. El historial se reinicia al cambiar de apunte.

`editor.js` contiene la integración. `build.mjs` genera un paquete sin conexiones
externas y lo incluye entre los marcadores `CUADERNO_EDITOR_BUNDLE_*` del HTML.
Incluye las licencias; la app y los instaladores siguen copiando un solo HTML.
No editar el paquete generado: editar la fuente y volver a ejecutar el generador.

Para evitar miles de archivos dentro de Drive:

```sh
mkdir -p /tmp/cuaderno-editor-build
cp editor/package.json editor/package-lock.json /tmp/cuaderno-editor-build/
npm ci --prefix /tmp/cuaderno-editor-build
node editor/build.mjs /tmp/cuaderno-editor-build
node editor/test.mjs /tmp/cuaderno-editor-build
```

Las pruebas abren Chrome sin interfaz y con perfil temporal, usan exclusivamente
datos de ejemplo y nunca leen `datos/` ni el perfil de la app real.

La batería incluye integridad de objetos anidados, edición, párrafos, listas,
tablas, barra fija, guardado y reapertura. `pruebas/editor-compilado.cjs` añade la
comprobación nativa (requiere compilar previamente y usa `CUADERNO_PRUEBA`).
`pruebas/exportacion-editor.test.cjs` revisa el contenido y formato del DOCX con
las dependencias de escritorio. `escritorio/editor-exportar.js` conserva las
propiedades de párrafo, tabulaciones y marcadores que el conversor base omite.

El HTML de entrada se procesa en un documento inerte: nunca crear un DIV en el
documento activo para analizar HTML desconocido. Los objetos se buscan por su
nodo exacto, también dentro de listas/citas; no borrar el bloque raíz por error.

La paginación y las tablas usan extensiones MIT de Romik Makavana. El generador
adapta el cálculo de páginas para incluir los objetos flotantes de Cuaderno.
La exportación PDF mantiene su composición propia (título, fecha, notas al final);
sus saltos pueden diferir de la vista del editor. La app de escritorio importa y
exporta DOCX mediante `documentos-worker.js`; esa función no está en la edición web.

## Trabajos en grupo (beta, 16-11-2026)

`rich.collab` usa Yjs + y-prosemirror (sin conexión ni servidor). El 16-11 `npm install` en la carpeta de
compilación fallaba (el registro ya no sirve `prosemirror-transform@1.12.6` del package-lock), así que se instalaron
aparte y se copiaron a `node_modules`:

```sh
mkdir -p /tmp/cuaderno-yjs && cd /tmp/cuaderno-yjs && echo '{"private":true}' > package.json
npm install --save-exact --legacy-peer-deps yjs@13.6.33 y-prosemirror@1.3.7 y-protocols@1.0.6
cp -R node_modules/{yjs,y-prosemirror,y-protocols,lib0,isomorphic.js} /tmp/cuaderno-editor-build/node_modules/
```
Prueba con dos apps de escritorio a la vez: `pruebas/trabajos-grupo/` (ver comentario de `arrancar-dos-apps.sh`).
