# Cuaderno 4.2.1

- **Trabajos en grupo (beta):** un documento que escribís entre varias personas. Crea el trabajo, pulsa «Invitar» y manda el código; tus compañeros lo pegan en «Unirme» y los aceptas con ✓. Cada uno escribe tranquilo y, al pulsar **Actualizar**, envía lo suyo y recibe lo de los demás sin pisar nada. Se ve quién está en el trabajo con su foto o iniciales. Comparte también imágenes, adjuntos, encabezado y pie. Todo viaja cifrado: sin el código no se puede leer.
- **Listas y sangrías:** «- » después de Tab crea una sublista de guiones; Intro en una línea vacía vuelve al margen y Retroceso quita la sangría.
- **PDF:** sale con el mismo formato que el folio (letra, interlineado, sangrías, listas y espacios).
- **Imágenes:** se agrandan o encogen con el tirador de la esquina y se cogen con la mano para moverlas.
- **Folio:** botones «Página», «Nota» y «Cita» junto a la hoja, con el color de la página y de la próxima nota.
- **Más color** en el modo día y en el modo noche, e **icono nuevo**.
- **Carpeta de datos:** al cambiar de carpeta, lo de este ordenador se combina con lo que ya había, sin perder nada. En el Mac la app ya no se abre sola al iniciar sesión.

Incluye todas las mejoras de la versión 4.1.0. Los datos guardados se conservan al actualizar.

## Descargas

- **Mac con chip Apple:** Cuaderno-mac-arm64.dmg.
- **Mac Intel:** Cuaderno-mac-x64.dmg.
- **Windows de 64 bits:** Cuaderno-win-x64.exe.

Probado con datos ficticios. Los trabajos en grupo necesitan internet al pulsar «Actualizar»; las solicitudes y avisos nuevos pueden tardar unos 30 segundos en aparecer. Windows físico queda pendiente de comprobación.
