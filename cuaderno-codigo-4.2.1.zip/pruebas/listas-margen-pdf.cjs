// 16-11-2026: sublistas con «- » tras Tab, volver al margen, tirador de imágenes, botones del folio y PDF igual que el folio.
const http=require('node:http'),fs=require('node:fs'),{chromium}=require('playwright'),assert=require('node:assert/strict'),path=require('node:path'),{pathToFileURL}=require('node:url');
const DASH='list-style-type: "–  ";';
(async()=>{const server=http.createServer((req,res)=>{if(new URL(req.url,'http://x').pathname==='/'){res.setHeader('Content-Type','text/html; charset=utf-8');res.end(fs.readFileSync(path.join(process.cwd(),'cuaderno-apuntes.html')));}else{res.statusCode=404;res.setHeader('Content-Type','application/json');res.end('{}');}});await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const b=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});try{
 const p=await b.newPage({viewport:{width:1440,height:1000}}),errors=[];p.on('pageerror',e=>errors.push(e.message));
 const svg=encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="600" height="360"><rect width="600" height="360" fill="#3d6f9e"/></svg>');
 const subject={id:'prueba',short:'ADP',name:'Prueba',color:'#399c91',notes:[{id:'n',title:'Prueba',date:'2026-11-16',content:`<p>Hola</p><img class="att-img" style="width:320px" src="data:image/svg+xml,${svg}"><p>Fin</p>`}],tasks:[],files:[],teachers:[],biblio:[]};
 await p.addInitScript(s=>{if(top!==window)return;localStorage.setItem('cuaderno-apuntes-v1',JSON.stringify({subjects:[s],active:s.id,subjectScope:s.id,activeNote:'n',view:'notes',theme:'light',settings:{userName:'Prueba',lang:'es'},deleted:{},library:[],schedule:[],tfmAdded:true,seeded2627:true}));localStorage.setItem('cuaderno-correo-preguntado','1');},subject);
 await p.route('https://api.github.com/**',r=>r.fulfill({status:200,contentType:'application/json',body:'{"tag_name":"v2.0.0"}'}));
 await p.goto('http://127.0.0.1:'+server.address().port+'/');await p.locator('#editor img').waitFor();await p.waitForTimeout(400);
 const html=()=>p.evaluate(()=>document.querySelector('#editor').editor.getHTML());
 const keys=async list=>{for(const k of list){if(/^(Enter|Tab|Backspace)$/.test(k))await p.keyboard.press(k);else await p.keyboard.type(k);}};
 const set=async(content,after)=>{await p.evaluate(([h,after])=>{const e=document.querySelector('#editor').editor;e.commands.setContent(h);let pos=null;e.state.doc.descendants((n,ps)=>{if(n.isText&&pos===null&&n.text.includes(after))pos=ps+n.text.indexOf(after)+after.length;});e.commands.focus(pos);},[content,after]);await p.waitForTimeout(80);};

 // Imagen: el tirador de la esquina cambia el ancho (px) y se guarda; ya no hay botones de porcentaje.
 const img=p.locator('#editor img');await img.click();await p.locator('.img-resize').waitFor({state:'visible'});
 assert.equal(await p.locator('.img-bar [data-i^="w"]').count(),0);
 const h=await p.locator('.img-resize').boundingBox();await p.mouse.move(h.x+10,h.y+10);await p.mouse.down();await p.mouse.move(h.x+90,h.y+60,{steps:6});await p.mouse.up();await p.waitForTimeout(600);
 const width=parseFloat(await img.evaluate(i=>i.style.width));assert.ok(width>360&&width<460,'ancho '+width);
 assert.match(await html(),new RegExp('width: '+width+'px'));
 await p.keyboard.press('Meta+z');assert.match(await html(),/width: 320px/);

 // Sublista con «- » tras Tab dentro de la lista, y salida al margen con Intro en líneas vacías.
 await set('<ul><li><p>Uno</p></li><li><p>Conoce</p></li></ul>','Conoce');await keys(['Enter','Tab','- ','a','Enter','b','Enter','Enter','Dos','Enter','Enter','Margen']);
 assert.equal(await html(),'<ul><li><p>Uno</p></li><li><p>Conoce</p><ul style="'+DASH.replace(/"/g,'&quot;')+'"><li><p>a</p></li><li><p>b</p></li></ul></li><li><p>Dos</p></li></ul><p>Margen</p><p></p>');
 // Tras salir de la lista, Tab y «- » cuelgan la sublista del último punto (no una lista nueva en el nivel principal).
 await set('<ul><li><p>Conoce</p></li></ul>','Conoce');await keys(['Enter','Enter','Tab','- ','a']);
 assert.equal(await html(),'<ul><li><p>Conoce</p><ul style="'+DASH.replace(/"/g,'&quot;')+'"><li><p>a</p></li></ul></li></ul><p></p>');
 // Línea sangrada sin lista delante: la lista toma la sangría y el texto no la repite.
 await set('<p>z</p>','z');await keys(['Enter','Tab','- ','a']);assert.match(await html(),/<ul style="[^"]*margin-left: 47\.244px;[^"]*"><li><p>a<\/p><\/li><\/ul>/);
 // Intro en línea vacía sangrada vuelve al margen; Retroceso al principio quita la sangría.
 await set('<p style="text-indent:47px">z</p>','z');await keys(['Enter','Enter','x']);assert.equal(await html(),'<p style="text-indent: 47px;">z</p><p>x</p>');
 await set('<p style="text-indent:47px">z</p>','z');await keys(['Enter','Backspace','x']);assert.equal(await html(),'<p style="text-indent: 47px;">z</p><p>x</p>');
 // Convertir una línea sangrada en lista numerada no deja la sangría dentro; deshacer la recupera.
 await set('<p style="text-indent:47px">z</p>','z');await keys(['Enter','1. ','x']);assert.equal(await html(),'<p style="text-indent: 47px;">z</p><ol><li><p>x</p></li></ol><p></p>');
 // Cambiar de contenido con el cursor en una lista no quita sangrías del documento nuevo.
 await set('<ul><li><p>a</p></li></ul>','a');await set('<p style="text-indent:47px">z</p>','z');assert.equal(await html(),'<p style="text-indent: 47px;">z</p>');

 // Botones del folio con nombre y muestra de color.
 assert.deepEqual(await p.locator('#pageTools .pt-l').allTextContents(),['Página','Nota','Cita']);
 await p.click('#pageTools [data-cmd="paper"]');await p.locator('#paperPop [data-paper="sepia"]').click();
 assert.equal(await p.locator('#pageTools').evaluate(e=>e.style.getPropertyValue('--paper-swatch')),'#f1e5cc');
 await p.click('#pageTools [data-cmd="sticky"]');await p.locator('#editor .sticky').waitFor();

 // PDF: lleva las reglas del folio (espacios, listas, sangrías) y la anchura de escritura del folio.
 await p.evaluate(()=>{const f=window.fetch;window.fetch=(u,o)=>{if(String(u).includes('/api/pdf')){window.__pdf=JSON.parse(o.body);return Promise.resolve(new Response('{}',{status:500}));}return f(u,o);};});
 await set('<p style="text-indent:47px">Uno  dos</p><ul><li><p>a</p><ul style="'+DASH.replace(/"/g,'&quot;')+'"><li><p>b</p></li></ul></li></ul>','dos');
 await p.getByRole('button',{name:/PDF de este apunte/}).click();await p.locator('#pdfGo').click();await p.waitForTimeout(600);
 const captured=await p.evaluate(()=>window.__pdf||null);await p.keyboard.press('Escape');
 if(captured){
  assert.match(captured.html,/class="editor ProseMirror pa-ed"/);assert.match(captured.html,/@page\{size:A4;margin:64px 68px 56px\}/);
  assert.match(captured.html,/\.ProseMirror\{[^}]*white-space: break-spaces/);assert.match(captured.html,/\.editor ul,\.editor ol\{padding-left: 1\.4em/);
  assert.doesNotMatch(captured.html,/data-theme|show-ws|\.st-bar/);
  const q=await b.newPage({viewport:{width:900,height:1200}});await q.setContent(captured.html);
  const geo=await q.evaluate(()=>{const ed=document.querySelector('.pa-ed'),p=ed.querySelector('p'),li=ed.querySelector('ul ul');return {indent:getComputedStyle(p).textIndent,ws:getComputedStyle(ed).whiteSpace,marker:getComputedStyle(li).listStyleType,line:getComputedStyle(ed).lineHeight,size:getComputedStyle(ed).fontSize};});
  assert.equal(geo.indent,'47px');assert.equal(geo.ws,'break-spaces');assert.equal(geo.marker,'"–  "');
  assert.equal(geo.size,await p.evaluate(()=>getComputedStyle(document.querySelector('#editor')).fontSize));
  assert.equal(geo.line,await p.evaluate(()=>getComputedStyle(document.querySelector('#editor')).lineHeight));
  await q.close();
 }else throw new Error('No se pidió el PDF');
 assert.deepEqual(errors,[]);
 console.log('PASS sublistas con guion tras Tab, volver al margen, tirador de imágenes, botones del folio y PDF con el formato del folio');
}finally{await b.close();server.close();}})().catch(e=>{console.error(e);process.exit(1)});
