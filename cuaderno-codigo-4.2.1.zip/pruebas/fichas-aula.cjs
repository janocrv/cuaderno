/* Fichas de profesorado desde el Aula Virtual: sin duplicados ni nombres que no son de persona. Datos ficticios.
   NODE_PATH=<playwright> node pruebas/fichas-aula.cjs */
const {chromium}=require('playwright'),fs=require('node:fs'),http=require('node:http'),path=require('node:path'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..');
(async()=>{let browser,server;try{
 const subj=(id,short,code,name,teachers=[])=>({id,short,code,name,color:'#399c91',notes:[],tasks:[],files:[],biblio:[],teachers,emails:[]});
 const T=(id,name,extra={})=>({id,name,email:'',hours:'',room:'',phone:'',notes:'',...extra});
 // Estado como lo dejó la 4.0.3: duplicado con «Prof. Dr.» y una ficha con nombre de facultad.
 const state={subjects:[
  subj('a','AEM','40524','Aprendizaje y enseñanza',[T('m1','Ana Perez Lopez',{sources:['x'],mailNames:['ana lopez perez']}),T('d1','Prof. Dr. Ana Perez',{email:'ana.perez@uv.es',room:'P4.03)',aulaCourse:'AEM',autoFields:{email:{subject:'Aula Virtual · GUÍA',value:'ana.perez@uv.es'},room:{subject:'Aula Virtual · GUÍA',value:'P4.03)'}}})]),
  subj('b','CFD','40523','Complementos',[T('m2','Hector Lopez Ruiz',{sources:['y']})]),
  subj('d','IDI','40525','Innovación docente',[T('m4','Maria Jose Garcia Folgado',{sources:['z']})]),
  subj('c','SFE','40495','Sociedad, familia y educación',[T('d2','Facultat de Ciències Socials',{email:'juan.garcia@uv.es',aulaCourse:'SFE',autoFields:{email:{subject:'Aula Virtual · PRESENTACIÓN',value:'juan.garcia@uv.es'}}})])],
  active:'a',subjectScope:'all',activeNote:null,view:'teachers',theme:'light',settings:{userName:'Prueba',lang:'es'},deleted:{},library:[],schedule:[],homeBoard:[],seeded2627:true,tfmAdded:true};
 // Textos con la forma real de las guías de la UV (nombres ficticios). Los docentes llegan por «Participantes».
 const scan={ok:true,deep:true,checkedAt:Date.now(),warnings:[],events:[],courses:[
  {id:1,fullname:'2026-27 Aprenentatge (40524)',shortname:'',idnumber:'',contacts:['Perez Lopez, Ana','Fernandez Colomer, Maria Jose','Reig Gascon, Aina'],info:{activities:[],text:'Curso 2026-2027\nProf. Dr. Ana Perez\nAna.perez@uv.es\nDesglose de temas, criterios de evaluación\n(despacho: P4.03)\nEl bloque aborda la enseñanza para alumn@s de Secundaria\nDocente María José Fernández Colomer\nCorreo electrónico maria.jose.fernandez@uv.es\nCurso 2026-2027\nTutorías\nMiércoles de 17.00 a 19.00. También podrán\nconcertarse con cita previa.',docs:[]}},
  {id:2,fullname:'2026-27 Complements (40523)',shortname:'',idnumber:'',contacts:['Lopez Ruiz, Hector'],info:{activities:[],text:'6 créditos / Curso 2026-2027\nPROFESOR: Héctor López Ruiz (Hector.Lopez@uv.es)\nHORARIO DE ATENCIÓN: tutorías virtuales o presenciales con cita previa.\n1. INTRODUCCIÓN A LA ASIGNATURA\nLa asignatura ofrece los complementos disciplinares necesarios para enseñar lengua castellana y literatura en\nSecundaria. Se revisan los contenidos del currículo, su secuenciación y los recursos más habituales en el aula,\ncon atención a la normativa vigente y a la práctica docente.\n2. COMPETENCIAS\nCompetencia general 1',docs:[]}},
  {id:3,fullname:'2026-27 Societat (40495)',shortname:'',idnumber:'',contacts:['Garcia Mora, Juan'],info:{activities:[],text:'Facultat de Ciències Socials\njuan.garcia@uv.es\nDepartament de Sociologia\ninfo.dep@uv.es',docs:[]}},
  {id:4,fullname:'2026-27 Innovació (40525)',shortname:'',idnumber:'',contacts:['Garcia Folgado, Maria Jose','España Palop, Eduardo'],info:{activities:[],text:'Profesores:\nMª José García Folgado Eduardo España Palop\nmaria.jose.garcia-folgado@uv.es eduardo.espana@uv.es\nDespacho 08',docs:[]}}]};
 let scans=0;
 server=http.createServer(async(req,res)=>{const u=new URL(req.url,'http://x');let d='';for await(const b of req)d+=b;const json=j=>{res.setHeader('Content-Type','application/json');res.end(JSON.stringify(j));};
  if(u.pathname==='/api/datos')return json({state:JSON.parse(d||'{}')});if(u.pathname==='/api/correos')return json({configured:true,user:'prueba',mails:[]});if(u.pathname==='/api/aula/revisar'){scans++;return json(scan);}if(u.pathname.startsWith('/api/'))return json({ok:true,configured:true,user:'prueba',ids:[],drafts:[],results:[],current:'4.0.3'});
  const f=u.pathname==='/'?path.join(root,'cuaderno-apuntes.html'):path.join(root,u.pathname);if(!fs.existsSync(f)){res.statusCode=404;return res.end();}res.setHeader('Content-Type',/\.m?js$/.test(f)?'text/javascript':f.endsWith('.html')?'text/html':'application/octet-stream');const src=fs.readFileSync(f);res.end(f.endsWith('cuaderno-apuntes.html')?src.toString().replace("const IN_APP = location.protocol === 'cuaderno:';",'const IN_APP = true;'):src);});
 await new Promise(r=>server.listen(0,'127.0.0.1',r));browser=await chromium.launch({executablePath:process.env.CHROME_PATH||'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});
 const p=await browser.newPage({viewport:{width:1100,height:900}}),errors=[];p.on('pageerror',e=>errors.push(e.message));
 await p.addInitScript(s=>{if(top!==window)return;if(!localStorage.getItem('cuaderno-apuntes-v1'))localStorage.setItem('cuaderno-apuntes-v1',JSON.stringify(s));localStorage.setItem('cuaderno-correo-preguntado','1');},state);
 await p.goto('http://127.0.0.1:'+server.address().port);await p.waitForTimeout(3500);await p.evaluate(()=>document.querySelectorAll('dialog[open]').forEach(d=>d.close()));
 const saved=()=>p.evaluate(()=>JSON.parse(localStorage.getItem('cuaderno-apuntes-v1')).subjects.map(s=>s.teachers.map(t=>[t.id,t.name,t.email,t.room,t.hours])));
 assert(scans>=1,'la revisión automática no se lanzó');let [a,b,d,c]=await saved();
 assert.deepEqual(a,[['m1','Ana Perez Lopez','ana.perez@uv.es','P4.03',''],[a[1][0],'Maria Jose Fernandez Colomer','maria.jose.fernandez@uv.es','','Miércoles de 17.00 a 19.00. También podrán'],[a[2][0],'Aina Reig Gascon','','','']]);console.log('PASS AEM: duplicado «Prof. Dr.» fundido; tres docentes de Participantes; correo, despacho y tutorías a quien corresponde');
 assert.deepEqual(b,[['m2','Hector Lopez Ruiz','hector.lopez@uv.es','','tutorías virtuales o presenciales con cita previa.']]);console.log('PASS CFD: «PROFESOR: Nombre (correo)» y «HORARIO DE ATENCIÓN» completan la ficha existente');
 assert.deepEqual(d.map(x=>x.slice(1,3)),[['Maria Jose Garcia Folgado','maria.jose.garcia-folgado@uv.es'],['Eduardo España Palop','eduardo.espana@uv.es']]);console.log('PASS IDI: dos docentes en la misma línea, cada uno con su correo');
 assert.equal(c.length,1);assert.deepEqual(c[0].slice(0,3),['d2','Juan Garcia Mora','juan.garcia@uv.es']);console.log('PASS SFE: «Facultat de…» sustituido por el nombre oficial; el departamento no crea ficha');
 const about=await p.evaluate(()=>JSON.parse(localStorage.getItem('cuaderno-apuntes-v1')).subjects.find(x=>x.id==='b').about);assert.match(about.text,/^La asignatura ofrece los complementos disciplinares/);assert.match(about.text,/práctica docente\.$/);assert.doesNotMatch(about.text,/COMPETENCIAS/);assert(!about.manual);console.log('PASS descripción de la asignatura tomada del apartado de introducción de la guía');
 await p.locator('#tabTeachers').click().catch(()=>{});await p.locator('#tRescan').click();await p.waitForFunction(()=>!document.querySelector('#tRescan').disabled);await p.waitForTimeout(800);
 const again=await saved();assert.deepEqual(again.map(x=>x.length),[3,1,2,1]);console.log('PASS repetir la revisión no vuelve a duplicar');
 await p.screenshot({path:path.join(root,'revisiones/2026-11-16/fichas-aula.png'),fullPage:true});assert.deepEqual(errors,[]);
}finally{await browser?.close();server?.close();}})().catch(e=>{console.error(e);process.exit(1)});
