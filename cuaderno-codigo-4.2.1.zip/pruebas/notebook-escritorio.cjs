/* App sin compilar y perfil temporal: carpeta de documentos para NotebookLM. Sin red ni datos reales.
   NODE_PATH=<playwright> CUADERNO_BIN=<Electron> CUADERNO_APP_DIR=~/.cuaderno-build node pruebas/notebook-escritorio.cjs */
const {_electron}=require('playwright'),fs=require('node:fs'),os=require('node:os'),path=require('node:path'),assert=require('node:assert/strict');
const profile=fs.mkdtempSync(path.join(os.tmpdir(),'cuaderno-notebook-'));let app;
(async()=>{try{
 fs.mkdirSync(path.join(profile,'datos/archivos'),{recursive:true});fs.writeFileSync(path.join(profile,'datos/archivos/abcd1234.bin'),'%PDF-ficticio');
 fs.writeFileSync(path.join(profile,'datos/cuaderno-datos.json'),JSON.stringify({subjects:[{id:'s1',short:'AEM',code:'1',name:'Prueba',color:'#399c91',notes:[],tasks:[],files:[{id:'abcd1234',name:'Análisis',ext:'pdf',size:13,added:1}],biblio:[],teachers:[],_u:1}],settings:{userName:'Prueba',lang:'es',_u:1},deleted:{},schedule:[],library:[],homeBoard:[],seeded2627:true,tfmAdded:true,_u:1}));
 app=await _electron.launch({executablePath:process.env.CUADERNO_BIN,args:[process.env.CUADERNO_APP_DIR],env:{...process.env,CUADERNO_PRUEBA:profile,CUADERNO_UPDATE_API:'http://127.0.0.1:9'},timeout:60000});
 const p=await app.firstWindow();await p.waitForTimeout(2500);
 const call=body=>p.evaluate(async b=>{const r=await fetch('/api/notebook/preparar',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)});return {status:r.status,...await r.json()};},body);
 const bad=await call({files:[{id:'../../ajustes',name:'x.json'},{id:'noexiste1',name:'y.pdf'}],texts:[]});assert.equal(bad.ok,false);assert.match(bad.error||bad.message||'',/No se ha encontrado/);
 const ok=await call({files:[{id:'abcd1234',name:'Análisis/..\\raro.pdf'},{id:'abcd1234',name:'Análisis/..\\raro.pdf'}],texts:[{name:'Apuntes AEM.md',text:'# AEM\nHola'}]});
 assert.equal(ok.ok,true);assert.equal(ok.count,3);assert(ok.folder.startsWith(path.join(fs.realpathSync(profile),'Cuaderno para NotebookLM'))||ok.folder.startsWith(path.join(profile,'Cuaderno para NotebookLM')));
 const names=fs.readdirSync(ok.folder).sort();assert.equal(names.length,3);assert(names.every(n=>!/[\\/]/.test(n)));assert(names.includes('Apuntes AEM.md'));assert.equal(fs.readFileSync(path.join(ok.folder,'Apuntes AEM.md'),'utf8'),'# AEM\nHola');assert.equal(fs.readFileSync(path.join(ok.folder,names.find(n=>n.endsWith('.pdf'))),'utf8'),'%PDF-ficticio');
 console.log('PASS documentos copiados con nombre limpio y sin repetir; identificadores inválidos rechazados; nada fuera de la carpeta',names.join(' | '));
 const link=await p.evaluate(async()=>{const r=await fetch('/api/notebook/abrir',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({url:'https://ejemplo.test/x'})});return {status:r.status,...await r.json()};});assert.equal(link.ok,false);assert.equal(await app.evaluate(({BrowserWindow})=>BrowserWindow.getAllWindows().length),1);
 console.log('PASS solo se abren enlaces de notebooklm.google.com');
}finally{await app?.close();fs.rmSync(profile,{recursive:true,force:true});}})().catch(e=>{console.error(e);process.exit(1)});
