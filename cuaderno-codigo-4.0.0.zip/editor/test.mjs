import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
const folder=path.dirname(fileURLToPath(import.meta.url)),root=path.dirname(folder),deps=path.resolve(process.argv[2]||folder);
const env={...process.env,NODE_PATH:[path.join(deps,'node_modules'),process.env.NODE_PATH].filter(Boolean).join(path.delimiter)};
const tests=['auditoria-editor.cjs','parrafos.cjs','listas-formato.cjs','listas-individuales.cjs','tablas.cjs','barra-editor-fija.cjs','interfaz.cjs'];
for(const test of tests){
 process.stdout.write('\n'+test+'\n');const result=spawnSync(process.execPath,[path.join(root,'pruebas',test)],{cwd:root,env,stdio:'inherit',timeout:180000});
 if(result.error)process.stderr.write(result.error.message+'\n');if(result.status!==0)process.exitCode=1;
}
