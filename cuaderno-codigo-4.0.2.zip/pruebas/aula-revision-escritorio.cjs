/* Revisión automática del Aula Virtual. App sin compilar, perfil temporal y servidores UV ficticios; sin red ni claves reales.
   NODE_PATH=<playwright> CUADERNO_BIN=<Electron> CUADERNO_APP_DIR=~/.cuaderno-build node pruebas/aula-revision-escritorio.cjs */
const {_electron}=require('playwright'),fs=require('node:fs'),os=require('node:os'),path=require('node:path'),assert=require('node:assert/strict');
const profile=fs.mkdtempSync(path.join(os.tmpdir(),'cuaderno-aula-revision-'));let app;
(async()=>{try{
 const subj=(id,short,code,name,tasks=[])=>({id,short,code,name,color:'#399c91',notes:[],tasks,files:[],biblio:[],teachers:[],emails:[],_u:1});
 const state={subjects:[subj('s1','ADP','40493','Aprendizaje y desarrollo de la personalidad',[{id:'t1',title:'Trabajo final',av:'123',due:'2030-01-10',done:false,created:1}]),subj('s2','CFD','40523','Complementos para la formación disciplinar')],settings:{userName:'Prueba aislada',lang:'es',_u:1},deleted:{},schedule:[],library:[],homeBoard:[],seeded2627:true,tfmAdded:true,_u:1};
 fs.mkdirSync(path.join(profile,'datos'));fs.writeFileSync(path.join(profile,'datos/cuaderno-datos.json'),JSON.stringify(state));
 app=await _electron.launch({executablePath:process.env.CUADERNO_BIN,args:[process.env.CUADERNO_APP_DIR],env:{...process.env,CUADERNO_PRUEBA:profile,CUADERNO_UPDATE_API:'http://127.0.0.1:9'},timeout:60000});
 await app.evaluate(async({session})=>{
  globalThis.uvTest={authed:false,posts:0,services:[]};
  await session.fromPartition('persist:cuaderno-intranet').protocol.handle('https',async request=>{
   const u=new URL(request.url),html=body=>new Response('<!doctype html><meta charset="utf-8">'+body,{headers:{'Content-Type':'text/html; charset=utf-8'}}),redirect=url=>new Response(null,{status:302,headers:{Location:url}});
   const auth='https://as.uv.es/cgi-bin/AuthServer';
   if(u.hostname==='portal.uv.es')return uvTest.authed?html('<h1>Intranet</h1><a href="/logout">Salir</a>'):redirect(auth);
   if(u.hostname==='aulavirtual.uv.es'){
    if(u.pathname==='/login/index.php')return html('<a href="/auth/saml2/login.php?idp=ficticio">Usuaris de la Universitat</a>');
    if(u.pathname==='/auth/saml2/login.php')return redirect(auth);
    if(!uvTest.authed)return redirect('https://aulavirtual.uv.es/login/index.php');
    if(u.pathname==='/lib/ajax/service.php'){const info=u.searchParams.get('info');uvTest.services.push(info);if(u.searchParams.get('sesskey')!=='abc123')return Response.json([{error:true,exception:{message:'sesskey'}}]);
     const day=n=>Math.floor(new Date(2031,0,n,23,59).getTime()/1000);
     if(info==='core_course_get_enrolled_courses_by_timeline_classification')return Response.json([{error:false,data:{courses:[{id:11,fullname:'40493 Aprendizaje y desarrollo de la personalidad Gr.A',shortname:'2026-40493-A',idnumber:''},{id:12,fullname:'Complementos para la formación disciplinar (40523)',shortname:'CFD',idnumber:''},{id:13,fullname:'Curso de biblioteca',shortname:'BIB',idnumber:''}]}}]);
     if(info==='core_course_get_courses_by_field')return Response.json([{error:false,data:{courses:[{id:11,contacts:[{id:1,fullname:'PÉREZ GARCÍA, ANA'}]},{id:12,contacts:[{id:2,fullname:'Héctor López Ruiz'}]},{id:13,contacts:[{id:3,fullname:'Persona Ajena Total'}]}]}}]);
     if(info==='core_calendar_get_action_events_by_timesort')return Response.json([{error:false,data:{events:[
      {modulename:'assign',activityname:'Trabajo final',name:'Vencimiento de Trabajo final',timesort:day(15),url:'https://aulavirtual.uv.es/mod/assign/view.php?id=123',course:{id:11,fullname:'ADP'}},
      {modulename:'assign',activityname:'Comentario de texto &amp; debate',name:'x',timesort:day(20),url:'https://aulavirtual.uv.es/mod/assign/view.php?id=456',course:{id:12,fullname:'CFD'}},
      {modulename:'quiz',activityname:'Cuestionario tema 1',name:'x',timesort:day(22),url:'https://aulavirtual.uv.es/mod/quiz/view.php?id=789',course:{id:12,fullname:'CFD'}},
      {modulename:'assign',activityname:'Tarea de otro curso',name:'x',timesort:day(25),url:'https://aulavirtual.uv.es/mod/assign/view.php?id=999',course:{id:13,fullname:'BIB'}},
      {modulename:'forum',activityname:'Foro',name:'x',timesort:day(25),url:'https://aulavirtual.uv.es/mod/forum/view.php?id=5',course:{id:11}}]}}]);
     return Response.json([{error:true,exception:{message:'desconocido'}}]);}
    return html('<div class="usermenu"><button class="userbutton">Cuenta ficticia</button><a href="/login/logout.php?sesskey=abc123">Salir</a></div><main id="region-main"></main>');
   }
   if(u.hostname==='as.uv.es'){
    let error='';if(request.method==='POST'){uvTest.posts++;const body=new URLSearchParams(await request.text());await new Promise(r=>setTimeout(r,uvTest.delay||0));if(body.get('username')==='prueba'&&body.get('password')==='clave-ficticia'){uvTest.authed=true;return redirect(uvTest.back||'https://portal.uv.es/cgi-bin/portal/portal');}error='<div role="alert">Contraseña incorrecta</div>';}
    return html(error+'<form method="post" action="/cgi-bin/AuthServer"><label>Usuario<input name="username" autocomplete="username"></label><label>Clave<input type="password" name="password" autocomplete="current-password"></label><button type="submit">Acceder</button></form>');
   }
   return new Response('',{status:404});
  });
 });
 const p=await app.firstWindow();p.setDefaultTimeout(15000);await p.waitForTimeout(2500);await p.evaluate(()=>{localStorage.setItem('cuaderno-correo-preguntado','1');document.querySelectorAll('dialog[open]').forEach(d=>d.close());});
 const visible=()=>app.evaluate(({BrowserWindow})=>BrowserWindow.getAllWindows().filter(w=>w.isVisible()).length),total=()=>app.evaluate(({BrowserWindow})=>BrowserWindow.getAllWindows().length);
 const saved=()=>p.evaluate(()=>JSON.parse(localStorage.getItem('cuaderno-apuntes-v1')));
 const review=async()=>{await p.locator('#tRescan').click();await p.waitForFunction(()=>!document.querySelector('#tRescan').disabled&&!/Revisando/.test(document.querySelector('#tAulaStatus').textContent));await p.waitForTimeout(700);};
 await p.evaluate(()=>{document.querySelector('.subj:not(.grp)').click();});await p.locator('#tabTeachers').click();
 // 1. Sin sesión ni acceso guardado: avisa y no enseña ninguna ventana.
 await review();assert.match(await p.locator('#tAulaStatus').textContent(),/iniciar sesión una vez/);assert.equal(await visible(),1);assert.equal(await total(),1);
 console.log('PASS sin acceso guardado: avisa en la ficha y no abre ventanas');
 // 2. Primer acceso a mano (único momento en que se escribe la clave).
 let wp=app.waitForEvent('window');await p.locator('#aulaBtn').click();let uv=await wp;await uv.waitForURL('https://as.uv.es/**');assert.equal(await visible(),2);
 await app.evaluate(()=>{uvTest.back='https://aulavirtual.uv.es/my/';});
 await uv.locator('[name="username"]').fill('prueba');await uv.locator('[name="password"]').fill('clave-ficticia');await uv.getByRole('button',{name:'Acceder'}).click();await uv.waitForURL('https://aulavirtual.uv.es/my/');
 await p.waitForFunction(async()=>!!(await fetch('/api/intranet/estado').then(r=>r.json())).saved);await uv.close();
 console.log('PASS primer acceso manual guardado');
 // 3. Sesión caducada + botón Aula Virtual: la pantalla de inicio no llega a verse.
 await app.evaluate(()=>{uvTest.authed=false;uvTest.delay=1500;});wp=app.waitForEvent('window');await p.locator('#aulaBtn').click();uv=await wp;
 await uv.waitForURL('https://as.uv.es/**');await p.waitForTimeout(600);assert.equal(await visible(),1,'la ventana debe seguir oculta durante el inicio de sesión');
 await uv.waitForURL('https://aulavirtual.uv.es/my/');await p.waitForFunction(()=>true);for(let i=0;i<20&&await visible()!==2;i++)await p.waitForTimeout(150);assert.equal(await visible(),2);assert.equal(await app.evaluate(()=>uvTest.posts),2);await uv.close();
 console.log('PASS Aula Virtual se abre ya dentro: el inicio de sesión se renueva oculto');
 // 4. Revisión con la sesión caducada: se renueva sola, sin ventanas, y coloca profesorado y entregas.
 await app.evaluate(()=>{uvTest.authed=false;uvTest.delay=0;});await review();
 assert.equal(await visible(),1);assert.equal(await total(),1);assert.equal(await app.evaluate(()=>uvTest.posts),3);
 let st=await saved(),a=st.subjects.find(s=>s.id==='s1'),c=st.subjects.find(s=>s.id==='s2');
 assert.deepEqual(a.teachers.map(t=>t.name),['Ana Pérez García']);assert.deepEqual(c.teachers.map(t=>t.name),['Héctor López Ruiz']);
 assert.equal(a.tasks.length,1);assert.equal(a.tasks[0].due,'2031-01-15');assert.equal(a.tasks[0].id,'t1');
 assert.deepEqual(c.tasks.map(t=>[t.id,t.title,t.due]),[['aula-task-456','Comentario de texto & debate','2031-01-20'],['aula-task-q789','Cuestionario tema 1','2031-01-22']]);
 assert.match(await p.locator('#tAulaStatus').textContent(),/asignaturas reconocidas: 2/);
 console.log('PASS revisión silenciosa: 2 fichas, 2 tareas nuevas, 1 plazo actualizado, curso ajeno ignorado');
 // 5. Repetir no duplica; lo cambiado o borrado a mano se respeta.
 await p.evaluate(()=>{const t=document.querySelector('#tList .t-del');window.confirm=()=>true;t.click();});await p.waitForTimeout(400);
 await review();st=await saved();a=st.subjects.find(s=>s.id==='s1');c=st.subjects.find(s=>s.id==='s2');
 assert.equal(a.teachers.length,0,'la ficha quitada no vuelve');assert.equal(c.teachers.length,1);assert.equal(c.tasks.length,2);assert.equal(a.tasks.length,1);
 console.log('PASS segunda revisión sin duplicados; la ficha quitada no reaparece');
 // 6. Lista completa de fichas: se abre y se cierra sin salir de la asignatura.
 const b=p.locator('#tShowAll');assert.equal(await b.textContent(),'Ver todas las fichas');await b.click();
 assert.equal(await b.textContent(),'Cerrar la lista completa');assert(await p.locator('#tList h3.subj-tag').count()>=1);assert.match(await p.locator('#tList').textContent(),/Héctor|CFD/);
 await p.screenshot({path:path.join(__dirname,'../revisiones/2026-11-15/profesorado-lista-completa.png')});
 await b.click();assert.equal(await b.textContent(),'Ver todas las fichas');assert.equal(await p.locator('#tList h3.subj-tag').count(),0);
 console.log('PASS lista completa de fichas se abre y se cierra en la misma asignatura');
}finally{await app?.close();fs.rmSync(profile,{recursive:true,force:true});}})().catch(e=>{console.error(e);process.exit(1)});
