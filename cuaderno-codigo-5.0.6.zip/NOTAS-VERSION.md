# Cuaderno 5.0.6

- **Grabar clase:** en cada asignatura, el botón «Grabar clase» graba el audio con el micrófono (la primera vez el ordenador pide permiso). Al pulsar «Detener y guardar», la grabación (.m4a) queda en Archivos de la asignatura y en Documentos → Cuaderno - Grabaciones. Mientras graba, el ordenador no se duerme solo (no cierres la tapa del portátil). Si la app se cierra de golpe, al volver a abrirla te ofrece guardar lo grabado.
- **Transcribir en un apunte:** al terminar de grabar, Cuaderno ofrece transcribir la clase en un apunte nuevo: **completa** (con la hora de cada parte) o **resumen** (ideas principales y, debajo, la transcripción completa). También puedes transcribir un audio después: ⋯ → «Transcribir un audio…» o el botón de ondas junto al audio en Archivos. Se hace en tu ordenador, sin enviar el audio a nadie; la primera vez descarga el reconocimiento de voz.
- **Menú de tabla completo:** pulsa ⋯ en una tabla para añadir, mover o quitar filas y columnas, cambiar cuántas filas y columnas tiene, colorear una celda o toda la tabla, combinar o dividir celdas y separarla del margen. El menú se queda abierto para dar varios pasos seguidos y Cmd/Ctrl+Z deshace cada uno.
- **Listas más fiables:** Tab o espacios delante de «- », «* », «1. » o «a) » meten la lista un nivel más adentro; Tab en el primer elemento mueve toda la lista; Alt+Mayús+↑/↓ (o los botones Subir/Bajar) cambian el orden de los elementos.
- **Horario sin choques:** las clases vuelven a salir a su hora. Si dos clases coinciden se ven lado a lado y Cuaderno te pregunta cuál tienes (o «Van las dos»). También puedes quitar todas las clases de una asignatura que no cursas.
- **Trabajos en grupo al momento:** los cambios de cada persona llegan solos a los demás, sin pulsar «Actualizar», y cualquiera con el código entra en el trabajo. **Tus compañeros también tienen que actualizar** para que funcione en los dos sentidos.

Incluye todas las mejoras de la versión 5.0.5. Los datos guardados se conservan al actualizar.

## Descargas

- **Mac con chip Apple:** Cuaderno-mac-arm64.dmg.
- **Mac Intel:** Cuaderno-mac-x64.dmg.
- **Windows de 64 bits:** Cuaderno-win-x64.exe.
