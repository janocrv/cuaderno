/* Grabar clase + transcribir con micrófono simulado (voz sintética en un .wav) y datos ficticios.
   Uso: CUADERNO_VOZ=<archivo.wav> node pruebas/grabar-clase-escritorio.cjs [capturas]
   La primera vez descarga el reconocimiento de voz (≈ 300 MB) a la caché del perfil de prueba.
   Sin CUADERNO_TRANSCRIBIR=1 solo prueba grabar, guardar y recuperar. */
const { _electron } = require('playwright'), fs = require('node:fs'), path = require('node:path'), os = require('node:os'), assert = require('node:assert/strict');
const BUILD = process.env.CUADERNO_APP_DIR || path.join(os.homedir(), '.cuaderno-build');
const VOZ = process.env.CUADERNO_VOZ, SHOTS = process.argv[2] || null;
(async () => {
  let app; const profile = fs.mkdtempSync(path.join(os.tmpdir(), 'cuaderno-grabar-'));
  try {
    const s = { id: 'adp', short: 'ADP', name: 'Aprendizaje y desarrollo de la personalidad', color: '#399c91', notes: [], tasks: [], files: [], teachers: [], biblio: [] };
    const state = { subjects: [s], settings: { userName: 'Prueba', lang: 'es' }, deleted: {}, library: [], schedule: [], homeBoard: [], seeded2627: true, tfmAdded: true };
    fs.mkdirSync(path.join(profile, 'datos')); fs.writeFileSync(path.join(profile, 'datos/cuaderno-datos.json'), JSON.stringify(state));
    const args = [BUILD, '--use-fake-ui-for-media-stream', '--use-fake-device-for-media-stream', ...(VOZ ? ['--use-file-for-fake-audio-capture=' + VOZ] : [])];
    app = await _electron.launch({ executablePath: path.join(BUILD, 'node_modules/electron/dist/Electron.app/Contents/MacOS/Electron'), args, env: { ...process.env, CUADERNO_PRUEBA: profile, CUADERNO_UPDATE_API: 'http://127.0.0.1:9' }, timeout: 60000 });
    const p = await app.firstWindow(); p.setDefaultTimeout(20000);
    const errors = []; p.on('pageerror', e => errors.push(String(e)));
    await p.waitForTimeout(1500);
    await p.evaluate(() => { localStorage.setItem('cuaderno-correo-preguntado', '1'); document.querySelectorAll('dialog[open]').forEach(d => d.close()); });
    await p.locator('#subjects [data-sid="adp"]').click(); await p.locator('#tabNotes').click();
    // micrófono simulado: la voz del .wav entra por getUserMedia (el «fake device» de Chromium no siempre usa el archivo)
    if (VOZ) await p.evaluate(async b64 => {
      const bytes = Uint8Array.from(atob(b64), c => c.charCodeAt(0));
      navigator.mediaDevices.getUserMedia = async () => {
        const ac = new AudioContext(), buf = await ac.decodeAudioData(bytes.buffer.slice(0)), src = ac.createBufferSource(), dest = ac.createMediaStreamDestination();
        src.buffer = buf; src.connect(dest); src.start(); return dest.stream;
      };
    }, fs.readFileSync(VOZ).toString('base64'));
    // 1) grabar
    await p.locator('#recBtn').click();
    try { await p.waitForFunction(() => document.querySelector('#recBar').matches(':popover-open') && document.querySelector('#recBar').classList.contains('rec')); }
    catch (e) { console.log('Diagnóstico:', await p.evaluate(() => ({ toast: document.querySelector('#toast').textContent, bar: document.querySelector('#recBar').className, open: document.querySelector('#recBar').matches(':popover-open'), dlg: [...document.querySelectorAll('dialog[open]')].map(d => d.id) })), errors); throw e; }
    await p.waitForTimeout(VOZ ? 19000 : 9000);
    await p.evaluate(() => window.focus());
    const level = await p.evaluate(() => parseFloat(document.querySelector('#recLevel').style.width) || 0);
    if (SHOTS) await p.screenshot({ path: path.join(SHOTS, 'grabando.png') });
    const part = fs.readdirSync(path.join(profile, 'grabaciones')).find(f => f.endsWith('.part'));
    assert.ok(part && fs.statSync(path.join(profile, 'grabaciones', part)).size > 1000, 'se va guardando en el disco mientras graba');
    console.log('PASS se va guardando a trozos mientras graba; nivel', level.toFixed(0) + '%');
    // 2) detener → Archivos + copia en Documentos + ventana
    await p.locator('#recStop').click();
    await p.waitForFunction(() => document.querySelector('#recDlg').open, null, { timeout: 30000 });
    if (SHOTS) await p.screenshot({ path: path.join(SHOTS, 'guardada.png') });
    const info = await p.evaluate(() => { const s = cuadernoGrabacion.asignatura('adp'); return { files: s.files, sub: document.querySelector('#recDlgSub').textContent, where: document.querySelector('#recDlgWhere').textContent }; });
    assert.equal(info.files.length, 1); assert.equal(info.files[0].ext, 'm4a');
    const bin = path.join(profile, 'datos/archivos', info.files[0].id + '.bin');
    assert.ok(fs.statSync(bin).size > 1000, 'audio en Archivos');
    if (process.env.CUADERNO_GUARDAR_AUDIO) fs.copyFileSync(bin, process.env.CUADERNO_GUARDAR_AUDIO);
    const docs = path.join(profile, 'Documentos/Cuaderno - Grabaciones'), copies = fs.readdirSync(docs);
    assert.equal(copies.length, 1); assert.ok(copies[0].endsWith('.m4a'));
    assert.equal(fs.readdirSync(path.join(profile, 'grabaciones')).length, 0, 'sin restos pendientes');
    console.log('PASS guardada en Archivos y en Documentos:', copies[0], info.sub);
    // 3) recuperación: una grabación a medias se ofrece al abrir
    const rid = 'recuperar' + Date.now().toString(36);
    fs.copyFileSync(bin, path.join(profile, 'grabaciones', rid + '.part'));
    fs.writeFileSync(path.join(profile, 'grabaciones', rid + '.json'), JSON.stringify({ sid: 'adp', name: 'ADP · clase rota', mime: 'audio/mp4', ext: 'm4a' }));
    p.once('dialog', d => d.accept());
    await p.locator('#recLater').click();
    await p.evaluate(() => cuadernoGrabacion.recuperar());
    await p.waitForFunction(() => cuadernoGrabacion.asignatura('adp').files.length === 2);
    await p.evaluate(() => document.querySelector('#recDlg').open && document.querySelector('#recDlg').close());
    console.log('PASS grabación interrumpida recuperada');
    // 4) transcribir (descarga el modelo la primera vez)
    if (process.env.CUADERNO_TRANSCRIBIR) {
      await p.evaluate(fid => { const f = cuadernoGrabacion.asignatura('adp').files.find(x => x.id === fid); cuadernoGrabacion.abrir({ fid, sid: 'adp', name: f.name, size: f.size, fresh: false }); }, info.files[0].id);
      if (SHOTS) await p.screenshot({ path: path.join(SHOTS, 'transcribir.png') });
      const t0 = Date.now();
      if (process.env.CUADERNO_RESUMEN) await p.locator('#recForm input[name=kind][value=sum]').check({ force: true });
      await p.locator('#recGo').click();
      await p.waitForTimeout(4000); if (SHOTS) await p.screenshot({ path: path.join(SHOTS, 'transcribiendo.png') });
      await p.waitForTimeout(40000); if (SHOTS) await p.screenshot({ path: path.join(SHOTS, 'tras40.png') }); console.log('a los 40 s:', await p.evaluate(() => document.querySelector('#recTxt').textContent + ' | ' + document.querySelector('#recBar').className + ' | notas ' + cuadernoGrabacion.asignatura('adp').notes.length));
      await p.waitForFunction(() => cuadernoGrabacion.asignatura('adp').notes.length === 1 || !document.querySelector('#recBar').matches(':popover-open'), null, { timeout: 15 * 60000 });
      const note = await p.evaluate(() => cuadernoGrabacion.asignatura('adp').notes[0]);
      assert.ok(note, 'apunte creado');
      console.log('PASS transcripción en', Math.round((Date.now() - t0) / 1000), 's →', note.title, '\n', note.content.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').slice(0, 600));
      if (SHOTS) await p.screenshot({ path: path.join(SHOTS, 'lista.png') });
      if (SHOTS) { await p.locator('#recOpen').click(); await p.waitForTimeout(1200); await p.screenshot({ path: path.join(SHOTS, 'apunte.png') }); }
    }
    assert.deepEqual(errors, []);
    console.log('PASS sin errores');
  } finally { await app?.close(); fs.rmSync(profile, { recursive: true, force: true }); }
})().catch(e => { console.error(e); process.exitCode = 1; });
