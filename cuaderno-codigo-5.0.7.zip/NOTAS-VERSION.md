# Cuaderno 5.0.7

- **Transcripción simultánea:** mientras grabas una clase, pulsa «Transcripción simultánea» en la barra de grabación. Se abre una ventana flotante (la puedes mover y cambiar de tamaño) donde el texto va apareciendo mientras habla la profesora, como subtítulos: la frase en curso en gris y, en cada pausa, en negro con su hora. Al terminar, «Añadir a apuntes: Completa / Resumen» crea el apunte en la asignatura. Se hace en tu ordenador; la primera vez descarga unos 120 MB.
- **Medidor de sonido al grabar:** mientras grabas una clase, unas barras se mueven con la voz para que sepas que el micrófono funciona. Si durante 6 segundos no entra sonido, la barra se pone en rojo y avisa «No llega sonido».
- **Ventana más sencilla al terminar de grabar:** completa o resumen, asignatura e idioma, sin textos de más.
- **Tus ordenadores, iguales:** los ajustes (foto, nombre, colores, horario…) se juntan uno a uno. Si cambias la foto en un ordenador y los colores en otro, se quedan los dos cambios (antes ganaba el último ordenador que guardaba).
- **Ajustes → Carpeta de datos** dice si se está sincronizando (o por qué no) y qué ordenadores usan esos datos, con su versión. Si falta uno, en ese ordenador elige la misma carpeta de Drive.

Incluye todo lo de la 5.0.6 (grabar clase y transcribir, menú de tablas, listas, horario y trabajos en grupo). Los datos guardados se conservan al actualizar.

## Descargas

- **Mac con chip Apple:** Cuaderno-mac-arm64.dmg.
- **Mac Intel:** Cuaderno-mac-x64.dmg.
- **Windows de 64 bits:** Cuaderno-win-x64.exe.
