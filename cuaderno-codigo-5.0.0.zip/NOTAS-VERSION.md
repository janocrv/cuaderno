# Cuaderno 5.0.0

Una versión más ligera y pulida, con todo lo de los trabajos en grupo.

- **Más ligera:** el instalador ocupa unos 60 MB menos. Se han quitado piezas que venían incluidas y no se usaban, sin perder ninguna función.
- **«Ver espacios» ya no mueve el texto:** al activarla, el documento se queda exactamente donde estaba; solo se marcan los párrafos (¶) y ahora también los saltos de línea (↵), para distinguir un párrafo nuevo de un salto de línea dentro del mismo párrafo (Mayús+Intro).
- **Trabajos en grupo (beta):** pestaña «En grupo» con tus trabajos por asignatura, código corto para invitar y mezcla de los cambios de todos al pulsar «Actualizar».
- **Fotos donde escribes**, **avisos visibles** por encima de las ventanas, **cabecera centrada** y **barra del editor sin cortes**.

Incluye todas las mejoras de la versión 4.2.3. Los datos guardados se conservan al actualizar.

## Descargas

- **Mac con chip Apple:** Cuaderno-mac-arm64.dmg.
- **Mac Intel:** Cuaderno-mac-x64.dmg.
- **Windows de 64 bits:** Cuaderno-win-x64.exe.

Probado con datos ficticios. Los trabajos en grupo necesitan internet. Windows físico queda pendiente de comprobación.
