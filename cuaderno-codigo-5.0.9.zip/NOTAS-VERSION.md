# Cuaderno 5.0.9

- **Tus ordenadores ya no se pisan los cambios:** al abrir Cuaderno, el ordenador marcaba todos sus apuntes y ajustes como «recién cambiados», se creía el más nuevo y podía pisar lo que habías hecho en el otro ordenador mientras estaba cerrado (por ejemplo, la foto de perfil). Arreglado: ahora gana siempre el cambio más reciente de verdad.

Incluye todo lo de la 5.0.8 (transcripción simultánea más fina y rápida, «Guardar en…» de las grabaciones). Los datos guardados se conservan al actualizar.

## Descargas

- **Mac con chip Apple:** Cuaderno-mac-arm64.dmg.
- **Mac Intel:** Cuaderno-mac-x64.dmg.
- **Windows de 64 bits:** Cuaderno-win-x64.exe.
