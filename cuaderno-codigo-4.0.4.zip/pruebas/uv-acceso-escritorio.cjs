/* Aplicación compilada, perfil temporal y servidores UV ficticios. Nunca usa claves reales. */
const {_electron}=require('playwright'),fs=require('node:fs'),os=require('node:os'),path=require('node:path'),assert=require('node:assert/strict');
const uvWindow=app=>{const before=new Set(app.windows());return (async()=>{for(let i=0;i<300;i++){const w=app.windows().find(w=>!before.has(w)&&w.url().startsWith('https://'));if(w)return w;await new Promise(r=>setTimeout(r,100));}throw new Error('No se abrió la ventana de la UV');})();}; // la ventana UV lleva además una vista con los botones de navegación
const profile=fs.mkdtempSync(path.join(os.tmpdir(),'cuaderno-uv-prueba-'));
const executablePath=process.env.CUADERNO_BIN||'/Users/jano/.cuaderno-build/dist/mac-arm64/Cuaderno.app/Contents/MacOS/Cuaderno';
let app;
async function launch(){
 app=await _electron.launch({executablePath,args:process.env.CUADERNO_APP_DIR?[process.env.CUADERNO_APP_DIR]:[],env:{...process.env,CUADERNO_PRUEBA:profile,CUADERNO_UPDATE_API:'http://127.0.0.1:9'},timeout:60000});
 await app.evaluate(async({session})=>{
  globalThis.uvTest={authed:false,posts:0};
  await session.fromPartition('persist:cuaderno-intranet').protocol.handle('https',async request=>{
   const u=new URL(request.url),html=body=>new Response('<!doctype html><meta charset="utf-8">'+body,{headers:{'Content-Type':'text/html; charset=utf-8'}}),redirect=url=>new Response(null,{status:302,headers:{Location:url}});
   const auth='https://as.uv.es/cgi-bin/AuthServer';
   if(u.hostname==='portal.uv.es')return uvTest.authed?html('<h1>Intranet</h1><a href="/logout">Salir</a>'):redirect(auth);
   if(u.hostname==='aulavirtual.uv.es'){
    if(u.pathname==='/login/index.php')return html((uvTest.ssoOnly?'':'<form action="/login/index.php" method="post"><input name="username"><input name="password" type="password"><button>Entrar externo</button></form>')+'<a href="/auth/saml2/login.php?idp=ficticio">Usuaris de la Universitat</a>');
    if(u.pathname==='/auth/saml2/login.php')return redirect(auth);
    return uvTest.authed?html('<div class="usermenu"><button class="userbutton">Cuenta ficticia</button></div>'):redirect('https://aulavirtual.uv.es/login/index.php');
   }
   if(u.hostname==='as.uv.es'){
    let error='';if(request.method==='POST'){uvTest.posts++;const body=new URLSearchParams(await request.text());if(!uvTest.reject&&body.get('username')==='prueba'&&body.get('password')==='clave-ficticia'){uvTest.authed=true;return redirect('https://portal.uv.es/cgi-bin/portal/portal');}error='<div role="alert">Contraseña incorrecta</div>';}
    if(uvTest.challenge)return html('<form method="post" action="/cgi-bin/AuthServer"><input name="username"><input name="password" type="password"><input name="otp" autocomplete="one-time-code"><button>Acceder</button></form>');
    return html(error+'<form method="post" action="/cgi-bin/AuthServer"><label>Usuario<input name="username" autocomplete="username"></label><label>Clave<input type="password" name="password" autocomplete="current-password"></label><button type="submit">Acceder</button></form>');
   }
   return new Response('',{status:404});
  });
 });
 const p=await app.firstWindow();await p.waitForTimeout(1800);await p.evaluate(()=>{localStorage.setItem('cuaderno-correo-preguntado','1');document.querySelectorAll('dialog[open]').forEach(d=>d.close());});
 const windowPromise=uvWindow(app);await p.evaluate(()=>fetch('/api/intranet/abrir',{method:'POST',body:'{}'}));
 const uv=await windowPromise;return {p,uv};
}
(async()=>{try{
 // Open window before awaiting its event: app.windows also covers an already delivered event.
 const first=await launch();
 const p=first.p,uv=first.uv;uv.setDefaultTimeout(10000);await uv.waitForURL('https://as.uv.es/**');
 await uv.locator('[name="username"]').fill('prueba');await uv.locator('[name="password"]').fill('incorrecta');await uv.getByRole('button',{name:'Acceder'}).click();await uv.getByRole('alert').waitFor();
 assert.equal((await p.evaluate(()=>fetch('/api/intranet/estado').then(r=>r.json()))).saved,false);
 await uv.locator('[name="username"]').fill('prueba');await uv.locator('[name="password"]').fill('clave-ficticia');await uv.getByRole('button',{name:'Acceder'}).click();await uv.waitForURL('https://portal.uv.es/**');
 await p.waitForFunction(async()=>!!(await fetch('/api/intranet/estado').then(r=>r.json())).saved);
 const disk=fs.readFileSync(path.join(profile,'ajustes.json'),'utf8');assert(!disk.includes('clave-ficticia'));assert(!disk.includes('incorrecta'));console.log('PASS acceso fallido no guardado, acceso correcto cifrado por el sistema');
 await p.locator('#aulaBtn').click();await uv.waitForURL('https://aulavirtual.uv.es/my/');assert.equal(await app.evaluate(()=>uvTest.posts),2);console.log('PASS acceso directo Aula Virtual reutiliza la sesión sin pedir credenciales');
 await p.locator('#intranetBtn').click();await uv.waitForURL('https://portal.uv.es/**');assert.equal(await app.evaluate(()=>uvTest.posts),2);await app.evaluate(()=>{uvTest.ssoOnly=true;});
 await uv.goto('https://aulavirtual.uv.es/login/index.php');await uv.waitForURL('https://portal.uv.es/**');assert.equal(await app.evaluate(()=>uvTest.posts),3);console.log('PASS Aula usa SSO UV y renueva automáticamente con la clave guardada');
 await uv.close();await app.evaluate(()=>{uvTest.authed=false;uvTest.reject=true;});const failedWindow=uvWindow(app);await p.locator('#aulaBtn').click();const failed=await failedWindow;await failed.getByRole('alert').waitFor();await failed.waitForTimeout(700);assert.equal(await app.evaluate(()=>uvTest.posts),4);assert.equal((await p.evaluate(()=>fetch('/api/intranet/estado').then(r=>r.json()))).saved,true);console.log('PASS clave rechazada detiene la renovación sin bucle ni borrar la clave guardada');
 await failed.close();await app.evaluate(()=>{uvTest.challenge=true;uvTest.reject=false;});const challengeWindow=uvWindow(app);await p.locator('#aulaBtn').click();const challenge=await challengeWindow;await challenge.locator('[name=otp]').waitFor();await challenge.waitForTimeout(500);assert.equal(await app.evaluate(()=>uvTest.posts),4);console.log('PASS verificación adicional queda pendiente del alumno, sin envío automático');
 await p.locator('#railToggle').click();await p.screenshot({path:path.join(__dirname,'../revisiones/2026-11-15/aula-acceso-directo.png')});
 await app.close();app=null;
 // Restart with same local profile: the OS vault must decrypt the previous record.
 const second=await launch();const uv2=second.uv;await uv2.waitForURL('https://portal.uv.es/**');assert.equal(await app.evaluate(()=>uvTest.posts),1);console.log('PASS reinicio recupera el acceso y entra sin volver a escribir la clave');
 await app.evaluate(()=>{uvTest.authed=false;});
 await second.p.evaluate(()=>fetch('/api/intranet/olvidar',{method:'POST',body:'{}'}));await uv2.waitForTimeout(500);await uv2.waitForFunction(()=>document.querySelector('[type=password]')?.value==='');
 assert.equal((await second.p.evaluate(()=>fetch('/api/intranet/estado').then(r=>r.json()))).saved,false);assert(!fs.readFileSync(path.join(profile,'ajustes.json'),'utf8').includes('uvAccess'));console.log('PASS reinicio recupera el acceso; olvidar elimina claves y autorrelleno');
 await second.p.locator('#setBtn').click();await second.p.locator('#uvLoginStatus').waitFor();assert.match(await second.p.locator('#uvLoginStatus').textContent(),/primera vez/);console.log('PASS Ajustes explica el guardado de ambos servicios sin revelar claves');
}finally{await app?.close();}})().catch(e=>{console.error(e);process.exit(1)});
