/* Recordatorio del Aula Virtual con varias tareas. Datos ficticios. NODE_PATH=<playwright> node pruebas/recordatorio-tareas.cjs */
const {chromium}=require('playwright'),fs=require('node:fs'),http=require('node:http'),path=require('node:path'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..');
(async()=>{let browser,server;try{
 const subj=(id,short,code,name,tasks=[])=>({id,short,code,name,color:'#399c91',notes:[],tasks,files:[],biblio:[],teachers:[],emails:[]});
 const body='Hola, Prueba,.\n\nLas siguientes tarean vencerán en LUNES, 23 DE NOVIEMBRE DE 2026.\n\n* TAREA 1: PREGUNTA 1 (20%) en curso 2026-27 Aprenentatge i ensenyança de\nla llengua castellana i la seua literatura Gr.2-X (40524)\nVENCIMIENTO: 8:00 PM\nIr a la actividad [1]\n* PROPUESTAS ÁMBITOS en curso 2026-27 Complements per a la formació\ndisciplinar en l\'especialitat de llengua castellana i literatura Gr.2-X\n(40523)\nVENCIMIENTO: 9:00 PM\nIr a la actividad [2]\n* TAREA AJENA en curso 2026-27 Otro curso (99999)\nVENCIMIENTO: 9:00 PM\nIr a la actividad [3]\n\nLinks:\n------\n[1] https://aulavirtual.uv.es/mod/assign/view.php?id=111&action=view\n[2] https://aulavirtual.uv.es/mod/assign/view.php?id=222&action=view\n[3] https://aulavirtual.uv.es/mod/assign/view.php?id=333&action=view';
 const mail={uid:'dg1',subject:'Tiene tareas con fecha de entrega en 7 días',from:'noreply@uv.es',from_name:', No contestar a este correo (vía AulaVirtual)',date:'2026-11-16T00:03:43.000Z',seen:true,body,attachments:[]};
 // Estado como lo dejó la versión anterior: correo ya visto y guardado como una sola duda; una de las tareas ya existía.
 const state={subjects:[subj('a','AEM','40524','Aprendizaje y enseñanza de la lengua'),subj('b','CFD','40523','Complementos para la formación disciplinar',[{id:'old',title:'Propuestas ámbitos',av:'222',due:'2026-11-20',done:false,created:1}])],active:'a',subjectScope:'all',activeNote:null,view:'tasks',theme:'light',settings:{userName:'Prueba',lang:'es'},deleted:{},library:[],schedule:[],homeBoard:[],seeded2627:true,tfmAdded:true,autoMail:{seen:{dg1:true},review:[{uid:'dg1',sid:'a',due:'2026-11-23',title:'Tiene tareas con fecha de entrega en 7 días'}],dismissed:{}}};
 server=http.createServer(async(req,res)=>{const u=new URL(req.url,'http://x');let d='';for await(const b of req)d+=b;const json=j=>{res.setHeader('Content-Type','application/json');res.end(JSON.stringify(j));};
  if(u.pathname==='/api/datos')return json({state:JSON.parse(d||'{}')});if(u.pathname==='/api/correos')return json({configured:true,user:'prueba',mails:[mail]});if(u.pathname.startsWith('/api/'))return json({ok:true,configured:true,user:'prueba',ids:[],drafts:[],results:[],current:'4.0.3'});
  const f=u.pathname==='/'?path.join(root,'cuaderno-apuntes.html'):path.join(root,u.pathname);if(!fs.existsSync(f)){res.statusCode=404;return res.end();}res.setHeader('Content-Type',/\.m?js$/.test(f)?'text/javascript':f.endsWith('.html')?'text/html':'application/octet-stream');res.end(fs.readFileSync(f));});
 await new Promise(r=>server.listen(0,'127.0.0.1',r));browser=await chromium.launch({executablePath:process.env.CHROME_PATH||'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});
 const p=await browser.newPage({viewport:{width:1100,height:900}}),errors=[];p.on('pageerror',e=>errors.push(e.message));
 await p.addInitScript(s=>{if(top!==window)return;if(!localStorage.getItem('cuaderno-apuntes-v1'))localStorage.setItem('cuaderno-apuntes-v1',JSON.stringify(s));localStorage.setItem('cuaderno-correo-preguntado','1');},state);
 await p.goto('http://127.0.0.1:'+server.address().port);await p.waitForTimeout(3000);await p.evaluate(()=>document.querySelectorAll('dialog[open]').forEach(d=>d.close()));
 const saved=()=>p.evaluate(()=>JSON.parse(localStorage.getItem('cuaderno-apuntes-v1')));
 let st=await saved(),a=st.subjects[0],b=st.subjects[1];
 assert.deepEqual(a.tasks.map(t=>[t.title,t.due,t.av]),[['Tarea 1: pregunta 1 (20%)','2026-11-23','111']]);assert.match(a.tasks[0].info,/cierra a las 20:00/);
 assert.deepEqual(b.tasks.map(t=>[t.id,t.due,t.av]),[['old','2026-11-23','222']]);
 assert.equal(st.autoMail.review.length,0);assert.equal(await p.locator('#taskReview').isHidden(),true);
 console.log('PASS recordatorio antiguo ya visto: una tarea por línea con nombre, hora y enlace; la existente actualiza su plazo; curso ajeno ignorado; la duda desaparece');
 await p.reload();await p.waitForTimeout(2500);st=await saved();assert.equal(st.subjects[0].tasks.length,1);assert.equal(st.subjects[1].tasks.length,1);console.log('PASS al volver a abrir no se duplican');
 await p.screenshot({path:path.join(root,'revisiones/2026-11-16/recordatorio-tareas.png')});assert.deepEqual(errors,[]);
}finally{await browser?.close();server?.close();}})().catch(e=>{console.error(e);process.exit(1)});
