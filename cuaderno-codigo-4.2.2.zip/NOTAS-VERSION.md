# Cuaderno 4.2.2

- **Invitar a un trabajo en grupo es más fácil:** el código ahora es corto (por ejemplo T82R-78JD-GC6R), sale grande en «Invitar» y es el mismo para todo el grupo. Quien lo recibe lo escribe en «¿Te han invitado?». La ventana de trabajos separa «Crear un trabajo» de «¿Te han invitado?». Los códigos largos anteriores siguen funcionando.
- **Avisos visibles:** mensajes como «Código copiado» salen por encima de las ventanas, no detrás.
- **Cabecera:** el muñeco, las pestañas y los botones de arriba tienen más aire y quedan centrados.
- **Barra del editor:** la franja de la barra de herramientas ya no deja «cortes» a los lados; se funde con el panel.

Incluye todas las mejoras de la versión 4.2.1. Los datos guardados se conservan al actualizar.

## Descargas

- **Mac con chip Apple:** Cuaderno-mac-arm64.dmg.
- **Mac Intel:** Cuaderno-mac-x64.dmg.
- **Windows de 64 bits:** Cuaderno-win-x64.exe.

Probado con datos ficticios. Los trabajos en grupo necesitan internet; un código recién creado puede tardar hasta un minuto en funcionar. Windows físico queda pendiente de comprobación.
