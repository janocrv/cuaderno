# Cuaderno 5.0.1

- **Asignaturas más ordenadas en la barra lateral:** cada una ocupa una sola línea y todas quedan alineadas. Al pasar el ratón se ve el nombre completo.
- **Número de tareas** en la esquina de la tarjeta de cada asignatura, sin tapar las siglas.
- **Clase actual:** vuelve el puntito brillante que late en la asignatura que tienes en clase, más discreto (sin marco ni resplandor). Se puede apagar en ⋯ → «Brillo de la clase actual».

Incluye todas las mejoras de la versión 5.0.0. Los datos guardados se conservan al actualizar.

## Descargas

- **Mac con chip Apple:** Cuaderno-mac-arm64.dmg.
- **Mac Intel:** Cuaderno-mac-x64.dmg.
- **Windows de 64 bits:** Cuaderno-win-x64.exe.

Probado con datos ficticios. Windows físico queda pendiente de comprobación.
